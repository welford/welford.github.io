// SPDX-License-Identifier: MIT
/* region-map.js: a fast point / box map with nested regions, on OpenLayers (WebGL)
 *
 * Needs OpenLayers (tested with ol@10.6.1) loaded first, plus region-map.css:
 *   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ol@10.6.1/ol.css">
 *   <script src="https://cdn.jsdelivr.net/npm/ol@10.6.1/dist/ol.js"></script>
 *   <link rel="stylesheet" href="region-map.css">
 *   <script src="region-map.js"></script>
 *
 *   const rm = RegionMap.create(document.getElementById('here'), {
 *     title: 'Depots',                       // panel heading (none if left out)
 *     extent: [0, 0, 100000, 100000],        // the abstract x/y space (no geographic projection)
 *     categories: [{ name: 'Alpha', color: '#4e79a7' }, 'Bravo'],   // names alone get palette colours
 *     points: [{ x, y, cat, value, id, ...anything }],              // cat: a category's name or index
 *     boxes:  [{ x0, y0, x1, y1, cat, value, id, ...anything }],
 *     regions: geojson | [flat list] | 'url/of/regions.json' | RegionMap.sample.regions({ extent }),   // see below
 *     regionsLabel: 'my regions',            // shown as the regions' source (default: the file name / 'data')
 *     regionTargetPx: 300,                   // a region level is shown once its regions are about this wide
 *     panel: true,                           // the side panel (false: the map alone)
 *     stats: true,                           // the Performance section (feature count, load time, frame rate)
 *     dimOthers: true,                       // while something is selected, everything else fades back
 *     pulse: true,                           // rings grow out of features selected from outside the map (a table row)
 *     dimOnHover: false,                     // true: hovering a feature (or its table row) dims everything else too
 *     note: 'Coordinates are…',              // a hint at the bottom of the panel
 *     csvColumns: { x: 'easting', y: 'northing', cat: ['type', 'kind'] },   // which CSV columns hold x, y, x0, y0,
 *                              //   x1, y1, cat, value or id, when a file names them differently (a list: the
 *                              //   first one the file has). See "Files dropped on the map" below
 *     csvAppend: false,                      // true: a dropped (or loaded) CSV adds its points / boxes to what is
 *                                            //   there instead of replacing them (the panel has a checkbox for it)
 *     onSelect: sel => {},                   // { kind: 'point' | 'box', index, data } | { kind: 'area', extent, points,
 *                                            //   boxes, pointIndexes, boxIndexes } | { kind: 'rows', pointIndexes,
 *                                            //   boxIndexes } (from highlight) | { kind: 'picked', pointIndexes, boxIndexes,
 *                                            //   points, boxes, added } (Ctrl/⌘+clicks) | null. index: in points / boxes
 *   });
 *
 *   rm.setData({ points, boxes })            replace the data; returns { count, ms }
 *   rm.loadRegions(geojson | url, label)     replace the regions; returns a promise
 *   rm.loadCsv(text, name, csvColumns)       points and/or boxes from CSV text (see below); returns the counts
 *   rm.loadCsv(text, name, csvColumns, { append: true })   add the rows instead (default: the csvAppend option)
 *   rm.setCsvColumns({ x: 'easting', … })   change the column mapping used for dropped / loaded CSVs
 *   rm.setCsvAppend(bool)   rm.csvAppend   whether dropped / loaded CSVs add to the data or replace it
 *   rm.regionsGeoJSON()                      the regions as a GeoJSON object (what Export saves)
 *   rm.addSection(title, content, { position: 'top' | 'bottom' })   a panel section of your own; returns it
 *   rm.setStat(label, text)                  add or update a row in the Performance section
 *   rm.busy('Loading…') / rm.busy(false)     a veil over the map while you work
 *   rm.clearSelection({ silent })
 *   rm.selectFeature('point' | 'box', index, { pan, pulse, silent })   select one (index in points / boxes);
 *                                            pan: bring it on screen (default true), pulse: rings grow out of it (default: the pulse option)
 *   rm.highlight(pointIndexes, boxIndexes, { pan, pulse, silent, label })   highlight several, like an area selection
 *   rm.hover('point' | 'box', index) / rm.hover(null)   hover a feature from outside (white, larger; dims with dimOnHover)
 *   rm.setShown(pointMask, boxMask)          draw only these (0 / 1 per point and per box; null: all)
 *   rm.on('data' | 'select', fn) -> off      'data': setData ran, with { points, boxes }; 'select': as onSelect.
 *                                            silent: true on the calls above means no 'select' event
 *   rm.data                                  the current { points, boxes }
 *   rm.categoryOf(cat) -> { name, color }    how a cat value is drawn
 *   rm.map                                   the ol.Map, for anything else
 *
 * A tarang-table can be linked with region-map-table.js (filters, selection and clicks both ways).
 *   rm.destroy()
 *
 * Regions are GeoJSON polygons with properties { id, parentId, level, name } (level and name are optional:
 * levels come from the parent chain). One level shows at a time, chosen from the zoom; click a region to go
 * into it (pinning, togglePin, has no shortcut for now). Points are counted per region (exact point-in-polygon), cached.
 * Regions can also be a flat JSON list, one object per region (anywhere GeoJSON is taken, files included):
 *   [{ id: 'root', name: 'World', box: [x0, y0, x1, y1] },
 *    { id: 'A', parent: 'root', name: 'North', polygon: [[x, y], [x, y], [x, y], …] }, …]
 * with a box or a polygon (its corners in order; repeating the first at the end is optional). parent (or
 * parentId), name and level are optional as in GeoJSON; any other fields are kept as the region's
 * properties. RegionMap.regionsFromList(list) gives the GeoJSON.
 *
 * Sample data for demos: RegionMap.sample.data({ extent, points, boxes, categories }) gives { points, boxes }
 * in clusters; RegionMap.sample.regions({ extent, depth, seed }) gives nested Voronoi regions.
 *
 * Files dropped on the map (or picked with Load…): GeoJSON replaces the regions; a CSV replaces the points
 * and/or boxes (or, with csvAppend, adds to them: several CSVs can then be dropped at once). The CSV needs a
 * header row: x, y for points, x0, y0, x1, y1 for boxes (a file can mix both), and
 * optionally cat (or category), value and id; other columns show in the selection details. Names are matched
 * ignoring case, and comma, semicolon or tab separated all work. A CSV with only points keeps the boxes, and
 * the other way round. RegionMap.csvToData(text, csvColumns) does the reading on its own: { points, boxes,
 * skipped, columns }. With csvColumns, a mapped column wins over one with the field's own name (which is then
 * kept as an ordinary column, "x (column)").
 *
 * Category names in the data that aren't in `categories` are added with the next palette colours (so
 * `categories` can be left out); rows without one are "Other".
 *
 * Several maps can share a page: each keeps its own state.
 */
(function () {
'use strict';

const PALETTE = [[78, 121, 167], [242, 142, 43], [225, 87, 89], [118, 183, 178], [89, 161, 79], [237, 201, 72],
  [176, 122, 161], [255, 157, 167]];
const OTHER_COLOR = [128, 128, 128];
const HOVER = [255, 255, 255, 1];
const SELECT = [255, 213, 74, 1];
const ACCENT = '#ffd54a';
const PIN = '#ff6bd6';
const DIM_ALPHA = 0.16;   // everything outside the selection, while something is selected
// The pulse that shows where a selection made from outside the map is: rings growing from each feature
const PULSE = { rings: 3, gap: 220, life: 900, grow: 34, most: 50 };
const BOX_ID_OFFSET = 10_000_000;   // keeps point and box ids distinct (and exact as GPU floats)
const REGION_TINTS = ['rgba(78,121,167,0.10)', 'rgba(242,142,43,0.09)', 'rgba(225,87,89,0.09)',
  'rgba(118,183,178,0.10)', 'rgba(89,161,79,0.10)', 'rgba(176,122,161,0.10)'];
// Point radius in pixels by zoom: drives both the style and hover picking
const RADIUS_STOPS = [[0, 1.5], [4, 2.5], [10, 6], [16, 10]];
// See reduceRebuilds
const REBUILD_ZOOM_FACTOR = 32;

const fmt = n => n.toLocaleString();
const ms = t => (t < 1000 ? `${Math.round(t)} ms` : `${(t / 1000).toFixed(2)} s`);
const rgb = c => `rgb(${c.join(',')})`;
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const compact = new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 2 });
const pct = (n, d) => (d ? `${(100 * n / d).toFixed(1)}%` : '–');
const hexToRgb = h => {
  const m = /^#?([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(h.trim());
  return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : OTHER_COLOR;
};
let instances = 0;

function radiusAt(zoom) {
  if (zoom <= RADIUS_STOPS[0][0]) return RADIUS_STOPS[0][1];
  for (let i = 1; i < RADIUS_STOPS.length; i++) {
    const [z0, r0] = RADIUS_STOPS[i - 1], [z1, r1] = RADIUS_STOPS[i];
    if (zoom <= z1) return r0 + (r1 - r0) * (zoom - z0) / (z1 - z0);
  }
  return RADIUS_STOPS[RADIUS_STOPS.length - 1][1];
}

// Distance from (x, y) to the outline of a box extent
function distToOutline([x0, y0, x1, y1], x, y) {
  const dx = Math.max(x0 - x, 0, x - x1), dy = Math.max(y0 - y, 0, y - y1);
  if (dx || dy) return Math.hypot(dx, dy);
  return Math.min(x - x0, x1 - x, y - y0, y1 - y);
}

// 1, 2 or 5 times a power of ten, about `target`
function niceStep(target) {
  const p = 10 ** Math.floor(Math.log10(target)), f = target / p;
  return p * (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10);
}

// After every pan/zoom the WebGL vector renderer rebuilds its GPU buffers for *all* features on the main
// thread (~2 ms per 1k features), which shows up as a hitch when the view settles. The existing buffers can
// be redrawn at any view (that is how it animates during the interaction), so only rebuild when the data
// changes or the zoom has moved a long way. This relies on renderer internals of ol@10.6.1: on any other
// version where they are missing it does nothing.
function reduceRebuilds(layer) {
  const renderer = layer.getRenderer();
  if (!renderer || typeof renderer.prepareFrameInternal !== 'function') return;
  const prepare = renderer.prepareFrameInternal.bind(renderer);
  let builtResolution = null;
  renderer.prepareFrameInternal = function (frameState) {
    const res = frameState.viewState.resolution;
    const sourceChanged = this.sourceRevision_ < layer.getSource().getRevision();
    const zoomRatio = builtResolution ? Math.max(res / builtResolution, builtResolution / res) : Infinity;
    if (this.previousExtent_ && !sourceChanged && zoomRatio < REBUILD_ZOOM_FACTOR) {
      this.previousExtent_ = frameState.extent.slice();   // looks unchanged, so buffers are reused
    }
    const before = this.previousExtent_;
    const result = prepare(frameState);
    if (this.previousExtent_ !== before) builtResolution = res;   // a rebuild happened
    return result;
  };
}

const PANEL_HTML = `
  <h1 class="rm-title"></h1>
  <div class="rm-top"></div>
  <section class="rm-stats-section">
    <h2>Performance</h2>
    <div class="rm-stats">
      <span>Features</span><span data-stat="Features">–</span>
      <span>Add to map</span><span data-stat="Add to map">–</span>
      <span>Frame rate</span><span data-stat="Frame rate">–</span>
    </div>
  </section>
  <section class="rm-legend">
    <h2>Categories</h2>
    <div class="rm-legend-rows"></div>
  </section>
  <section>
    <h2>Selection</h2>
    <div class="rm-details rm-hint"></div>
    <div class="rm-btns"><button type="button" class="rm-clear">Clear selection</button></div>
  </section>
  <section>
    <h2>Regions</h2>
    <div class="rm-stats">
      <span>Showing</span><span class="rm-level">–</span>
      <span>Source</span><span class="rm-source">–</span>
    </div>
    <div class="rm-crumb"></div>
    <div class="rm-points rm-hint"></div>
    <div class="rm-pinned"></div>
    <div class="rm-btns">
      <button type="button" class="rm-up">↑ Up a level</button>
      <button type="button" class="rm-load">Load…</button>
      <button type="button" class="rm-export">Export</button>
    </div>
    <label class="rm-append rm-hint"><input type="checkbox" class="rm-append-box"> Dropped CSVs add to the data</label>
    <input type="file" class="rm-file" accept=".geojson,.json,application/geo+json,.csv,.tsv,.txt,text/csv" hidden>
    <div class="rm-hint rm-gap">Click the map (away from points) to zoom into a region.
      Drop (or Load) a <code>.geojson</code> or <code>.json</code>
      file to replace the regions, or a <code>.csv</code> of points (<code>x, y</code>) or boxes (<code>x0, y0, x1, y1</code>) to replace those (or add to them, with the box ticked).</div>
  </section>
  <div class="rm-bottom"></div>
  <section class="rm-hint rm-note"></section>`;
const SELECT_HINT = 'Click a feature (<kbd>Ctrl</kbd>/<kbd>⌘</kbd>+click to add more), or <kbd>Shift</kbd>+drag to select an area.';

function create(container, options = {}) {
  if (!window.ol) throw new Error('RegionMap needs OpenLayers (window.ol) loaded first');
  const opts = { extent: [0, 0, 100000, 100000], regionTargetPx: 300, panel: true, stats: true, maxZoom: 18, ...options };
  const [X0, Y0, X1, Y1] = opts.extent, W = X1 - X0, H = Y1 - Y0;
  csvToData('', opts.csvColumns);   // an unknown field name in csvColumns fails here, not on the first drop

  // Categories, plus "Other" (grey, always last) for rows without one. Names the data brings that aren't
  // listed are added (see addCategories), so CATS, OTHER and catByName change
  const CATS = (opts.categories || []).map((c, i) => {
    const name = typeof c === 'string' ? c : c.name;
    const color = typeof c === 'object' && c.color ? (Array.isArray(c.color) ? c.color : hexToRgb(c.color)) : PALETTE[i % PALETTE.length];
    return { name: String(name), color };
  });
  CATS.push({ name: 'Other', color: OTHER_COLOR });
  let OTHER = CATS.length - 1;
  let catByName = new Map(CATS.slice(0, OTHER).map((c, i) => [c.name, i]));
  const catIndex = c => (typeof c === 'number' && c >= 0 && c < OTHER ? c : c != null && c !== '' && catByName.has(String(c)) ? catByName.get(String(c)) : OTHER);

  // ----- DOM -----
  const root = document.createElement('div');
  root.className = 'rm' + (opts.panel ? '' : ' rm-no-panel');
  const mapEl = document.createElement('div');
  mapEl.className = 'rm-map';
  mapEl.innerHTML = '<div class="rm-tooltip"></div><div class="rm-busy"></div>';
  const panel = document.createElement('aside');
  panel.className = 'rm-panel';
  panel.innerHTML = PANEL_HTML;
  root.append(mapEl, panel);
  container.appendChild(root);
  const q = sel => root.querySelector(sel);
  const tooltip = q('.rm-tooltip'), busyEl = q('.rm-busy'), details = q('.rm-details');
  if (opts.title) q('.rm-title').textContent = opts.title; else q('.rm-title').remove();
  if (!opts.stats) q('.rm-stats-section').hidden = true;
  q('.rm-note').textContent = opts.note || 'Coordinates are an abstract x/y space (no geographic projection). Points and boxes are drawn with WebGL.';
  details.innerHTML = SELECT_HINT;

  // ----- Style expressions (evaluated on the GPU) -----
  const projection = new ol.proj.Projection({ code: `RM-XY-${++instances}`, units: 'pixels', extent: opts.extent });
  // dim: 1 while something is selected, so everything else fades back (see updateDim)
  let variables = { hoverId: -1, selId: -1, dim: 0, ...Object.fromEntries(CATS.map((_, i) => ['v' + i, 1])) };
  const isHover = ['==', ['get', 'uid'], ['var', 'hoverId']];
  const isSel = ['==', ['get', 'uid'], ['var', 'selId']];
  const dimmed = ['==', ['var', 'dim'], 1];
  const baseRadius = ['interpolate', ['linear'], ['zoom'], ...RADIUS_STOPS.flat()];
  // The styles depend on the categories, so they're built (again) by buildLayers
  function layerStyles() {
    // Shown: its category is ticked, and it isn't hidden by setShown (e.g. a linked table's filters)
    const visibleExpr = ['all', ['==', ['match', ['get', 'cat'], ...CATS.flatMap((_, i) => [i, ['var', 'v' + i]]), 0], 1], ['==', ['get', 'shown'], 1]];
    const catColor = alpha => ['match', ['get', 'cat'], ...CATS.flatMap((c, i) => [i, [...c.color, alpha]]), [...OTHER_COLOR, alpha]];
    return {
      point: [{ filter: visibleExpr, style: {
        'circle-radius': ['case', ['any', isHover, isSel], ['*', baseRadius, 2], baseRadius],
        'circle-fill-color': ['case', isSel, SELECT, isHover, HOVER, dimmed, catColor(DIM_ALPHA), catColor(0.9)],
      } }],
      box: [{ filter: visibleExpr, style: {
        'stroke-color': ['case', isSel, SELECT, isHover, HOVER, dimmed, catColor(DIM_ALPHA), catColor(1)],
        'stroke-width': ['case', ['any', isHover, isSel], 2.5, 1],
      } }],
      // Group selections (Shift+drag, rows from a table): in full colour with a yellow ring, over the dimmed rest
      selPoint: [{ filter: visibleExpr, style: {
        'circle-radius': ['*', baseRadius, 1.6], 'circle-fill-color': catColor(0.95),
        'circle-stroke-color': SELECT, 'circle-stroke-width': 1.25,
      } }],
      selBox: [{ filter: visibleExpr, style: { 'stroke-color': SELECT, 'stroke-width': 2 } }],
    };
  }

  // ----- Sources and layers -----
  const pointSource = new ol.source.Vector({ wrapX: false });
  const boxSource = new ol.source.Vector({ wrapX: false });
  const selPointSource = new ol.source.Vector({ wrapX: false });
  const selBoxSource = new ol.source.Vector({ wrapX: false });
  // GPU hit detection is off everywhere: it draws a second hidden copy of every feature each frame, and
  // picking with it uses readPixels, which stalls until the GPU finishes. Picking uses the sources' spatial
  // index instead (see featureAt).
  function buildLayers() {
    const s = layerStyles();
    const webgl = (source, style) => new ol.layer.WebGLVector({ source, style, variables, disableHitDetection: true });
    return [webgl(boxSource, s.box), webgl(pointSource, s.point), webgl(selBoxSource, s.selBox), webgl(selPointSource, s.selPoint)];
  }
  let dataLayers = buildLayers();
  const setVars = vars => { Object.assign(variables, vars); dataLayers.forEach(l => l.updateStyleVariables(vars)); };

  // New category names go in before "Other" with the next palette colours. The GPU styles list the
  // categories, so the data layers are rebuilt; each category keeps its on/off state
  function addCategories(names) {
    const fresh = [...new Set(names)].filter(n => !catByName.has(n));
    if (!fresh.length) return false;
    const shown = new Map(CATS.map((c, i) => [c.name, variables['v' + i]]));
    const otherShown = variables['v' + OTHER];
    CATS.splice(OTHER, 0, ...fresh.map((name, k) => ({ name, color: PALETTE[(OTHER + k) % PALETTE.length] })));
    OTHER = CATS.length - 1;
    catByName = new Map(CATS.slice(0, OTHER).map((c, i) => [c.name, i]));
    variables = { hoverId: -1, selId: variables.selId, dim: variables.dim, ...Object.fromEntries(CATS.map((c, i) => ['v' + i, i === OTHER ? otherShown : shown.get(c.name) ?? 1])) };
    const old = dataLayers;
    dataLayers = buildLayers();
    dataLayers.forEach(l => { map.addLayer(l); reduceRebuilds(l); });
    old.forEach(l => map.removeLayer(l));
    // Free the old layers' GPU buffers once they're off the map (disposing one that never drew throws in ol)
    setTimeout(() => old.forEach(l => { try { l.dispose(); } catch (e) { /* nothing to free */ } }));
    return true;
  }

  // Grid: a small ordinary canvas layer
  function buildGrid() {
    const features = [], step = niceStep(Math.max(W, H) / 10);
    for (let v = Math.ceil(X0 / step) * step; v <= X1; v += step) {
      features.push(new ol.Feature({ geometry: new ol.geom.LineString([[v, Y0], [v, Y1]]) }));
      if (v < X1) features.push(new ol.Feature({ geometry: new ol.geom.Point([v, Y0]), label: compact.format(v), anchor: 'x' }));
    }
    for (let v = Math.ceil(Y0 / step) * step; v <= Y1; v += step) {
      features.push(new ol.Feature({ geometry: new ol.geom.LineString([[X0, v], [X1, v]]) }));
      if (v < Y1) features.push(new ol.Feature({ geometry: new ol.geom.Point([X0, v]), label: compact.format(v), anchor: 'y' }));
    }
    const line = new ol.style.Style({ stroke: new ol.style.Stroke({ color: 'rgba(255,255,255,0.08)', width: 1 }) });
    const textFill = new ol.style.Fill({ color: 'rgba(255,255,255,0.4)' });
    return new ol.layer.Vector({
      source: new ol.source.Vector({ features }),
      style: f => {
        const label = f.get('label');
        if (!label) return line;
        const isX = f.get('anchor') === 'x';
        return new ol.style.Style({ text: new ol.style.Text({
          text: label, font: '11px system-ui, sans-serif', fill: textFill,
          offsetX: isX ? 4 : -6, offsetY: isX ? 10 : -6, textAlign: isX ? 'left' : 'right',
        }) });
      },
    });
  }

  // ----- Nested regions: layer and style -----
  // One level is "current" at a time, chosen from the view resolution: the deepest level whose typical region
  // is at least regionTargetPx wide on screen. The current level is filled and labelled; ancestor levels draw
  // as progressively thicker outlines; deeper levels are hidden.
  const regionSource = new ol.source.Vector({ wrapX: false });
  const regionIndex = {
    byId: new Map(),       // id -> feature
    maxLevel: 1,
    size: [],              // size[level] = typical region width in map units (median sqrt(area))
    tint: new Map(),       // id -> fill colour (kept off the feature so exports stay clean)
    worldArea: 0,
    source: '–',
  };
  let hoverRegionId = null, focusRegionId = null;
  const pinnedRegionIds = new Set();   // pinned regions are drawn at every zoom level (togglePin; no shortcut for now)
  const regionPointCounts = new Map();

  function levelForResolution(res) {
    let lvl = 1;
    for (let l = 2; l <= regionIndex.maxLevel; l++) if (regionIndex.size[l] / res >= opts.regionTargetPx) lvl = l;
    return lvl;
  }
  const regionText = {
    fill: new ol.style.Fill({ color: '#fff' }),
    halo: new ol.style.Stroke({ color: 'rgba(10,12,16,0.85)', width: 3 }),
  };
  const label = f => new ol.style.Text({ text: String(f.get('name')), font: '600 12px system-ui, sans-serif', fill: regionText.fill, stroke: regionText.halo, overflow: false });
  function regionStyle(f, res) {
    const cur = levelForResolution(res), lvl = f.get('level'), id = f.get('id');
    if (pinnedRegionIds.has(id)) {
      // Pinned: visible at every level; labelled only when it is not smaller than the shown level
      return new ol.style.Style({
        zIndex: 50,
        fill: new ol.style.Fill({ color: lvl < cur ? 'rgba(255,107,214,0.06)' : 'rgba(255,107,214,0.22)' }),
        stroke: new ol.style.Stroke({ color: PIN, width: lvl < cur ? 3 : 2 }),
        text: lvl <= cur ? label(f) : undefined,
      });
    }
    if (lvl > cur) return null;
    if (lvl < cur) {
      const depth = cur - lvl;   // ancestors: thicker the further up the hierarchy
      return new ol.style.Style({ zIndex: 10 + depth, stroke: new ol.style.Stroke({ color: id === focusRegionId ? ACCENT : 'rgba(255,255,255,0.75)', width: 1 + depth * 1.5 }) });
    }
    const hovered = id === hoverRegionId;
    return new ol.style.Style({
      zIndex: hovered ? 5 : 0,
      fill: new ol.style.Fill({ color: hovered ? 'rgba(255,255,255,0.12)' : regionIndex.tint.get(id) }),
      stroke: new ol.style.Stroke({ color: hovered ? ACCENT : 'rgba(255,255,255,0.4)', width: hovered ? 2 : 1 }),
      text: label(f),
    });
  }
  const regionLayer = new ol.layer.Vector({ source: regionSource, style: regionStyle, declutter: true, updateWhileAnimating: true, updateWhileInteracting: true });

  // ----- Map -----
  const map = new ol.Map({
    target: mapEl,
    layers: [buildGrid(), regionLayer, ...dataLayers],
    view: new ol.View({
      projection, center: [X0 + W / 2, Y0 + H / 2], zoom: 2, maxZoom: opts.maxZoom,
      extent: [X0 - W * 0.2, Y0 - H * 0.2, X1 + W * 0.2, Y1 + H * 0.2], showFullExtent: true,
    }),
    interactions: ol.interaction.defaults.defaults({ shiftDragZoom: false }),
    controls: ol.control.defaults.defaults({ attribution: false }).extend([
      new ol.control.MousePosition({ coordinateFormat: c => `x ${Math.round(c[0]).toLocaleString()}  y ${Math.round(c[1]).toLocaleString()}` }),
      new ol.control.ScaleLine({ units: 'metric' }),
    ]),
  });
  map.getView().fit(opts.extent, { padding: [30, 30, 30, 30] });
  dataLayers.forEach(reduceRebuilds);

  // ----- Pulse: rings growing out of features, to show where a selection made from outside the map is -----
  // Drawn on an empty canvas layer above everything (zIndex), only while a pulse is running
  const pulseLayer = new ol.layer.Vector({ source: new ol.source.Vector(), zIndex: 1000 });
  map.addLayer(pulseLayer);
  let pulses = [];   // { geom, r0 (px), start }
  const PULSE_TOTAL = (PULSE.rings - 1) * PULSE.gap + PULSE.life;
  pulseLayer.on('postrender', e => {
    if (!pulses.length) return;
    const ctx = ol.render.getVectorContext(e), now = Date.now();
    pulses = pulses.filter(p => now - p.start < PULSE_TOTAL);
    for (const p of pulses) {
      for (let k = 0; k < PULSE.rings; k++) {
        const t = (now - p.start - k * PULSE.gap) / PULSE.life;
        if (t < 0 || t > 1) continue;
        const radius = p.r0 + (1 - (1 - t) ** 3) * PULSE.grow, fade = 1 - t;   // fast out, slowing down
        // a dark halo under the yellow ring, so it shows on light and dark points alike
        ctx.setStyle(new ol.style.Style({ image: new ol.style.Circle({ radius, stroke: new ol.style.Stroke({ color: `rgba(10,12,16,${0.6 * fade})`, width: 5 }) }) }));
        ctx.drawGeometry(p.geom);
        ctx.setStyle(new ol.style.Style({ image: new ol.style.Circle({ radius, stroke: new ol.style.Stroke({ color: `rgba(255,213,74,${fade})`, width: 2.5 }) }) }));
        ctx.drawGeometry(p.geom);
      }
    }
    if (pulses.length) map.render();   // next frame
  });
  function pulse(features) {
    const res = map.getView().getResolution(), start = Date.now();
    pulses = [];
    for (const f of features.slice(0, PULSE.most)) {
      const ext = f.getGeometry().getExtent();
      // from the feature's edge: a box's rings start around the whole box
      const r0 = Math.min(80, Math.max(5, Math.hypot(ol.extent.getWidth(ext), ol.extent.getHeight(ext)) / 2 / res));
      pulses.push({ geom: new ol.geom.Point(ol.extent.getCenter(ext)), r0, start });
    }
    map.render();
  }

  // While anything is selected, everything else fades back (opts.dimOthers: false to keep it all bright)
  // With opts.dimOnHover, hovering a feature (on the map, or through rm.hover) dims the rest too
  function updateDim() {
    const selected = variables.selId !== -1 || selPointSource.getFeatures().length > 0 || selBoxSource.getFeatures().length > 0;
    const on = (opts.dimOthers !== false && selected) || (!!opts.dimOnHover && variables.hoverId !== -1);
    if (variables.dim !== (on ? 1 : 0)) setVars({ dim: on ? 1 : 0 });
  }
  // Hover a feature from outside (e.g. the table row under the pointer); hover(null) to stop
  function hover(kind, index) {
    const f = kind == null ? null : (kind === 'box' ? boxFeatures : pointFeatures)[index];
    const id = f && f.get('shown') === 1 ? f.get('uid') : -1;
    if (id === variables.hoverId) return;
    setVars({ hoverId: id });
    updateDim();
  }

  // ----- Data -----
  let catCounts = new Array(CATS.length).fill(0);
  let totalPoints = 0, hasValue = false;
  const isVisible = f => variables['v' + f.get('cat')] === 1 && f.get('shown') === 1;
  const valueOf = f => { const v = f.get('data').value; return typeof v === 'number' ? v : null; };
  const indexOf = f => (f.get('kind') === 'box' ? f.get('uid') - BOX_ID_OFFSET : f.get('uid'));   // in points / boxes

  // Events for code outside: 'data' (setData ran: { points, boxes }) and 'select' (what onSelect gets)
  const handlers = { data: new Set(), select: new Set() };
  function emit(type, payload) {
    if (type === 'select' && opts.onSelect) opts.onSelect(payload);
    for (const fn of handlers[type]) { try { fn(payload); } catch (err) { console.error('[region-map] listener:', err); } }
  }

  let current = { points: [], boxes: [] };
  let pointFeatures = [], boxFeatures = [];
  let filtered = false;   // setShown has hidden some features
  function setData({ points = [], boxes = [] } = {}) {
    clearSelection();
    filtered = false;
    const t0 = performance.now();
    current = { points, boxes };
    // Category names not listed yet get added (numbers are indexes; no category is "Other")
    const unknown = new Set();
    for (const list of [points, boxes]) {
      for (let i = 0; i < list.length; i++) {
        const c = list[i].cat;
        if (typeof c === 'string' && c !== '' && c !== CATS[OTHER].name && !catByName.has(c)) unknown.add(c);
      }
    }
    if (unknown.size) addCategories([...unknown]);
    catCounts = new Array(CATS.length).fill(0);
    hasValue = false;
    const pts = new Array(points.length), bxs = new Array(boxes.length);
    for (let i = 0; i < points.length; i++) {
      const p = points[i], cat = catIndex(p.cat);
      catCounts[cat]++;
      if (!hasValue && typeof p.value === 'number') hasValue = true;
      pts[i] = new ol.Feature({ geometry: new ol.geom.Point([p.x, p.y]), uid: i, kind: 'point', cat, shown: 1, data: p });
    }
    for (let i = 0; i < boxes.length; i++) {
      const b = boxes[i], cat = catIndex(b.cat);
      catCounts[cat]++;
      if (!hasValue && typeof b.value === 'number') hasValue = true;
      bxs[i] = new ol.Feature({
        geometry: new ol.geom.Polygon([[[b.x0, b.y0], [b.x1, b.y0], [b.x1, b.y1], [b.x0, b.y1], [b.x0, b.y0]]]),
        uid: BOX_ID_OFFSET + i, kind: 'box', cat, shown: 1, data: b,
      });
    }
    pointSource.clear(true); boxSource.clear(true);
    pointSource.addFeatures(pts); boxSource.addFeatures(bxs);
    pointFeatures = pts; boxFeatures = bxs;
    totalPoints = pts.length;
    const took = performance.now() - t0;
    setStat('Features', fmt(pts.length + bxs.length));
    setStat('Add to map', ms(took));
    if (statCell('Shown')) setStat('Shown', 'all');
    renderLegend();
    regionPointCounts.clear();
    updateRegionPanel();
    emit('data', current);
    return { count: pts.length + bxs.length, ms: took };
  }

  // Show only some features: a Uint8Array (or array of 0 / 1) per point and per box, or null for all of
  // them. Hidden ones aren't drawn, picked, selected or counted in regions
  function setShown(pointMask, boxMask) {
    let changedP = false, changedB = false, nP = 0, nB = 0;
    for (let i = 0; i < pointFeatures.length; i++) {
      const s = !pointMask || pointMask[i] ? 1 : 0, f = pointFeatures[i];
      nP += s;
      if (f.get('shown') !== s) { f.set('shown', s, true); changedP = true; }   // silent: one rebuild below, not one per feature
    }
    for (let i = 0; i < boxFeatures.length; i++) {
      const s = !boxMask || boxMask[i] ? 1 : 0, f = boxFeatures[i];
      nB += s;
      if (f.get('shown') !== s) { f.set('shown', s, true); changedB = true; }
    }
    if (changedP) pointSource.changed();
    if (changedB) boxSource.changed();
    if (!changedP && !changedB) return;
    filtered = !!(pointMask || boxMask);
    totalPoints = nP;   // regions' "% of all" is of what is shown
    setStat('Shown', filtered ? `${fmt(nP + nB)} of ${fmt(pointFeatures.length + boxFeatures.length)}` : 'all');
    if (lastArea) selectArea(lastArea, true);   // the selection loses what was hidden
    else if (variables.selId !== -1) {
      const f = variables.selId >= BOX_ID_OFFSET ? boxFeatures[variables.selId - BOX_ID_OFFSET] : pointFeatures[variables.selId];
      if (f && f.get('shown') !== 1) clearSelection(true);
    }
    regionPointCounts.clear();
    updateRegionPanel();
  }

  // ----- Panel helpers -----
  function statCell(name) { return [...root.querySelectorAll('.rm-stats-section [data-stat]')].find(c => c.dataset.stat === name); }
  function setStat(name, text) {
    let cell = statCell(name);
    if (!cell) {
      const k = document.createElement('span'); k.textContent = name;
      cell = document.createElement('span'); cell.dataset.stat = name;
      q('.rm-stats-section .rm-stats').append(k, cell);
    }
    cell.textContent = text;
  }
  function addSection(title, content, { position = 'top' } = {}) {
    const s = document.createElement('section');
    if (title) { const h = document.createElement('h2'); h.textContent = title; s.appendChild(h); }
    if (typeof content === 'string') s.insertAdjacentHTML('beforeend', content);
    else if (content) s.appendChild(content);
    q(position === 'bottom' ? '.rm-bottom' : '.rm-top').appendChild(s);
    return s;
  }
  function busy(text) {
    busyEl.textContent = text || '';
    busyEl.style.display = text ? 'flex' : 'none';
  }
  const swatch = c => `<span class="rm-swatch" style="background:${rgb(c.color)}"></span>`;

  function renderLegend() {
    q('.rm-legend-rows').innerHTML = CATS.map((c, i) => (i === OTHER && !catCounts[i] ? '' : `
      <label>
        <input type="checkbox" data-cat="${i}" ${variables['v' + i] ? 'checked' : ''}>
        ${swatch(c)}${esc(c.name)}
        <span class="rm-count">${fmt(catCounts[i])}</span>
      </label>`)).join('');
  }
  q('.rm-legend-rows').addEventListener('change', e => {
    const i = e.target.dataset.cat;
    if (i === undefined) return;
    setVars({ ['v' + i]: e.target.checked ? 1 : 0 });
    if (lastArea) selectArea(lastArea);   // recount the selection against the visible categories
  });

  // ----- Hover -----
  // Spatial-index picking (R-tree query + exact distance test); points take priority over boxes
  function featureAt([x, y]) {
    const view = map.getView(), res = view.getResolution();
    const pointTol = (radiusAt(view.getZoom()) + 3) * res;
    let best = null, bestD = pointTol;
    pointSource.forEachFeatureInExtent([x - pointTol, y - pointTol, x + pointTol, y + pointTol], f => {
      if (!isVisible(f)) return;
      const [px, py] = f.getGeometry().getCoordinates();
      const d = Math.hypot(px - x, py - y);
      if (d <= bestD) { best = f; bestD = d; }
    });
    if (best) return best;
    const boxTol = 4 * res;
    bestD = boxTol;
    boxSource.forEachFeatureIntersectingExtent([x - boxTol, y - boxTol, x + boxTol, y + boxTol], f => {
      if (!isVisible(f)) return;
      const d = distToOutline(f.getGeometry().getExtent(), x, y);
      if (d <= bestD) { best = f; bestD = d; }
    });
    return best;
  }
  const kindName = f => (f.get('kind') === 'box' ? 'Box' : 'Point');
  const shownId = f => { const d = f.get('data'); return d.id != null ? d.id : f.get('kind') === 'box' ? f.get('uid') - BOX_ID_OFFSET : f.get('uid'); };

  map.on('pointermove', e => {
    if (e.dragging) return;
    updateRegionHover(e.coordinate);
    const f = featureAt(e.coordinate);
    const id = f ? f.get('uid') : -1;
    if (id !== variables.hoverId) { setVars({ hoverId: id }); updateDim(); }
    mapEl.style.cursor = f ? 'pointer' : hoverRegionId && currentRegionLevel() < regionIndex.maxLevel ? 'zoom-in' : '';
    if (!f) { tooltip.style.display = 'none'; return; }
    const cat = CATS[f.get('cat')], v = valueOf(f);
    tooltip.innerHTML = `${swatch(cat)} <b>${kindName(f)} #${esc(shownId(f))}</b> · ${esc(cat.name)}${v != null ? ` · value ${esc(v)}` : ''}`;
    tooltip.style.display = 'block';
    const [x, y] = e.pixel, w = map.getSize()[0];
    tooltip.style.left = (x + 14 + tooltip.offsetWidth > w ? x - 14 - tooltip.offsetWidth : x + 14) + 'px';
    tooltip.style.top = (y + 14) + 'px';
  });
  const onLeave = () => { tooltip.style.display = 'none'; setVars({ hoverId: -1 }); updateDim(); updateRegionHover(null); };
  map.getViewport().addEventListener('pointerleave', onLeave);

  // ----- Click selection -----
  map.on('singleclick', e => {
    const f = featureAt(e.coordinate);
    if (e.originalEvent.ctrlKey || e.originalEvent.metaKey) {   // Ctrl/⌘+click: add to the selection, or take one out
      if (f) toggleInSelection(f);
      return;
    }
    // (Pinning a region, togglePin, has no shortcut for now)
    clearSelection();
    if (!f) {
      // Empty spot: go into the region under the cursor
      const r = regionAt(e.coordinate, currentRegionLevel());
      if (r) drillInto(r);
      return;
    }
    setVars({ selId: f.get('uid') });
    updateDim();
    showFeature(f);
    emit('select', { kind: f.get('kind'), index: indexOf(f), data: f.get('data') });
  });

  // The selection as features: the one selected, or the highlighted group
  function selectedFeatures() {
    if (variables.selId !== -1) {
      const id = variables.selId;
      return [id >= BOX_ID_OFFSET ? boxFeatures[id - BOX_ID_OFFSET] : pointFeatures[id]].filter(Boolean);
    }
    return [...selPointSource.getFeatures(), ...selBoxSource.getFeatures()];
  }
  // Ctrl/⌘+click: one feature in or out of the selection. One left is shown as a single selection, more as a
  // group (as Shift+drag shows them)
  function toggleInSelection(f) {
    const now = selectedFeatures();
    const next = now.includes(f) ? now.filter(g => g !== f) : [...now, f];
    clearSelection(true);
    if (!next.length) { emit('select', null); return; }
    if (next.length === 1) {
      const g = next[0];
      setVars({ selId: g.get('uid') });
      updateDim();
      showFeature(g);
      emit('select', { kind: g.get('kind'), index: indexOf(g), data: g.get('data') });
      return;
    }
    const pts = next.filter(g => g.get('kind') === 'point'), bxs = next.filter(g => g.get('kind') === 'box');
    showGroup(pts, bxs, `${next.length} picked (Ctrl/⌘+click to add or remove)`);
    emit('select', { kind: 'picked', pointIndexes: pts.map(indexOf), boxIndexes: bxs.map(indexOf),
      points: pts.map(g => g.get('data')), boxes: bxs.map(g => g.get('data')),
      added: next.includes(f) ? { kind: f.get('kind'), index: indexOf(f) } : null });   // what this click put in
  }

  // Select one feature from outside (e.g. a table row): { pan } brings it into view if it's off screen, and
  // { pulse } rings it so the eye finds it
  function selectFeature(kind, index, { pan = true, pulse: rings = opts.pulse !== false, silent = false } = {}) {
    const f = (kind === 'box' ? boxFeatures : pointFeatures)[index];
    clearSelection(true);
    if (!f || f.get('shown') !== 1) { if (!silent) emit('select', null); return false; }
    setVars({ selId: f.get('uid') });
    updateDim();
    showFeature(f);
    if (pan) panTo(f.getGeometry().getExtent());
    if (rings) pulse([f]);
    if (!silent) emit('select', { kind, index, data: f.get('data') });
    return true;
  }
  // Highlight several features (as an area selection does), e.g. rows selected in a table
  function highlight(pointIndexes = [], boxIndexes = [], { pan = true, pulse: rings = opts.pulse !== false, silent = false, label = 'Selected' } = {}) {
    if (pointIndexes.length + boxIndexes.length === 1) {
      return pointIndexes.length ? selectFeature('point', pointIndexes[0], { pan, pulse: rings, silent }) : selectFeature('box', boxIndexes[0], { pan, pulse: rings, silent });
    }
    clearSelection(true);
    if (!pointIndexes.length && !boxIndexes.length) { if (!silent) emit('select', null); return false; }
    const pts = pointIndexes.map(i => pointFeatures[i]).filter(f => f && f.get('shown') === 1);
    const bxs = boxIndexes.map(i => boxFeatures[i]).filter(f => f && f.get('shown') === 1);
    showGroup(pts, bxs, label);
    if (pan && (pts.length || bxs.length)) {
      const ext = ol.extent.createEmpty();
      for (const f of [...pts, ...bxs]) ol.extent.extend(ext, f.getGeometry().getExtent());
      panTo(ext);
    }
    if (rings) pulse([...pts, ...bxs]);   // the first PULSE.most of them
    if (!silent) emit('select', { kind: 'rows', pointIndexes: pts.map(indexOf), boxIndexes: bxs.map(indexOf) });
    return true;
  }
  // Centre on an extent if any of it is off screen, zooming out only if it doesn't fit
  function panTo(ext) {
    const view = map.getView(), seen = view.calculateExtent(map.getSize());
    if (ol.extent.containsExtent(seen, ext)) return;
    const fits = ol.extent.getWidth(ext) <= ol.extent.getWidth(seen) * 0.9 && ol.extent.getHeight(ext) <= ol.extent.getHeight(seen) * 0.9;
    if (fits) view.animate({ center: ol.extent.getCenter(ext), duration: 350 });
    else view.fit(ext, { padding: [40, 40, 40, 40], duration: 350 });
  }

  const KNOWN = new Set(['x', 'y', 'x0', 'y0', 'x1', 'y1', 'cat', 'id', 'value']);
  function showFeature(f) {
    const cat = CATS[f.get('cat')], isBox = f.get('kind') === 'box', ext = f.getGeometry().getExtent(), data = f.get('data');
    const r = n => fmt(Math.round(n));
    const rows = [
      ['Type', kindName(f)],
      ['ID', esc(shownId(f))],
      ['Category', `${swatch(cat)} ${esc(cat.name)}`],
      ...(valueOf(f) != null ? [['Value', esc(valueOf(f))]] : []),
      isBox ? ['Bounds', `${r(ext[0])}, ${r(ext[1])} → ${r(ext[2])}, ${r(ext[3])}`] : ['Position', `${r(ext[0])}, ${r(ext[1])}`],
      ...(isBox ? [['Size', `${r(ext[2] - ext[0])} × ${r(ext[3] - ext[1])}`]] : []),
      ...Object.keys(data).filter(k => !KNOWN.has(k)).map(k => [esc(k), esc(data[k])]),
    ];
    details.className = 'rm-details';
    details.innerHTML = `<table>${rows.map(row => `<tr><td>${row[0]}</td><td>${row[1]}</td></tr>`).join('')}</table>`;
  }

  // ----- Shift + drag area selection -----
  let lastArea = null;
  const dragBox = new ol.interaction.DragBox({ condition: ol.events.condition.shiftKeyOnly });
  map.addInteraction(dragBox);
  dragBox.on('boxstart', () => clearSelection());
  dragBox.on('boxend', () => selectArea(dragBox.getGeometry().getExtent()));

  function selectArea(extent, silent = false) {
    lastArea = extent;
    const t0 = performance.now();
    const pts = [], bxs = [];
    pointSource.forEachFeatureInExtent(extent, f => { if (isVisible(f)) pts.push(f); });
    boxSource.forEachFeatureIntersectingExtent(extent, f => { if (isVisible(f)) bxs.push(f); });
    showGroup(pts, bxs, null, performance.now() - t0);
    if (!silent) {
      emit('select', { kind: 'area', extent, points: pts.map(f => f.get('data')), boxes: bxs.map(f => f.get('data')),
        pointIndexes: pts.map(indexOf), boxIndexes: bxs.map(indexOf) });
    }
  }
  // Highlight a group of features and sum them up in the Selection section
  function showGroup(pts, bxs, label, queryMs) {
    selPointSource.clear(true); selBoxSource.clear(true);
    selPointSource.addFeatures(pts); selBoxSource.addFeatures(bxs);
    setVars({ selId: -1 });
    updateDim();
    const byCat = new Array(CATS.length).fill(0);
    for (const f of pts) byCat[f.get('cat')]++;
    for (const f of bxs) byCat[f.get('cat')]++;
    details.className = 'rm-details';
    details.innerHTML = `${label ? `<div class="rm-hint">${esc(label)}</div>` : ''}<table>
      <tr><td>Points</td><td>${fmt(pts.length)}</td></tr>
      <tr><td>Boxes</td><td>${fmt(bxs.length)}</td></tr>
      ${CATS.map((c, i) => (byCat[i] ? `<tr><td>${swatch(c)} ${esc(c.name)}</td><td>${fmt(byCat[i])}</td></tr>` : '')).join('')}
      ${queryMs != null ? `<tr><td>Query time</td><td>${ms(queryMs)}</td></tr>` : ''}
    </table>`;
  }

  function clearSelection(silent = false) {
    const had = lastArea || variables.selId !== -1 || selPointSource.getFeatures().length || selBoxSource.getFeatures().length;
    lastArea = null;
    selPointSource.clear(true); selBoxSource.clear(true);
    setVars({ selId: -1 });
    updateDim();
    pulses = [];
    details.className = 'rm-details rm-hint';
    details.innerHTML = SELECT_HINT;
    if (had && silent !== true) emit('select', null);
  }
  q('.rm-clear').addEventListener('click', () => clearSelection());
  // Escape clears this map's selection when the pointer or focus is in it (other maps on the page keep theirs)
  let pointerInside = false;
  root.addEventListener('pointerenter', () => { pointerInside = true; });
  root.addEventListener('pointerleave', () => { pointerInside = false; });
  const onKey = e => { if (e.key === 'Escape' && (pointerInside || root.contains(document.activeElement))) clearSelection(); };
  document.addEventListener('keydown', onKey);

  // ----- Nested regions: loading (data, URL, file picker, drag-and-drop) -----
  const regionFormat = new ol.format.GeoJSON({ dataProjection: projection, featureProjection: projection });

  function applyRegions(geojson, sourceLabel) {
    const features = regionFormat.readFeatures(Array.isArray(geojson) ? regionsFromList(geojson) : geojson);   // a flat list, or GeoJSON
    const byId = new Map();
    features.forEach((f, i) => {
      const id = String(f.get('id') ?? f.getId() ?? `r${i}`);
      f.set('id', id, true);
      if (f.get('name') == null) f.set('name', id, true);
      byId.set(id, f);
    });
    // Derive missing levels from the parent chain (roots are level 1)
    const levelOf = (f, guard = 0) => {
      const given = Number(f.get('level'));
      if (Number.isFinite(given) && given >= 1) return given;
      const parent = byId.get(String(f.get('parentId')));
      return parent && guard < 32 ? levelOf(parent, guard + 1) + 1 : 1;
    };
    features.forEach(f => f.set('level', levelOf(f), true));
    // Typical region size per level (the median width) drives which level is shown at each zoom
    const areas = [];
    for (const f of features) (areas[f.get('level')] ||= []).push(Math.sqrt(Math.abs(f.getGeometry().getArea())));
    const size = areas.map(a => (a ? a.sort((x, y) => x - y)[Math.floor(a.length / 2)] : 0));

    regionIndex.byId = byId;
    regionIndex.maxLevel = Math.max(1, size.length - 1);
    regionIndex.size = size;
    regionIndex.worldArea = features.filter(f => f.get('level') === 1).reduce((a, f) => a + Math.abs(f.getGeometry().getArea()), 0);
    regionIndex.tint = new Map(features.map((f, i) => [f.get('id'), REGION_TINTS[i % REGION_TINTS.length]]));
    regionIndex.source = sourceLabel;
    hoverRegionId = focusRegionId = null;
    pinnedRegionIds.clear();   // ids from the previous region set no longer apply
    regionPointCounts.clear();
    regionSource.clear(true);
    regionSource.addFeatures(features);

    // Start zoomed out on the top level
    const roots = features.filter(f => f.get('level') === 1);
    const ext = ol.extent.createEmpty();
    (roots.length ? roots : features).forEach(f => ol.extent.extend(ext, f.getGeometry().getExtent()));
    if (!ol.extent.isEmpty(ext)) flyTo(ext, 1, 0);
    updateRegionPanel();
  }

  // geojson: an object, GeoJSON text, or a URL to fetch
  async function loadRegions(geojson, sourceLabel) {
    try {
      if (typeof geojson === 'string' && !/^\s*[{[]/.test(geojson)) {
        const res = await fetch(geojson);
        if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
        applyRegions(await res.json(), sourceLabel || geojson.split('/').pop());
      } else {
        applyRegions(typeof geojson === 'string' ? JSON.parse(geojson) : geojson, sourceLabel || 'data');
      }
    } catch (err) {
      alert('Could not read the regions (GeoJSON or a flat JSON list): ' + err.message);
      throw err;
    }
  }
  // A CSV of points and/or boxes (see csvToData). Only the kinds the file has are replaced: a CSV of points
  // keeps the boxes, and the other way round
  // append: add the rows to the points / boxes there are (default: the csvAppend option)
  function loadCsv(text, name = 'CSV', mapping = opts.csvColumns, { append = !!opts.csvAppend } = {}) {
    const got = csvToData(text, mapping);
    if (!got.points.length && !got.boxes.length) {
      const named = Object.entries(mapping || {}).map(([f, n]) => `${f} → ${[].concat(n).join(' / ')}`);
      throw new Error(`${name} has no rows with numbers in x, y (points) or x0, y0, x1, y1 (boxes)`
        + (named.length ? ` (with the columns mapped as ${named.join(', ')})` : '')
        + (got.columns.length ? `. Its columns: ${got.columns.join(', ')}` : ''));
    }
    const join = (had, add) => (!add.length ? had : append ? had.concat(add) : add);
    const before = current;
    const result = setData({ points: join(current.points, got.points), boxes: join(current.boxes, got.boxes) });
    const parts = [got.points.length && `${fmt(got.points.length)} points`, got.boxes.length && `${fmt(got.boxes.length)} boxes`].filter(Boolean);
    const kept = append ? `now ${fmt(current.points.length)} points, ${fmt(current.boxes.length)} boxes`
      : !got.points.length && before.points.length ? 'points kept' : !got.boxes.length && before.boxes.length ? 'boxes kept' : '';
    details.className = 'rm-details rm-hint';
    details.textContent = `${append ? 'Added' : 'Loaded'} ${name}: ${parts.join(', ')}${kept ? ` (${kept})` : ''}`
      + (got.skipped ? `. ${fmt(got.skipped)} row${got.skipped === 1 ? '' : 's'} without coordinates skipped.` : '.');
    // the Data stat lists every file added since the last replace
    dataNames = append && dataNames.length ? [...dataNames, name] : [name];
    setStat('Data', dataNames.length > 2 ? `${dataNames[0]} + ${dataNames.length - 1} more` : dataNames.join(' + '));
    return { points: got.points.length, boxes: got.boxes.length, skipped: got.skipped, ms: result.ms };
  }

  // A dropped or picked file: GeoJSON replaces the regions, anything else is read as a CSV of points / boxes
  const fromFile = async file => {
    if (!file) return;
    const text = await file.text();
    if (/\.(geo)?json$/i.test(file.name) || /^﻿?\s*[{[]/.test(text)) { loadRegions(text, file.name).catch(() => {}); return; }
    busy(`Reading ${file.name}…`);
    await new Promise(r => requestAnimationFrame(() => setTimeout(r)));   // let the veil show first
    try { loadCsv(text, file.name); } catch (err) { alert(err.message); } finally { busy(false); }
  };
  // Several files at once: each in turn while CSVs add to the data; otherwise just the first (each would
  // replace the one before)
  const fromFiles = async files => {
    const list = Array.from(files || []);
    for (const f of opts.csvAppend ? list : list.slice(0, 1)) await fromFile(f);
  };
  let dataNames = [];   // the files in the data since the last replace (for the Data stat)

  // The "Dropped CSVs add to the data" checkbox
  const appendBox = q('.rm-append-box');
  const setCsvAppend = on => { opts.csvAppend = !!on; if (appendBox) appendBox.checked = opts.csvAppend; };
  if (appendBox) appendBox.addEventListener('change', () => { opts.csvAppend = appendBox.checked; });
  setCsvAppend(opts.csvAppend);

  q('.rm-load').addEventListener('click', () => { q('.rm-file').multiple = !!opts.csvAppend; q('.rm-file').click(); });
  q('.rm-file').addEventListener('change', async e => { await fromFiles(e.target.files); e.target.value = ''; });
  mapEl.addEventListener('dragover', e => { e.preventDefault(); mapEl.classList.add('rm-dropping'); });
  mapEl.addEventListener('dragleave', e => { if (e.target === mapEl || !mapEl.contains(e.relatedTarget)) mapEl.classList.remove('rm-dropping'); });
  mapEl.addEventListener('drop', e => { e.preventDefault(); mapEl.classList.remove('rm-dropping'); fromFiles(e.dataTransfer.files); });

  const regionsGeoJSON = () => regionFormat.writeFeaturesObject(regionSource.getFeatures(), { decimals: 1 });
  q('.rm-export').addEventListener('click', () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(regionsGeoJSON())], { type: 'application/geo+json' }));
    a.download = 'regions.geojson';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });

  // ----- Nested regions: navigation, hover, breadcrumb, point counts -----
  const currentRegionLevel = () => levelForResolution(map.getView().getResolution());
  const regionParent = f => regionIndex.byId.get(String(f.get('parentId'))) || null;
  const regionAt = (coord, level) => regionSource.getFeaturesAtCoordinate(coord).find(f => f.get('level') === level) || null;

  // A resolution at which `level` is the shown level, fitting `ext` where possible
  function resolutionForLevel(level, ext) {
    const [w, h] = map.getSize() || [800, 600];
    const fitRes = Math.max(ol.extent.getWidth(ext) / Math.max(1, w - 80), ol.extent.getHeight(ext) / Math.max(1, h - 80));
    const { size, maxLevel } = regionIndex;
    const upper = level > 1 ? size[level] / opts.regionTargetPx : Infinity;       // at or below: level is shown
    const lower = level < maxLevel ? size[level + 1] / opts.regionTargetPx : 0;    // at or below: next level takes over
    return Math.min(upper * 0.98, Math.max(fitRes, lower * 1.15));
  }
  function flyTo(ext, level, duration = 450) {
    const view = map.getView(), resolution = resolutionForLevel(level, ext), center = ol.extent.getCenter(ext);
    if (duration) view.animate({ center, resolution, duration });
    else { view.setCenter(center); view.setResolution(resolution); }
  }
  // Zoom so `region`'s children become the shown level (or just fit it at the deepest level)
  function drillInto(region) {
    focusRegionId = region.get('id');
    flyTo(region.getGeometry().getExtent(), Math.min(region.get('level') + 1, regionIndex.maxLevel));
    regionLayer.changed();
  }
  // The region whose children are currently on screen
  function contextRegion() {
    const cur = currentRegionLevel();
    if (cur <= 1) return null;
    const center = map.getView().getCenter(), focused = regionIndex.byId.get(focusRegionId);
    if (focused && focused.get('level') === cur - 1 && focused.getGeometry().intersectsCoordinate(center)) return focused;
    return regionAt(center, cur - 1);
  }
  q('.rm-up').addEventListener('click', () => {
    const ctx = contextRegion();
    if (!ctx) return;
    const parent = regionParent(ctx);
    if (parent) drillInto(parent);
    else { focusRegionId = null; flyTo(ctx.getGeometry().getExtent(), ctx.get('level')); regionLayer.changed(); }
  });

  function updateRegionHover(coord) {
    const r = coord ? regionAt(coord, currentRegionLevel()) : null;
    const id = r ? r.get('id') : null;
    if (id === hoverRegionId) return;
    hoverRegionId = id;
    regionLayer.changed();
    updateRegionPanel();
  }
  map.on('moveend', () => {
    // A level change makes the hovered region stale
    const hovered = regionIndex.byId.get(hoverRegionId);
    if (hovered && hovered.get('level') !== currentRegionLevel()) { hoverRegionId = null; regionLayer.changed(); }
    updateRegionPanel();
  });

  // Points inside a region: R-tree query on the region's extent, then exact point-in-polygon. Cached per region.
  function countRegionPoints(region) {
    const id = region.get('id');
    if (regionPointCounts.has(id)) return regionPointCounts.get(id);
    const geom = region.getGeometry(), byCat = new Array(CATS.length).fill(0);
    let total = 0, valueSum = 0, valued = 0;
    pointSource.forEachFeatureInExtent(geom.getExtent(), f => {
      if (f.get('shown') === 1 && geom.intersectsCoordinate(f.getGeometry().getCoordinates())) {   // hidden ones (setShown) aren't counted
        byCat[f.get('cat')]++; total++;
        const v = valueOf(f);
        if (v != null) { valueSum += v; valued++; }
      }
    });
    const result = { total, byCat, valueSum, valued, area: Math.abs(geom.getArea()) };
    regionPointCounts.set(id, result);
    return result;
  }
  function togglePin(region) {
    const id = region.get('id');
    if (pinnedRegionIds.has(id)) pinnedRegionIds.delete(id); else pinnedRegionIds.add(id);
    regionLayer.changed();
    renderPinned();
  }

  // Stacked bar of points per category
  function catBar(byCat, total) {
    if (!total) return '<div class="rm-catbar"></div>';
    return `<div class="rm-catbar">${CATS.map((c, i) => (byCat[i]
      ? `<span style="width:${(100 * byCat[i] / total).toFixed(2)}%;background:${rgb(c.color)}" title="${esc(c.name)}: ${fmt(byCat[i])} (${pct(byCat[i], total)})"></span>`
      : '')).join('')}</div>`;
  }
  function statRows(s) {
    return `<div class="rm-pin-stats">
        <span>Points</span><span>${fmt(s.total)} · ${pct(s.total, totalPoints)} of all</span>
        ${hasValue ? `<span>Avg value</span><span>${s.valued ? (s.valueSum / s.valued).toFixed(1) : '–'}</span>` : ''}
        <span>Area</span><span>${compact.format(s.area)} u² · ${pct(s.area, regionIndex.worldArea)} of map</span>
        <span>Density</span><span>${s.area ? (s.total / (s.area / 1e6)).toFixed(2) : '–'} pts / 1M u²</span>
      </div>${catBar(s.byCat, s.total)}`;
  }
  function renderPinned() {
    const pins = [...pinnedRegionIds].map(id => regionIndex.byId.get(id)).filter(Boolean);
    const box = q('.rm-pinned');
    if (!pins.length) { box.innerHTML = ''; return; }
    const cards = pins.map(r => `<div class="rm-pin-card">
        <div class="rm-pin-head">
          <a data-id="${esc(r.get('id'))}">${esc(r.get('name'))}</a><span class="rm-lvl">level ${r.get('level')}</span>
          <button type="button" data-unpin="${esc(r.get('id'))}" title="Unpin">×</button>
        </div>
        ${statRows(countRegionPoints(r))}
      </div>`);
    // Combined: only pins without a pinned ancestor, so nested pins are not double-counted
    let combined = '';
    if (pins.length > 1) {
      const hasPinnedAncestor = r => { for (let p = regionParent(r); p; p = regionParent(p)) if (pinnedRegionIds.has(p.get('id'))) return true; return false; };
      const tops = pins.filter(r => !hasPinnedAncestor(r));
      const sum = { total: 0, valueSum: 0, valued: 0, area: 0, byCat: new Array(CATS.length).fill(0) };
      for (const r of tops) {
        const s = countRegionPoints(r);
        sum.total += s.total; sum.valueSum += s.valueSum; sum.valued += s.valued; sum.area += s.area;
        s.byCat.forEach((n, i) => { sum.byCat[i] += n; });
      }
      const nested = pins.length - tops.length;
      combined = `<div class="rm-pin-card rm-total">
          <div class="rm-pin-head"><b>Combined</b><span class="rm-lvl">${tops.length} region${tops.length === 1 ? '' : 's'}${nested ? `, ${nested} nested not double-counted` : ''}</span></div>
          ${statRows(sum)}
        </div>`;
    }
    box.innerHTML = `<div class="rm-pins">
        <h3>Pinned (${pins.length}) <button type="button" data-unpin-all>Unpin all</button></h3>
        ${combined}${cards.join('')}
      </div>`;
  }
  q('.rm-pinned').addEventListener('click', e => {
    const d = e.target.dataset || {};
    if ('unpinAll' in d) { pinnedRegionIds.clear(); regionLayer.changed(); renderPinned(); }
    else if (d.unpin) { pinnedRegionIds.delete(d.unpin); regionLayer.changed(); renderPinned(); }
    else if (d.id) { const r = regionIndex.byId.get(d.id); if (r) drillInto(r); }
  });

  function updateRegionPanel() {
    renderPinned();
    const cur = currentRegionLevel();
    const atLevel = regionSource.getFeatures().filter(f => f.get('level') === cur).length;
    q('.rm-level').textContent = `Level ${cur} of ${regionIndex.maxLevel} (${fmt(atLevel)} regions)`;
    q('.rm-source').textContent = regionIndex.source;
    q('.rm-up').disabled = cur <= 1;
    // Describe the hovered region, else the region at the view centre
    const center = map.getView().getCenter();
    const region = regionIndex.byId.get(hoverRegionId) || (center && regionAt(center, cur));
    if (!region) { q('.rm-crumb').innerHTML = '<span class="rm-hint">No region here.</span>'; q('.rm-points').innerHTML = ''; return; }
    const chain = [];
    for (let r = region; r; r = regionParent(r)) chain.unshift(r);
    q('.rm-crumb').innerHTML = chain.map(r => `<a data-id="${esc(r.get('id'))}">${esc(r.get('name'))}</a>`).join('<span class="rm-sep">›</span>');
    const c = countRegionPoints(region);
    q('.rm-points').innerHTML = `<div class="rm-catgrid">
        <span></span><b>Points in ${esc(region.get('name'))}</b><span class="rm-n"><b>${fmt(c.total)}</b></span>
        ${CATS.map((cat, i) => (c.byCat[i] ? `${swatch(cat)}<span>${esc(cat.name)}</span><span class="rm-n">${fmt(c.byCat[i])}</span>` : '')).join('')}
      </div>`;
  }
  q('.rm-crumb').addEventListener('click', e => {
    const r = regionIndex.byId.get(e.target.dataset && e.target.dataset.id);
    if (r) drillInto(r);
  });

  // ----- Frame rate (browser frames per second, sampled every 500 ms) -----
  let raf = 0;
  if (opts.stats) {
    let frames = 0, last = performance.now();
    const tick = now => {
      frames++;
      if (now - last >= 500) { setStat('Frame rate', `${Math.round(frames * 1000 / (now - last))} fps`); frames = 0; last = now; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
  }

  // ----- Start -----
  renderLegend();
  updateRegionPanel();
  if (opts.points || opts.boxes) setData({ points: opts.points, boxes: opts.boxes });
  if (opts.regions) loadRegions(opts.regions, opts.regionsLabel).catch(() => {});

  return {
    map,
    setData,
    loadRegions,
    loadCsv,
    setCsvColumns(mapping) { csvToData('', mapping); opts.csvColumns = mapping; },   // checks the field names first
    setCsvAppend,
    get csvAppend() { return !!opts.csvAppend; },
    regionsGeoJSON,
    addSection,
    setStat,
    busy,
    clearSelection: ({ silent = false } = {}) => clearSelection(silent),
    selectFeature,
    hover,
    highlight,
    setShown,
    on(type, fn) {   // 'data' | 'select'; returns a function that stops listening
      if (!handlers[type]) throw new Error(`Unknown RegionMap event "${type}": use data or select`);
      handlers[type].add(fn);
      return () => handlers[type].delete(fn);
    },
    get data() { return current; },
    // A category's name and colour ('#rrggbb') for a point / box's cat value, as the map draws it
    categoryOf(cat) { const c = CATS[catIndex(cat)]; return { name: c.name, color: '#' + c.color.map(v => v.toString(16).padStart(2, '0')).join('') }; },
    get categoryCounts() { return CATS.map((c, i) => ({ name: c.name, count: catCounts[i] })); },
    destroy() {
      cancelAnimationFrame(raf);
      document.removeEventListener('keydown', onKey);
      map.setTarget(null);
      root.remove();
    },
  };
}

// ---------------------------------------------------------------------------
// Regions as a flat list
// ---------------------------------------------------------------------------
// [{ id, parent, name, level, box: [x0, y0, x1, y1] | polygon: [[x, y], …], …other fields }] as a GeoJSON
// FeatureCollection. Throws, naming the entry, when one has no usable shape
function regionsFromList(list) {
  const where = (r, i) => `Region ${i + 1}${r && r.id != null ? ` ("${r.id}")` : ''}`;
  const features = list.map((r, i) => {
    if (!r || typeof r !== 'object') throw new Error(`${where(r, i)} isn't an object`);
    const { box, polygon, parent, parentId, ...rest } = r;
    let ring;
    if (box != null) {
      if (!Array.isArray(box) || box.length !== 4 || !box.every(Number.isFinite)) throw new Error(`${where(r, i)}: box should be [x0, y0, x1, y1]`);
      const [x0, y0, x1, y1] = box;
      ring = [[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]];
    } else if (polygon != null) {
      const ok = Array.isArray(polygon) && polygon.every(p => Array.isArray(p) && p.length >= 2 && Number.isFinite(p[0]) && Number.isFinite(p[1]));
      if (!ok) throw new Error(`${where(r, i)}: polygon should be a list of [x, y] corners`);
      ring = polygon.map(p => [p[0], p[1]]);
      const [f, l] = [ring[0], ring[ring.length - 1]];
      if (ring.length && (f[0] !== l[0] || f[1] !== l[1])) ring.push([f[0], f[1]]);   // close it
      if (ring.length < 4) throw new Error(`${where(r, i)}: polygon needs at least 3 corners`);
    } else {
      throw new Error(`${where(r, i)} has no box or polygon`);
    }
    const properties = { ...rest };
    const up = parent ?? parentId;
    if (up != null) properties.parentId = up;
    return { type: 'Feature', properties, geometry: { type: 'Polygon', coordinates: [ring] } };
  });
  return { type: 'FeatureCollection', features };
}

// ---------------------------------------------------------------------------
// CSV
// ---------------------------------------------------------------------------
// Rows (arrays of strings) from CSV text: quoted fields ("" for a quote, newlines allowed inside), and the
// delimiter whichever of comma, semicolon or tab is most common in the first line
function parseCsv(text) {
  const firstLine = text.slice(0, text.search(/\r?\n|$/));
  const counts = [',', ';', '\t'].map(d => [d, firstLine.split(d).length]);
  const delim = counts.sort((a, b) => b[1] - a[1])[0][0];
  const rows = [];
  let row = [], field = '', i = 0, quoted = false;
  const n = text.length;
  while (i < n) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') { field += '"'; i += 2; continue; }
        quoted = false; i++; continue;
      }
      field += ch; i++; continue;
    }
    if (ch === '"' && field === '') { quoted = true; i++; continue; }
    if (ch === delim) { row.push(field); field = ''; i++; continue; }
    if (ch === '\r' || ch === '\n') {
      row.push(field); rows.push(row); row = []; field = '';
      i += ch === '\r' && text[i + 1] === '\n' ? 2 : 1;
      continue;
    }
    // plain run up to the next special character, in one slice
    let j = i + 1;
    while (j < n) { const c = text[j]; if (c === delim || c === '\r' || c === '\n' || c === '"') break; j++; }
    field += text.slice(i, j); i = j;
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows;
}

// Points and boxes from CSV text with a header row. Column names are matched ignoring case: x, y for points;
// x0, y0, x1, y1 for boxes; cat (or category), value and id are optional; every other column is kept on
// the row's object as text. A row with numbers in x0..y1 is a box, else one with numbers in x and y is a
// point, else it's skipped. Returns { points, boxes, skipped, columns }
// `mapping` names the file's columns for any of those fields, e.g. { x: 'easting', y: ['northing', 'lat'] }
// (a list: the first one the file has). A mapped column wins over a column with the field's own name, which
// is then kept as an ordinary column
const CANONICAL = { x: 'x', y: 'y', x0: 'x0', y0: 'y0', x1: 'x1', y1: 'y1', cat: 'cat', category: 'cat', value: 'value', id: 'id' };
const FIELDS = new Set(Object.values(CANONICAL));
function csvToData(text, mapping = {}) {
  const rows = parseCsv(String(text).replace(/^﻿/, ''));
  const columns = (rows[0] || []).map(h => h.trim());
  const lower = columns.map(h => h.toLowerCase());
  const explicit = new Map();   // column index -> field
  for (const [field, names] of Object.entries(mapping || {})) {
    if (!FIELDS.has(field)) throw new Error(`Unknown CSV field "${field}": use ${[...FIELDS].join(', ')}`);
    const at = [].concat(names).map(n => lower.indexOf(String(n).trim().toLowerCase())).find(i => i >= 0);
    if (at !== undefined) explicit.set(at, field);
  }
  const mapped = new Set(explicit.values());
  const keys = columns.map((h, i) => explicit.get(i)
    || (!CANONICAL[lower[i]] ? h : !mapped.has(CANONICAL[lower[i]]) ? CANONICAL[lower[i]] : `${h} (column)`));   // never clashes with a field
  const num = v => (v == null || v.trim() === '' ? NaN : Number(v));
  const points = [], boxes = [];
  let skipped = 0;
  for (let r = 1; r < rows.length; r++) {
    const row = rows[r];
    if (row.length === 1 && row[0].trim() === '') continue;   // blank line
    const o = {};
    for (let c = 0; c < keys.length && c < row.length; c++) o[keys[c]] = row[c];
    const x0 = num(o.x0), y0 = num(o.y0), x1 = num(o.x1), y1 = num(o.y1);
    if (o.value != null && o.value.trim() !== '' && Number.isFinite(Number(o.value))) o.value = Number(o.value);
    else delete o.value;
    if (o.cat != null) o.cat = o.cat.trim();
    if (Number.isFinite(x0) && Number.isFinite(y0) && Number.isFinite(x1) && Number.isFinite(y1)) {
      Object.assign(o, { x0, y0, x1, y1 });
      boxes.push(o);
    } else {
      const x = num(o.x), y = num(o.y);
      if (Number.isFinite(x) && Number.isFinite(y)) { o.x = x; o.y = y; points.push(o); } else skipped++;
    }
  }
  return { points, boxes, skipped, columns };
}

// ---------------------------------------------------------------------------
// Sample data
// ---------------------------------------------------------------------------
function gauss(rand) {
  let u = 0, v = 0;
  while (u === 0) u = rand();
  while (v === 0) v = rand();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

// Clustered random points and boxes: { points: [{ x, y, cat, value }], boxes: [{ x0, y0, x1, y1, cat, value }] }
// `categories` is how many (cat is an index) or a list of names (cat is a name)
function sampleData({ extent = [0, 0, 100000, 100000], points = 10000, boxes = 0, categories = 6, clusters = 40, rand = Math.random } = {}) {
  const [X0, Y0, X1, Y1] = extent, W = X1 - X0, H = Y1 - Y0, S = Math.max(W, H);
  const names = Array.isArray(categories) ? categories : null, nCat = names ? names.length : categories;
  const catOf = k => (names ? names[k] : k);
  // Kept strictly inside the extent, so it falls inside the top-level region, not on its edge
  const clampX = v => Math.min(X1 - 0.5, Math.max(X0 + 0.5, v)), clampY = v => Math.min(Y1 - 0.5, Math.max(Y0 + 0.5, v));
  const cs = Array.from({ length: clusters }, () => ({
    x: X0 + W * (0.05 + 0.9 * rand()), y: Y0 + H * (0.05 + 0.9 * rand()),
    spread: S * (0.01 + 0.06 * rand()), cat: Math.floor(rand() * nCat),
  }));
  // Mostly the cluster's own category, sometimes a random one
  const randomCat = c => (rand() < 0.75 ? c.cat : Math.floor(rand() * nCat));
  const pts = new Array(points);
  for (let i = 0; i < points; i++) {
    if (rand() < 0.15) {   // uniform background noise
      pts[i] = { x: X0 + rand() * W, y: Y0 + rand() * H, cat: catOf(Math.floor(rand() * nCat)), value: Math.round(rand() * 1000) };
    } else {
      const c = cs[Math.floor(rand() * cs.length)];
      pts[i] = { x: clampX(c.x + gauss(rand) * c.spread), y: clampY(c.y + gauss(rand) * c.spread), cat: catOf(randomCat(c)), value: Math.round(rand() * 1000) };
    }
  }
  // box sizes are for a 100,000-wide space (40 to 1,540 across, mostly small): unit scales them to this one
  const bxs = new Array(boxes), unit = S / 100000;
  for (let i = 0; i < boxes; i++) {
    const c = cs[Math.floor(rand() * cs.length)];
    const cx = clampX(c.x + gauss(rand) * c.spread * 1.5), cy = clampY(c.y + gauss(rand) * c.spread * 1.5);
    const w = (40 + rand() ** 3 * 1500) * unit, h = (40 + rand() ** 3 * 1500) * unit;
    bxs[i] = { x0: cx - w / 2, y0: cy - h / 2, x1: cx + w / 2, y1: cy + h / 2, cat: catOf(randomCat(c)), value: Math.round(rand() * 1000) };
  }
  return { points: pts, boxes: bxs };
}

// Mulberry32: a small, fast seeded random number generator (the same seed always gives the same numbers, so
// the sample data is the same each time). Returns a function giving numbers in [0, 1). The constants and
// shifts are the algorithm's own: they scramble a 32-bit counter
function mulberry32(a) {
  return () => {
    a = (a + 0x6D2B79F5) | 0;   // | 0: keep it a 32-bit integer
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 2 ** 32;   // >>> 0: as an unsigned 32-bit number, then scaled to [0, 1)
  };
}
// Keep the part of polygon `poly` (open ring of [x, y]) where a*x + b*y <= c
function clipHalfPlane(poly, a, b, c) {
  const out = [];
  for (let i = 0; i < poly.length; i++) {
    const p = poly[i], q = poly[(i + 1) % poly.length];
    const fp = a * p[0] + b * p[1] - c, fq = a * q[0] + b * q[1] - c;
    if (fp <= 0) out.push(p);
    if ((fp < 0 && fq > 0) || (fp > 0 && fq < 0)) {
      const t = fp / (fp - fq);
      out.push([p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])]);
    }
  }
  return out;
}
function voronoiCells(parent, seeds) {
  return seeds.map((s, i) => {
    let cell = parent;
    for (let j = 0; j < seeds.length && cell.length >= 3; j++) {
      if (j === i) continue;
      const t = seeds[j];
      // Closer to s than to t:  2(t - s)·p <= |t|² - |s|²
      cell = clipHalfPlane(cell, 2 * (t[0] - s[0]), 2 * (t[1] - s[1]), t[0] * t[0] + t[1] * t[1] - s[0] * s[0] - s[1] * s[1]);
    }
    return cell;
  });
}
function centroid(poly) {
  let a = 0, cx = 0, cy = 0;
  for (let i = 0; i < poly.length; i++) {
    const [x0, y0] = poly[i], [x1, y1] = poly[(i + 1) % poly.length];
    const k = x0 * y1 - x1 * y0;
    a += k; cx += (x0 + x1) * k; cy += (y0 + y1) * k;
  }
  return a ? [cx / (3 * a), cy / (3 * a)] : poly[0];
}
function insidePolygon(poly, x, y) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

// Nested regions as GeoJSON: each region is split into 5-8 children by a Voronoi diagram clipped to the
// parent polygon. Clipping a convex polygon by half-planes keeps it convex, so every level nests exactly.
function sampleRegions({ extent = [0, 0, 100000, 100000], depth = 4, seed = 20261020, name = 'World' } = {}) {
  const rand = mulberry32(seed);
  const [X0, Y0, X1, Y1] = extent;
  const features = [];
  const r1 = v => Math.round(v * 10) / 10;
  const ring = poly => [...poly.map(([x, y]) => [r1(x), r1(y)]), [r1(poly[0][0]), r1(poly[0][1])]];
  function add(poly, id, parentId, level, label) {
    features.push({ type: 'Feature', properties: { id, parentId, level, name: label }, geometry: { type: 'Polygon', coordinates: [ring(poly)] } });
    if (level >= depth) return;
    // Random seeds inside the parent, relaxed twice (Lloyd) for even, natural-looking cells
    const xs = poly.map(p => p[0]), ys = poly.map(p => p[1]);
    const [minX, maxX, minY, maxY] = [Math.min(...xs), Math.max(...xs), Math.min(...ys), Math.max(...ys)];
    const n = 5 + Math.floor(rand() * 4);
    let seeds = [];
    for (let tries = 0; seeds.length < n && tries < 500; tries++) {
      const x = minX + rand() * (maxX - minX), y = minY + rand() * (maxY - minY);
      if (insidePolygon(poly, x, y)) seeds.push([x, y]);
    }
    let cells = voronoiCells(poly, seeds);
    for (let k = 0; k < 2; k++) {
      seeds = cells.map((c, i) => (c.length >= 3 ? centroid(c) : seeds[i]));
      cells = voronoiCells(poly, seeds);
    }
    cells.filter(c => c.length >= 3).forEach((cell, i) => {
      const childName = level === 1 ? String.fromCharCode(65 + i) : `${label}.${i + 1}`;
      add(cell, childName, id, level + 1, childName);
    });
  }
  add([[X0, Y0], [X1, Y0], [X1, Y1], [X0, Y1]], 'root', null, 1, name);
  return { type: 'FeatureCollection', features };
}

window.RegionMap = { create, csvToData, regionsFromList, sample: { data: sampleData, regions: sampleRegions } };
})();
