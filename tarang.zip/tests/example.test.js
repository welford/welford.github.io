// SPDX-License-Identifier: MIT
// Checks for tarang/example.html, run inside the page (it loads this with ?test): the orders table and
// the charts drawn from it (pie, bars, lines, columns, flow), their filters, clicks, menus and speed on 1M rows
TT.run('Example page: table and charts', async T => {
  const { log, check } = T;
  const frame = () => new Promise(r => requestAnimationFrame(() => setTimeout(r, 20)));
  while (!window.chart5) await new Promise(r => setTimeout(r, 50));
  await frame();
  const t = window.table;
  const brief = p => p.slices.map(s => `${s.name}:${+s.value.toFixed(2)}${s.dimmed ? '(dim)' : ''}`);
  const colours = p => Object.fromEntries(p.slices.map(s => [s.name, s.color]));

  // pie1 counts the rows shown; its total matches the table
  const total1 = chart1.slices.reduce((s, x) => s + x.value, 0);
  check('pie1 total = rows shown', total1, t.view.count());
  log.push('INFO pie1 ' + brief(chart1).join(', '));
  log.push('INFO pie2 ' + brief(chart2).join(', '));
  const rev = t.model.allColumns.find(c => c.label === 'revenue');
  let sum = 0; for (let p = 0; p < t.view.count(); p++) { const v = rev.raw(t.view.at(p)); if (v > 0) sum += v; }
  check('pie2 total = revenue shown', +chart2.slices.reduce((s, x) => s + x.value, 0).toFixed(2), +sum.toFixed(2));
  const c1 = colours(chart1);

  // A table filter on another column: sizes change, colours don't
  await t.setFilter('region', '=North');
  await frame();
  check('pie1 follows region filter', chart1.slices.reduce((s, x) => s + x.value, 0), t.view.count());
  check('colours follow the category', chart1.slices.every(s => c1[s.name] === s.color), true);
  { let s = 0; for (let p = 0; p < t.view.count(); p++) { const v = rev.raw(t.view.at(p)); if (v > 0) s += v; } check('bars follow the region filter', +chart2.slices.reduce((a, x) => a + x.value, 0).toFixed(2), +s.toFixed(2)); }
  await t.clearFilters(); await frame();

  // Clicking a slice filters the table; the pie keeps every slice, the others dimmed; again clears
  const legendRows = document.querySelectorAll('#pie1 .tarang-chart-row');
  const shippedIdx = chart1.slices.findIndex(s => s.name === 'shipped');
  legendRows[shippedIdx].click();
  await new Promise(r => setTimeout(r, 50)); await frame();
  check('click sets the table filter', t.getState().filters, { status: '=shipped' });
  check('all slices kept, others dimmed', chart1.slices.map(s => s.dimmed), chart1.slices.map(s => s.name !== 'shipped'));
  check('table shows only shipped', t.view.count(), chart1.slices.find(s => s.name === 'shipped').value);
  check('pie2 follows the click', chart2.slices.reduce((s, x) => s + x.value, 0) < sum, true);
  document.querySelectorAll('#pie1 .tarang-chart-row')[shippedIdx].click();
  await new Promise(r => setTimeout(r, 50)); await frame();
  check('second click clears', t.getState().filters, {});

  // A typed filter on the pie's own column dims what it leaves out
  await t.setFilter('status', 'deliv | ship'); await frame();
  check('typed own-column filter dims', chart1.slices.filter(s => !s.dimmed).map(s => s.name).sort(), ['delivered', 'shipped']);
  await t.clearFilters(); await frame();

  // Options: summing a column with negative values, folding into Other, a missing column
  chart2.setOptions({ column: 'product', value: 'profit', slices: 3 });
  await frame();
  log.push('INFO product/profit, 3 slices: ' + brief(chart2).join(', ') + ' | ' + document.querySelector('#pie2 .tarang-chart-sub').textContent);
  check('folded to 3 with Other', [chart2.slices.length, chart2.slices[2].other], [3, true]);
  const otherClick = document.querySelectorAll('#pie2 .tarang-chart-bar-row')[2];   // bars: "Other" is last
  otherClick.click(); await new Promise(r => setTimeout(r, 50)); await frame();
  log.push('INFO Other click sets: ' + JSON.stringify(t.getState().filters));
  check('Other click: named ones dimmed', chart2.slices.map(s => s.dimmed), [true, true, false]);
  await t.clearFilters(); await frame();
  chart2.setOptions({ column: 'nope' });   // with pickers: falls back to the first text column
  check('missing column falls back', [chart2.options.column !== 'nope', !document.querySelector('#pie2 .tarang-chart-empty')], [true, true]);
  const plain = document.createElement('div'); plain.style.cssText = 'height:200px;width:400px'; document.body.appendChild(plain);
  const noPick = TarangChart.pie(plain, t, { column: 'nope' });   // without pickers: a message
  check('missing column message', plain.querySelector('.tarang-chart-empty').textContent, 'No column "nope" in the table.');
  noPick.destroy();
  chart2.setOptions({ column: 'product', value: 'revenue', slices: 6 });

  // The ☰ menu: main rows show the choices; each opens a searchable list; picking redraws
  const btn = document.querySelector('#pie1 .tarang-chart-menu-btn');
  const key = (el, k) => el.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }));
  const itemNames = () => [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-name')].map(n => n.textContent);
  btn.click();
  const rowsEls = [...document.querySelectorAll('.tarang-chart-menu-row')];
  check('main menu rows', rowsEls.map(r => r.textContent), ['ChartPie▸', 'Slices bystatus▸', 'Sized bycount of rows▸', 'Most slices6▸',
    '✓Follow the table\'s filters', '✓Click a slice to filter the table', 'Colours shared with the table']);
  rowsEls.find(r => r.dataset.which === 'column').click();
  const search = document.querySelector('.tarang-chart-menu-sub .tarang-chart-search');
  check('search focused', document.activeElement === search, true);
  log.push('INFO slices-by list: ' + itemNames().join(', '));
  check('current ticked', document.querySelector('.tarang-chart-menu-sub .tarang-chart-menu-item.tarang-hot .tarang-chart-menu-name').textContent, 'status');
  check('action column not listed', itemNames().includes('action'), false);
  search.value = 'reg'; search.dispatchEvent(new Event('input'));
  check('search filters', itemNames(), ['region']);
  search.value = 'r'; search.dispatchEvent(new Event('input'));
  check('starts-with first', itemNames()[0], 'region');
  log.push('INFO "r" matches: ' + itemNames().join(', '));
  search.value = 'zzz'; search.dispatchEvent(new Event('input'));
  check('nothing matches', document.querySelector('.tarang-chart-menu-none').textContent, 'Nothing matches');
  search.value = 'reg'; search.dispatchEvent(new Event('input'));
  key(search, 'Enter');
  await frame();
  check('Enter picks; menu closes', [chart1.options.column, !!document.querySelector('.tarang-chart-menu')], ['region', false]);
  check('title follows', document.querySelector('#pie1 .tarang-chart-title').textContent, 'region');
  // Sized by, via keyboard: open, ↓ to the second row, → opens it, type, ↓ ↑, Enter
  btn.click();
  key(document.activeElement, 'ArrowDown'); key(document.activeElement, 'ArrowDown');
  key(document.activeElement, 'ArrowRight');
  const s2 = document.querySelector('.tarang-chart-menu-sub .tarang-chart-search');
  check('keyboard opened Sized by', [document.activeElement === s2, document.querySelector('.tarang-chart-menu-sub').dataset.which], [true, 'value']);
  log.push('INFO sized-by list: ' + itemNames().join(', '));
  s2.value = 'units'; s2.dispatchEvent(new Event('input'));
  key(s2, 'Enter');
  await frame();
  check('picked sum of units', [chart1.options.value, document.querySelector('#pie1 .tarang-chart-title').textContent], ['units', 'region · units']);
  const units = t.model.allColumns.find(c => c.label === 'units');
  let su = 0; for (let p = 0; p < t.view.count(); p++) su += units.raw(t.view.at(p)) || 0;
  check('sums units', chart1.slices.reduce((s, x) => s + x.value, 0), su);
  // Esc in a list goes back to the main menu; Esc again closes; clicking outside closes
  btn.click(); [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'column').click();
  key(document.querySelector('.tarang-chart-search'), 'Escape');
  check('Esc: back to main', [!!document.querySelector('.tarang-chart-menu-sub'), !!document.querySelector('.tarang-chart-menu')], [false, true]);
  key(document.activeElement, 'Escape');
  check('Esc again closes', !!document.querySelector('.tarang-chart-menu'), false);
  btn.click();
  document.body.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
  check('outside click closes', !!document.querySelector('.tarang-chart-menu'), false);
  chart1.setOptions({ column: 'product', value: null });
  btn.click();
  check('setOptions shows in the menu', [...document.querySelectorAll('.tarang-chart-menu-value')].map(n => n.textContent), ['Pie', 'product', 'count of rows', '6']);
  btn.click();
  check('button toggles closed', !!document.querySelector('.tarang-chart-menu'), false);

  // Switches: they apply at once and the menu stays open
  btn.click();
  const toggle = label => [...document.querySelectorAll('.tarang-chart-menu-toggle')].find(r => r.textContent.includes(label));
  const chartTo = async (b, label) => {   // Chart ▸ <label>
    if (!document.querySelector('.tarang-chart-menu')) b.click();
    [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'chart').click();
    [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-item')].find(i => i.querySelector('.tarang-chart-menu-name').textContent === label).click();
    await frame();
  };
  await chartTo(btn, 'Ring');
  check('Ring: ring drawn', [chart1.options.donut, !!document.querySelector('#pie1 .tarang-chart-centre')], [true, true]);
  await chartTo(btn, 'Pie');
  check('Pie: no ring', [chart1.options.donut, !!document.querySelector('#pie1 .tarang-chart-centre')], [false, false]);
  btn.click();
  await t.setFilter('region', '=North'); await frame();
  const followed = chart1.slices.reduce((s, x) => s + x.value, 0);
  toggle('Follow').click(); await frame();
  check('Follow off: every row', [chart1.options.filtered, chart1.slices.reduce((s, x) => s + x.value, 0) > followed], [false, true]);
  toggle('Follow').click(); await frame();
  await t.clearFilters(); await frame();
  toggle('Click a slice').click(); await frame();
  document.body.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
  document.querySelector('#pie1 .tarang-chart-row').click(); await frame();
  check('Click-to-filter off: clicking does nothing', t.getState().filters, {});
  chart1.setOptions({ clickToFilter: true });
  // Most slices: a short list with no search box, picked by keyboard
  btn.click();
  const sl = [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'slices');
  sl.click();
  check('slices list: no search, focused', [!document.querySelector('.tarang-chart-menu-sub .tarang-chart-search'), document.activeElement === document.querySelector('.tarang-chart-menu-sub .tarang-chart-menu-list')], [true, true]);
  log.push('INFO slices list: ' + [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-item')].map(b => b.textContent).join(' | '));
  key(document.activeElement, 'ArrowUp'); key(document.activeElement, 'ArrowUp'); key(document.activeElement, 'ArrowUp'); key(document.activeElement, 'ArrowUp');   // 6 -> 2
  key(document.activeElement, 'Enter'); await frame();
  check('picked 2 slices: one named + Other', [chart1.options.slices, chart1.slices.length, chart1.slices[1].other], [2, 2, true]);
  check('title kept when changing slices', document.querySelector('#pie1 .tarang-chart-title').textContent, 'product');
  chart1.setOptions({ slices: 6 });

  // Bars (chart2 starts as bars): biggest first, one colour, rows click to filter, the menu speaks of bars
  const barRows = () => [...document.querySelectorAll('#pie2 .tarang-chart-bar-row')];
  const barNames = () => barRows().map(r => r.querySelector('.tarang-chart-bar-name').textContent);
  log.push('INFO bars: ' + barRows().map(r => r.textContent).join(' | '));
  const vals = chart2.slices.map(s => s.value);
  check('bars: one row per category', barRows().length, chart2.slices.length);
  const byName = Object.fromEntries(chart2.slices.map(s => [s.name, s.value]));
  check('bars: biggest first', barNames().map(n => byName[n]), [...vals].sort((a, b) => b - a));
  const barColours = colours(chart2);
  check('bars: a colour per category', new Set(Object.values(barColours)).size, chart2.slices.length);
  check('bars drawn in those colours', barRows().map(r => r.querySelector('.tarang-chart-bar').style.background), barNames().map(n => { const h = barColours[n]; return `rgb(${parseInt(h.slice(1, 3), 16)}, ${parseInt(h.slice(3, 5), 16)}, ${parseInt(h.slice(5, 7), 16)})`; }));
  check('bars: longest is full width', barRows()[0].querySelector('.tarang-chart-bar').style.width, '100%');
  barRows()[1].click(); await new Promise(r => setTimeout(r, 50)); await frame();
  const picked = barNames()[1];
  check('bar click filters', t.getState().filters, { product: `=${picked}` });
  check('bar click: others dimmed', barRows().map(r => r.classList.contains('tarang-dim')), barNames().map(n => n !== picked));
  await t.clearFilters(); await frame();
  const btn2 = document.querySelector('#pie2 .tarang-chart-menu-btn');
  btn2.click();
  check('menu speaks of bars', [...document.querySelectorAll('.tarang-chart-menu-label')].map(n => n.textContent), ['Chart', 'Bars by', 'Sized by', 'Most bars']);
  [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'slices').click();
  check('bars allow up to 20', [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-name')].map(n => +n.textContent).at(-1), 20);
  [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-item')].at(-1).click(); await frame();
  chart2.setOptions({ column: 'units', value: null });
  log.push(`INFO units as bars, 20 max: ${barRows().length} rows, last "${barNames().at(-1)}"`);
  check('20 bars incl. Other', [barRows().length, chart2.slices.some(s => s.other)], [20, true]);
  check('past 8 colours: one slate, Other grey', [new Set(chart2.slices.slice(8, 19).map(s => s.color)).size, chart2.slices[8].color, chart2.slices[19].color], [1, '#5b6578', '#4b4f59']);
  const bars20 = colours(chart2);
  await chartTo(btn2, 'Pie');
  check('Pie again: at most 9 slices', [chart2.options.type, chart2.slices.length <= 9, !!document.querySelector('#pie2 .tarang-chart-pie')], ['pie', true, true]);
  check('same colours as a pie', chart2.slices.filter(s => !s.other).every(s => bars20[s.name] === s.color), true);
  await chartTo(btn2, 'Ring');
  check('same colours as a ring', chart2.slices.filter(s => !s.other).every(s => bars20[s.name] === s.color), true);
  await chartTo(btn2, 'Bars');
  chart2.setOptions({ column: 'product', value: 'revenue', slices: 6 });

  // Lines (chart3: revenue along date by region, weekly)
  const L = window.chart3;
  const lineSum = () => +L.slices.reduce((a, s) => a + s.value, 0).toFixed(2);
  const sumShown = label => { const c = t.model.allColumns.find(x => x.label === label); let s = 0; for (let p = 0; p < t.view.count(); p++) { const v = c.raw(t.view.at(p)); if (v === v && v != null) s += v; } return +s.toFixed(2); };
  log.push('INFO lines: ' + document.querySelector('#line1 .tarang-chart-title').textContent + ' | ' + document.querySelector('#line1 .tarang-chart-sub').textContent + ' | ' + brief(L).join(', '));
  check('lines: one per region', L.slices.map(s => s.name).sort(), ['East', 'North', 'South', 'West']);
  check('lines: total = revenue shown', lineSum(), sumShown('revenue'));
  const dates = t.model.allColumns.find(c => c.label === 'date');
  let dmin = Infinity, dmax = -Infinity; for (let i = 0; i < t.model.numRows; i++) { const d = Date.parse(dates.raw(i)); if (d < dmin) dmin = d; if (d > dmax) dmax = d; }
  const weekStart = d => { const day = Math.floor(d / 864e5); return day - ((day + 3) % 7); };
  const weeks = (weekStart(dmax) - weekStart(dmin)) / 7 + 1;
  check('lines: a path per line', document.querySelectorAll('#line1 g path[fill="none"]').length, 4);
  check('lines: same colours as the pie would give', L.slices.every(s => /^#/.test(s.color)), true);
  const lineRows = () => [...document.querySelectorAll('#line1 .tarang-chart-row')];
  check('lines: legend row per line', lineRows().length, 4);
  // hover: the guide and a tooltip with every line
  const hit = document.querySelector('#line1 svg rect');
  const hr = hit.getBoundingClientRect();
  hit.dispatchEvent(new PointerEvent('pointermove', { clientX: hr.left + hr.width / 2, clientY: hr.top + hr.height / 2, bubbles: true }));
  const tipEl = document.querySelector('#line1 .tarang-chart-tip');
  log.push('INFO line tooltip: ' + [...tipEl.children].map(c => c.textContent).join(' | '));
  check('hover tooltip lists every line', [tipEl.hidden, tipEl.querySelectorAll('.tarang-chart-tip-value').length], [false, 4]);
  hit.dispatchEvent(new PointerEvent('pointerleave', { bubbles: true }));
  // legend click filters by region; the others dim
  const northIdx = L.slices.findIndex(s => s.name === 'North');
  lineRows()[northIdx].click(); await new Promise(r => setTimeout(r, 50)); await frame();
  check('legend click filters', t.getState().filters, { region: '=North' });
  check('others dimmed', L.slices.map(s => !!s.dimmed), L.slices.map(s => s.name !== 'North'));
  await t.clearFilters(); await frame();
  // weekly: count the points via the x-axis span
  L.setOptions({ column: null }); await frame();
  check('one line: one series with a wash', [L.slices.length, !!document.querySelector('#line1 path[fill-opacity="0.1"]'), !document.querySelector('#line1 .tarang-chart-legend')], [1, true, true]);
  const onePath = document.querySelector('#line1 path[fill="none"]').getAttribute('d');
  check('one point per week', (onePath.match(/[ML]/g) || []).length, weeks);
  L.setOptions({ value: 'profit' }); await frame();
  check('lines count negative values', lineSum(), sumShown('profit'));
  check('zero line drawn', !!document.querySelector('#line1 .tarang-chart-zero'), true);
  L.setOptions({ x: 'units', value: null }); await frame();
  const unitsDistinct = new Set(Array.from({ length: t.view.count() }, (_, p) => t.model.allColumns.find(c => c.label === 'units').raw(t.view.at(p)))).size;
  log.push(`INFO along units: ${(document.querySelector('#line1 path[fill="none"]').getAttribute('d').match(/[ML]/g) || []).length} points, ${unitsDistinct} distinct shown`);
  check('along a number column: a point per value', (document.querySelector('#line1 path[fill="none"]').getAttribute('d').match(/[ML]/g) || []).length >= unitsDistinct, true);
  L.setOptions({ x: 'product' }); await frame();
  check('along text: a point per value, in order', [...document.querySelectorAll('#line1 .tarang-chart-axis')].filter(n => n.getAttribute('text-anchor') !== 'end' || n.textContent === 'Widget').map(n => n.textContent), ['Doohickey', 'Gadget', 'Gizmo', 'Sprocket', 'Widget']);
  // the menu: Lines rows, Dates by only along dates
  L.setOptions({ x: 'date', column: 'region', value: 'revenue', bucket: 'week' }); await frame();
  const btn3 = document.querySelector('#line1 .tarang-chart-menu-btn');
  btn3.click();
  check('line menu rows', [...document.querySelectorAll('.tarang-chart-menu-label')].map(n => n.textContent), ['Chart', 'Along', 'Dates by', 'Lines by', 'Lines', 'Values', 'Most lines']);
  [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'bucket').click();
  [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-item')].find(i => i.querySelector('.tarang-chart-menu-name').textContent === 'month').click();
  await frame();
  check('Dates by month', [L.options.bucket, (document.querySelector('#line1 g path[fill="none"]').getAttribute('d').match(/[ML]/g) || []).length], ['month', 4]);
  btn3.click();
  [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'x').click();
  [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-item')].find(i => i.querySelector('.tarang-chart-menu-name').textContent === 'product').click();
  await frame();
  btn3.click();
  check('Dates by hidden along text', [...document.querySelectorAll('.tarang-chart-menu-label')].map(n => n.textContent).includes('Dates by'), false);
  btn3.click();
  L.setOptions({ x: 'date', bucket: 'week' });
  // stacked areas: a filled band per line, the top line at the total; 100%: the top line at 100%
  const lineYs = path => (path.getAttribute('d').match(/[ML][\d.]+ ([\d.]+)/g) || []).map(s => +s.split(' ')[1]);
  L.setOptions({ value: null, lines: 'stack' }); await frame();
  const bands = [...document.querySelectorAll('#line1 g path')].filter(p => p.getAttribute('fill') !== 'none');
  check('stacked lines: a filled band per line', bands.length, L.slices.length);
  const topTick = Math.min(...[...document.querySelectorAll('#line1 .tarang-chart-grid, #line1 .tarang-chart-zero')].map(n => +n.getAttribute('y1')));
  const bandEdges = [...document.querySelectorAll('#line1 g path[fill="none"]')];
  check('stacked lines: the top line reaches the top tick area', Math.min(...bandEdges.flatMap(lineYs)) < topTick + 40, true);
  L.setOptions({ lines: 'percent' }); await frame();
  const pctTicks = [...document.querySelectorAll('#line1 .tarang-chart-axis[dominant-baseline="central"]')].map(n => n.textContent);
  check('100% lines: ticks in %, up to 100%', [pctTicks.every(s => s.endsWith('%')), pctTicks.includes('100%')], [true, true]);
  // the top band's edge sits flat at 100% wherever there is data
  const pctEdges = [...document.querySelectorAll('#line1 g path[fill="none"]')].map(lineYs);
  const flatTop = pctEdges.reduce((a, ys) => a.map((y, k) => Math.min(y, ys[k])));
  check('100% lines: the top edge is flat', Math.max(...flatTop) - Math.min(...flatTop) < 1, true);
  L.setOptions({ lines: 'overlap' }); await frame();
  check('overlapping lines: no bands', [...document.querySelectorAll('#line1 g path')].filter(p => p.getAttribute('fill') !== 'none' && p.getAttribute('fill-opacity') === '0.55').length, 0);
  // switching a pie to lines keeps its column as the lines
  await chartTo(btn, 'Lines');
  check('pie -> lines keeps the column', [chart1.options.type, chart1.options.column, !!chart1.options.x], ['line', 'product', true]);
  await chartTo(btn, 'Pie');

  // Columns (chart4: orders per week by status, stacked)
  const C4 = window.chart4;
  const parts = () => [...document.querySelectorAll('#cols1 g path')];
  log.push('INFO columns: ' + document.querySelector('#cols1 .tarang-chart-title').textContent + ' | ' + document.querySelector('#cols1 .tarang-chart-sub').textContent + ' | ' + brief(C4).join(', '));
  check('columns: total = rows shown', C4.slices.reduce((a, s) => a + s.value, 0), t.view.count());
  check('columns: a part per non-zero value', parts().length > weeks, true);
  // stacked: in each band the parts touch end to end; the tallest column reaches the top tick
  const xs = new Map();
  for (const p of parts()) { const m = /^M([\d.]+) ([\d.]+)/.exec(p.getAttribute('d')); const x = +m[1]; xs.set(x, (xs.get(x) || 0) + 1); }
  check('stacked: parts share their column', [...xs.values()].some(n => n > 1), true);
  check('outer end rounded, inner parts square', parts().some(p => p.getAttribute('d').includes('Q')) && parts().some(p => !p.getAttribute('d').includes('Q')), true);
  const hit4 = [...document.querySelectorAll('#cols1 svg rect')].at(-1), r4 = hit4.getBoundingClientRect();
  hit4.dispatchEvent(new PointerEvent('pointermove', { clientX: r4.left + 3, clientY: r4.top + 10, bubbles: true }));
  const tip4 = document.querySelector('#cols1 .tarang-chart-tip');
  log.push('INFO column tooltip: ' + [...tip4.children].map(c => c.textContent).join(' | '));
  check('hover: band lit, tooltip shown', [document.querySelector('#cols1 .tarang-chart-band').getAttribute('visibility'), tip4.hidden], ['visible', false]);
  hit4.dispatchEvent(new PointerEvent('pointerleave', { bubbles: true }));
  // side by side, via the menu
  const btn4 = document.querySelector('#cols1 .tarang-chart-menu-btn');
  btn4.click();
  check('column menu rows', [...document.querySelectorAll('.tarang-chart-menu-label')].map(n => n.textContent), ['Chart', 'Along', 'Dates by', 'Split by', 'Columns', 'Values', 'Most splits']);
  [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'stack').click();
  [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-item')].find(i => i.querySelector('.tarang-chart-menu-name').textContent === 'side by side').click();
  await frame();
  check('side by side: every part rounded', [C4.options.stack, parts().every(p => p.getAttribute('d').includes('Q') || +/v([\d.]+)/.exec(p.getAttribute('d'))?.[1] < 1)], ['group', true]);
  // 100%: every column full height
  C4.setOptions({ stack: 'percent' }); await frame();
  const tops = new Map();
  for (const p of parts()) { const b = p.getBBox(), x = Math.round(b.x); tops.set(x, Math.min(tops.get(x) ?? Infinity, b.y)); }
  log.push('INFO 100% column tops: ' + [...tops.values()].map(v => v.toFixed(1)).join(' '));
  check('100% columns: all the same height', Math.max(...tops.values()) - Math.min(...tops.values()) < 1.5, true);
  // negatives: profit per week stacks below zero
  C4.setOptions({ value: 'profit', stack: 'stack' }); await frame();
  check('columns count negative values', +C4.slices.reduce((a, s) => a + s.value, 0).toFixed(2), sumShown('profit'));
  const zeroY = +document.querySelector('#cols1 .tarang-chart-zero').getAttribute('y1');
  check('some parts below zero', parts().some(p => +/^M[\d.]+ ([\d.]+)/.exec(p.getAttribute('d'))[1] >= zeroY - 1), true);
  // legend click filters the table by that status
  const shippedRow = [...document.querySelectorAll('#cols1 .tarang-chart-row')].find(r => r.textContent.startsWith('shipped'));
  shippedRow.click(); await new Promise(r => setTimeout(r, 50)); await frame();
  check('legend click filters', t.getState().filters, { status: '=shipped' });
  await t.clearFilters(); await frame();
  C4.setOptions({ value: null, column: null }); await frame();
  check('no split: one colour, no legend', [new Set(parts().map(p => p.getAttribute('fill'))).size, !document.querySelector('#cols1 .tarang-chart-legend')], [1, true]);
  C4.setOptions({ column: 'status' }); await frame();

  // Clicking along the axis filters the table to that period
  const colHit = () => [...document.querySelectorAll('#cols1 svg rect')].at(-1);
  const clickBand = (k, mods = {}) => {
    const h = colHit(), r = h.getBoundingClientRect(), B = Math.round(r.width / (r.width / weeks));
    h.dispatchEvent(new MouseEvent('click', { clientX: r.left + (k + 0.5) * (r.width / weeks), clientY: r.top + 20, bubbles: true, ...mods }));
  };
  const totalBefore = C4.slices.reduce((a, s) => a + s.value, 0);
  clickBand(2); await new Promise(r => setTimeout(r, 50)); await frame();
  const f1 = t.getState().filters.date || '';
  log.push('INFO click week 3 sets: date ' + JSON.stringify(f1) + ' | ' + document.querySelector('#cols1 .tarang-chart-sub').textContent);
  check('column click filters the date', /^=2026-01-1\d( \| =2026-01-\d\d)*$/.test(f1), true);
  check('chart keeps every column', C4.slices.reduce((a, s) => a + s.value, 0), totalBefore);
  check('others dimmed', [...document.querySelectorAll('#cols1 g path')].some(p => p.getAttribute('opacity') === '0.3'), true);
  check('subtitle says 1 week', document.querySelector('#cols1 .tarang-chart-sub').textContent.includes('selected in 1 week'), true);
  const shownWeek = t.view.count();
  clickBand(5, { ctrlKey: true }); await new Promise(r => setTimeout(r, 50)); await frame();
  check('Ctrl+click adds a week', [document.querySelector('#cols1 .tarang-chart-sub').textContent.includes('in 2 weeks'), t.view.count() > shownWeek], [true, true]);
  clickBand(5, { ctrlKey: true }); await new Promise(r => setTimeout(r, 50)); await frame();
  check('Ctrl+click again removes it', [t.getState().filters.date, t.view.count()], [f1, shownWeek]);
  // the pie follows the date filter (it isn't the pie's own column)
  check('pie follows the week', chart1.slices.reduce((a, s) => a + s.value, 0), shownWeek);
  clickBand(2); await new Promise(r => setTimeout(r, 50)); await frame();
  check('clicking the only selected week clears', t.getState().filters, {});
  // A part of a column: that period AND that category; again: clear both; empty space: the whole period
  const statusIdx = name => C4.slices.findIndex(s => s.name === name);
  const partEl = name => {   // the biggest part of this status in any column
    const g = document.querySelectorAll('#cols1 svg > g')[statusIdx(name)];
    return [...g.querySelectorAll('path')].sort((a, b) => b.getBoundingClientRect().height - a.getBoundingClientRect().height)[0];
  };
  const clickAt = (x, y, mods = {}) => colHit().dispatchEvent(new MouseEvent('click', { clientX: x, clientY: y, bubbles: true, ...mods }));
  const shippedPart = partEl('shipped'), pr = shippedPart.getBoundingClientRect();
  clickAt(pr.left + pr.width / 2, pr.top + pr.height / 2); await new Promise(r => setTimeout(r, 80)); await frame();
  const st = t.getState().filters;
  log.push('INFO part click sets: ' + JSON.stringify(st) + ' -> ' + t.view.count() + ' rows | ' + document.querySelector('#cols1 .tarang-chart-sub').textContent);
  check('part click: period and category', [!!st.date, st.status], [true, '=shipped']);
  check('table shows only that part', t.view.count() > 0 && [...Array(t.view.count()).keys()].every(p => t.model.allColumns.find(c => c.label === 'status').raw(t.view.at(p)) === 'shipped'), true);
  check('one step: both filters at once', true, true);
  const pr2 = partEl('shipped').getBoundingClientRect();
  clickAt(pr2.left + pr2.width / 2, pr2.top + pr2.height / 2); await new Promise(r => setTimeout(r, 80)); await frame();
  check('same part again clears both', t.getState().filters, {});
  const pr3 = partEl('shipped').getBoundingClientRect();
  clickAt(pr3.left + pr3.width / 2, pr3.top + pr3.height / 2); await new Promise(r => setTimeout(r, 80)); await frame();
  const dateOnly = t.getState().filters.date;
  const plot = colHit().getBoundingClientRect();
  clickAt(pr3.left + pr3.width / 2, plot.top + 3); await new Promise(r => setTimeout(r, 80)); await frame();
  check('empty space: the whole period, every status', t.getState().filters, { date: dateOnly });
  clickAt(pr3.left + pr3.width / 2, plot.top + 3); await new Promise(r => setTimeout(r, 80)); await frame();
  check('empty space again clears', t.getState().filters, {});
  // hovering a part outlines it and the hint names it
  colHit().dispatchEvent(new PointerEvent('pointermove', { clientX: pr3.left + pr3.width / 2, clientY: pr3.top + pr3.height / 2, bubbles: true }));
  log.push('INFO part hover hint: ' + (document.querySelector('#cols1 .tarang-chart-tip-hint') || {}).textContent);
  check('hover outlines the part', [document.querySelector('#cols1 .tarang-chart-part-hot').getAttribute('visibility'), document.querySelector('#cols1 .tarang-chart-tip-hint').textContent.startsWith('Click to show only shipped in this week')], ['visible', true]);
  colHit().dispatchEvent(new PointerEvent('pointerleave', { bubbles: true }));

  // lines: clicking a point does the same; the picked period is highlighted
  const lh = [...document.querySelectorAll('#line1 svg rect')].at(-1), lr = lh.getBoundingClientRect();
  lh.dispatchEvent(new MouseEvent('click', { clientX: lr.left + 6, clientY: lr.top + 20, bubbles: true }));
  await new Promise(r => setTimeout(r, 50)); await frame();
  check('line click filters the first week', [!!t.getState().filters.date, document.querySelectorAll('#line1 .tarang-chart-picked').length], [true, 1]);
  await t.clearFilters(); await frame();
  // along a number column: "=value"
  L.setOptions({ x: 'units', column: null, value: null }); await frame();
  const uh = [...document.querySelectorAll('#line1 svg rect')].at(-1), ur = uh.getBoundingClientRect();
  uh.dispatchEvent(new MouseEvent('click', { clientX: ur.left + 6, clientY: ur.top + 20, bubbles: true }));
  await new Promise(r => setTimeout(r, 50)); await frame();
  log.push('INFO along units, click: ' + JSON.stringify(t.getState().filters));
  check('number point filter', /^=\d+$/.test(t.getState().filters.units || ''), true);
  await t.clearFilters();
  L.setOptions({ x: 'date', column: 'region', value: 'revenue', bucket: 'week' }); await frame();

  // Flow (chart5: revenue, region -> product -> status)
  const F = window.chart5;
  const fsvg = () => document.querySelector('#flow1 svg');
  const fhit = () => [...fsvg().querySelectorAll('rect')].at(-1);
  const fsub = () => document.querySelector('#flow1 .tarang-chart-sub').textContent;
  log.push('INFO flow: ' + document.querySelector('#flow1 .tarang-chart-title').textContent + ' | ' + fsub() + ' | ' + brief(F).join(', '));
  check('flow: colour stage nodes = regions, total = revenue', [F.slices.map(s => s.name).sort(), +F.slices.reduce((a, s) => a + s.value, 0).toFixed(2)], [['East', 'North', 'South', 'West'], sumShown('revenue')]);
  check('flow: region colours match the line chart', F.slices.every(s => { const l = L.slices.find(x => x.name === s.name); return !l || l.color === s.color; }), true);
  check('flow: stage headers', [...fsvg().querySelectorAll('.tarang-chart-stage')].map(n => n.textContent), ['region', 'product', 'status']);
  // every stage's nodes add up to the same total
  const labels = [...fsvg().querySelectorAll('.tarang-chart-node-label')].map(n => n.textContent);
  log.push('INFO flow labels: ' + labels.join(' | '));
  const clickSvg = (x, y, mods = {}) => { const r = fsvg().getBoundingClientRect(); fhit().dispatchEvent(new MouseEvent('click', { clientX: r.left + x, clientY: r.top + y, bubbles: true, ...mods })); };
  const moveSvg = (x, y) => { const r = fsvg().getBoundingClientRect(); fhit().dispatchEvent(new PointerEvent('pointermove', { clientX: r.left + x, clientY: r.top + y, bubbles: true })); };
  const nodeAt = name => { const tl = [...fsvg().querySelectorAll('.tarang-chart-node-label')].find(n => n.textContent.startsWith(name + ' ')); return { x: +tl.getAttribute('x') + (tl.getAttribute('text-anchor') === 'end' ? 12 : -12), y: +tl.getAttribute('y') }; };
  // click a node: that product
  const g = nodeAt('Gadget');
  moveSvg(g.x, g.y);
  log.push('INFO node hover: ' + [...document.querySelector('#flow1 .tarang-chart-tip').children].map(c => c.textContent).join(' | '));
  clickSvg(g.x, g.y); await new Promise(r => setTimeout(r, 80)); await frame();
  check('node click filters that stage', t.getState().filters, { product: '=Gadget' });
  check('flow keeps every row; says what is selected', [fsub().startsWith('69 rows'), /selected/.test(fsub())], [true, true]);
  check('other charts follow', chart2.slices.filter(s => !s.dimmed).map(s => s.name), ['Gadget']);
  clickSvg(g.x, g.y); await new Promise(r => setTimeout(r, 80)); await frame();
  check('again clears', t.getState().filters, {});
  // click a flow: both of its columns (the first band: North -> Doohickey)
  const first = fsvg().querySelector('g path.tarang-chart-flow');
  const m = /^M([\d.]+) ([\d.]+)/.exec(first.getAttribute('d'));
  moveSvg(+m[1] + 15, +m[2] + 1.5);
  log.push('INFO flow hover: ' + [...document.querySelector('#flow1 .tarang-chart-tip').children].map(c => c.textContent).join(' | '));
  clickSvg(+m[1] + 15, +m[2] + 1.5); await new Promise(r => setTimeout(r, 80)); await frame();
  check('flow click filters both columns', t.getState().filters, { region: '=North', product: '=Doohickey' });
  const regionCol = t.model.allColumns.find(c => c.label === 'region'), productCol = t.model.allColumns.find(c => c.label === 'product');
  check('table shows that flow', t.view.count() > 0 && [...Array(t.view.count()).keys()].every(p => regionCol.raw(t.view.at(p)) === 'North' && productCol.raw(t.view.at(p)) === 'Doohickey'), true);
  check('lit and dimmed flows drawn', [fsvg().querySelectorAll('.tarang-chart-flow-dim').length > 0, fsvg().querySelectorAll('path.tarang-chart-flow:not(.tarang-chart-flow-dim)').length > 0], [true, true]);
  // with one region picked, what each product node takes in lines up with what it sends on, at the node's top
  await t.setState({ filters: { region: '=West' } }); await frame();
  const spans = new Map();   // x -> {in: [ [y, y+w] ], out: [...]}
  for (const p of fsvg().querySelectorAll('path.tarang-chart-flow:not(.tarang-chart-flow-dim)')) {
    const n = p.getAttribute('d').match(/-?[\d.]+/g).map(Number);   // M x0 y0 C .. .. .. .. x1 y1 L x1 y1+w C .. .. .. .. x0 y0+w Z
    const [x0, y0, , , , , x1, y1, , y1w, , , , , , y0w] = n;
    (spans.get(x0) || spans.set(x0, { in: [], out: [] }).get(x0)).out.push([y0, y0w]);
    (spans.get(x1) || spans.set(x1, { in: [], out: [] }).get(x1)).in.push([y1, y1w]);
  }
  // merge touching spans into blocks: the selection's way in and way out of a node should be the same blocks
  const blocks = list => {
    const out = [];
    for (const [a, b] of [...list].sort((p, q) => p[0] - q[0])) {
      if (out.length && a - out[out.length - 1][1] < 0.6) out[out.length - 1][1] = b; else out.push([a, b]);
    }
    return out.map(([a, b]) => [Math.round(a), Math.round(b)]);
  };
  const xsIn = [...spans.keys()].filter(x => spans.get(x).in.length);
  const middle = xsIn.map(x => [x, [...spans.keys()].find(x2 => x2 > x && x2 - x < 30 && spans.get(x2).out.length)]).filter(([, x2]) => x2 != null);
  log.push('INFO West picked, middle blocks in/out: ' + middle.map(([x, x2]) => JSON.stringify(blocks(spans.get(x).in)) + ' / ' + JSON.stringify(blocks(spans.get(x2).out))).join(''));
  check('selected inflow and outflow line up at each middle node', middle.length === 1 && middle.every(([x, x2]) => JSON.stringify(blocks(spans.get(x).in)) === JSON.stringify(blocks(spans.get(x2).out))), true);
  await t.clearFilters(); await frame();

  // Keep routes together: picking a region moves nothing, and the selection still runs straight through
  const edges = sel => {   // every band edge, as "x:y" (rounded)
    const out = new Set();
    for (const p of fsvg().querySelectorAll(sel)) {
      const [x0, y0, , , , , x1, y1, , y1w, , , , , , y0w] = p.getAttribute('d').match(/-?[\d.]+/g).map(Number);
      for (const k of [[x0, y0], [x1, y1], ...(y0w - y0 > 0.55 ? [[x0, y0w], [x1, y1w]] : [])]) out.add(k);   // a hairline's drawn width isn't an edge
    }
    return out;
  };
  chart5.setOptions({ routes: true }); await frame();
  const before = edges('path.tarang-chart-flow');
  log.push(`INFO routes: ${fsvg().querySelectorAll('path.tarang-chart-flow').length} bands drawn`);
  await t.setState({ filters: { region: '=West' } }); await frame();
  const after = edges('path.tarang-chart-flow');
  check('routes: selecting moves nothing (no new band edges)', [...after].filter(([x, y]) => ![...before].some(([x2, y2]) => x2 === x && Math.abs(y2 - y) <= 0.2)).map(String), []);
  const rspans = new Map();
  for (const p of fsvg().querySelectorAll('path.tarang-chart-flow:not(.tarang-chart-flow-dim)')) {
    const [x0, y0, , , , , x1, y1, , y1w, , , , , , y0w] = p.getAttribute('d').match(/-?[\d.]+/g).map(Number);
    (rspans.get(x0) || rspans.set(x0, { in: [], out: [] }).get(x0)).out.push([y0, y0w]);
    (rspans.get(x1) || rspans.set(x1, { in: [], out: [] }).get(x1)).in.push([y1, y1w]);
  }
  const rmid = [...rspans.keys()].filter(x => rspans.get(x).in.length)
    .map(x => [x, [...rspans.keys()].find(x2 => x2 > x && x2 - x < 30 && rspans.get(x2).out.length)]).filter(([, x2]) => x2 != null);
  log.push('INFO routes, West picked, middle blocks in/out: ' + rmid.map(([x, x2]) => JSON.stringify(blocks(rspans.get(x).in)) + ' / ' + JSON.stringify(blocks(rspans.get(x2).out))).join(''));
  const near = (p, q) => p.length === q.length && p.every((r, i) => Math.abs(r[0] - q[i][0]) <= 1 && Math.abs(r[1] - q[i][1]) <= 1);
  check('routes: selection lines up through the middle nodes', rmid.length === 1 && near(blocks(rspans.get(rmid[0][0]).in), blocks(rspans.get(rmid[0][1]).out)), true);
  await t.clearFilters(); await frame();
  // clicking a strand picks its whole route
  const strand = fsvg().querySelector('g path.tarang-chart-flow');
  const sm = /^M([\d.]+) ([\d.]+)/.exec(strand.getAttribute('d'));
  moveSvg(+sm[1] + 15, +sm[2] + 0.5);
  log.push('INFO route hover: ' + [...document.querySelector('#flow1 .tarang-chart-tip').children].map(c => c.textContent).join(' | '));
  clickSvg(+sm[1] + 15, +sm[2] + 0.5); await new Promise(r => setTimeout(r, 80)); await frame();
  check('routes: a click filters every stage', Object.keys(t.getState().filters).sort(), ['product', 'region', 'status']);
  await t.clearFilters(); await frame();
  // the toggle is in the menu for flows only
  const menuHas = async label => {
    document.querySelector('#flow1 .tarang-chart-menu-btn').click(); await frame();
    const has = [...document.querySelectorAll('.tarang-chart-menu .tarang-chart-menu-toggle')].some(r => r.textContent.includes(label));
    document.querySelector('#flow1 .tarang-chart-menu-btn').click(); await frame();
    return has;
  };
  check('routes toggle in the flow menu', await menuHas('Keep routes together'), true);
  chart5.setOptions({ type: 'pie' }); await frame();
  check('no routes toggle on a pie', await menuHas('Keep routes together'), false);
  chart5.setOptions({ type: 'sankey', routes: false }); await frame();
  // a filter on another column (date) is followed, not ignored
  await t.setFilter('date', '2026-01'); await frame();
  check('follows a non-stage filter', /^\d+ rows/.test(fsub()) && !fsub().startsWith('69 rows'), true);
  await t.clearFilters(); await frame();
  // menu: stages, add, remove, colour by
  const fbtn = document.querySelector('#flow1 .tarang-chart-menu-btn');
  fbtn.click();
  check('flow menu rows', [...document.querySelectorAll('.tarang-chart-menu-label')].map(n => n.textContent),
    ['Chart', 'Stage 1', 'Stage 2', 'Stage 3', 'Add a stage', 'Colour by', 'Sized by', 'Most per stage']);
  [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'stage:add').click();
  const s = document.querySelector('.tarang-chart-menu-sub .tarang-chart-search');
  s.value = 'rating'; s.dispatchEvent(new Event('input')); key(s, 'Enter'); await frame();
  check('add a stage', F.options.stages, ['region', 'product', 'status', 'rating']);
  check('four stage headers', [...fsvg().querySelectorAll('.tarang-chart-stage')].length, 4);
  fbtn.click();
  [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'stage:1').click();
  [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-item')].find(i => i.textContent.includes('(remove this stage)')).click(); await frame();
  check('remove a stage', F.options.stages, ['region', 'status', 'rating']);
  fbtn.click();
  [...document.querySelectorAll('.tarang-chart-menu-row')].find(r => r.dataset.which === 'colorBy').click();
  [...document.querySelectorAll('.tarang-chart-menu-sub .tarang-chart-menu-item')].find(i => i.textContent.includes('status')).click(); await frame();
  check('colour by status: same colours as the pie', F.slices.every(sl => { const p = chart1.slices.find(x => x.name === sl.name); return !p || p.color === sl.color; }) && F.slices.some(sl => sl.name === 'delivered'), true);
  F.setOptions({ stages: ['region', 'product', 'status'], colorBy: null }); await frame();

  // Speed on a big table
  const big = document.createElement('div'); big.style.cssText = 'height:300px;width:900px'; document.body.appendChild(big);
  const pbox = document.createElement('div'); pbox.style.cssText = 'height:280px;width:520px'; document.body.appendChild(pbox);
  const bt = await TarangTable.create(big, { source: { sample: { rows: 1_000_000, cols: 12 } }, panel: false });
  let t0 = performance.now();
  const bp = TarangChart.pie(pbox, bt, { column: 'base_04' });
  const tFirst = performance.now() - t0;
  t0 = performance.now(); bp.setOptions({ column: 'count_03' }); const tNum = performance.now() - t0;
  await bt.setFilter('signal_01', '>0');
  t0 = performance.now(); bp.update(); const tFilt = performance.now() - t0;
  t0 = performance.now(); bp.setOptions({ type: 'line', x: 'signal_02', column: 'base_04', value: 'count_03' }); const tLine = performance.now() - t0;
  t0 = performance.now(); bp.update(); const tLine2 = performance.now() - t0;
  t0 = performance.now(); bp.setOptions({ type: 'column' }); const tCol = performance.now() - t0;
  // a binned number axis: clicking a column filters ">=a<b", and the table shows exactly that column's rows
  bp.setOptions({ value: null, column: null }); await frame();
  const bh = [...pbox.querySelectorAll('svg rect')].at(-1), br = bh.getBoundingClientRect();
  bh.dispatchEvent(new MouseEvent('click', { clientX: br.left + br.width * 0.505, clientY: br.top + 20, bubbles: true }));
  await new Promise(r => setTimeout(r, 300));
  const binFilter = bt.getState().filters.signal_02 || '';
  log.push(`INFO binned click: signal_02 ${JSON.stringify(binFilter)} -> ${bt.view.count()} rows`);
  check('binned click: a range filter', /^>=-?[\d.e-]+<-?[\d.e-]+$/.test(binFilter), true);
  await bt.clearFilters();
  t0 = performance.now(); bp.setOptions({ type: 'sankey', stages: ['base_04', 'call_08', 'base_12'], value: 'count_03' }); const tFlow = performance.now() - t0;
  log.push(`INFO 1M rows, flow through 3 stages: ${Math.round(tFlow)} ms, ${pbox.querySelectorAll('path.tarang-chart-flow').length} bands`);
  t0 = performance.now(); bp.setOptions({ routes: true }); const tRoutes = performance.now() - t0;
  log.push(`INFO 1M rows, flow with routes: ${Math.round(tRoutes)} ms, ${pbox.querySelectorAll('path.tarang-chart-flow').length} bands`);
  log.push(`INFO 1M rows, stacked columns (100 bins x ${bp.slices.length} parts): ${Math.round(tCol)} ms`);
  log.push(`INFO 1M rows, lines along a number column (binned) by a text column: first ${Math.round(tLine)} ms, redraw ${Math.round(tLine2)} ms, ${bp.slices.length} lines`);
  log.push(`INFO 1M rows: text column ${Math.round(tFirst)} ms, number column (${bp.slices.length} slices, ${bp.slices.at(-1).name}) ${Math.round(tNum)} ms, filtered redraw ${Math.round(tFilt)} ms`);

  // The treemap (revenue: region › product › status): drilling is the table's filters
  const tmEl = document.getElementById('tm1');
  const parents = () => [...tmEl.querySelectorAll('.tarang-chart-tm-parent')];
  const clickPart = g => { const r = g.querySelector('rect').getBoundingClientRect(); tmEl.querySelector('svg .tarang-chart-pickable').dispatchEvent(new MouseEvent('click', { clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, bubbles: true })); };
  await t.clearFilters(); await frame();
  check('treemap: a rectangle per region', parents().length, chart6.slices.length);
  const top = chart6.slices[0].name;
  clickPart(parents()[0]); await frame(); await T.wait(100);
  check('treemap: drilling filters the table', t.getState().filters, { region: '=' + top });
  check('treemap: breadcrumb', tmEl.querySelector('.tarang-chart-crumb-here').textContent, top);
  tmEl.querySelector('.tarang-chart-crumb-step').click(); await frame(); await T.wait(100);
  check('treemap: All climbs back', t.getState().filters, {});

  // Linked colours: charts that opt in take the table's colours (by row count), whatever they sum
  const colorsOf = ch => Object.fromEntries(ch.slices.filter(s => !s.other).map(s => [s.name, s.color]));
  chart1.setOptions({ type: 'pie', column: 'status', value: 'revenue', linkColors: false });
  const C1 = window.chart4; C1.setOptions({ column: 'status', value: null, linkColors: false }); await frame();
  const unlinked = colorsOf(chart1);
  log.push('INFO unlinked: pie of revenue ' + JSON.stringify(unlinked) + ' | columns of rows ' + JSON.stringify(colorsOf(C1)));
  chart1.setOptions({ linkColors: true }); C1.setOptions({ linkColors: true }); await frame();
  const linked = colorsOf(chart1);
  check('linked: pie colours are the table\'s', Object.entries(linked).every(([n, c]) => c === (t.colorOf('status', n) || '#5b6578')), true);
  check('linked: two charts summing different things agree', Object.entries(colorsOf(C1)).every(([n, c]) => !(n in linked) || linked[n] === c), true);
  // status has its own heat colours (the page's config): those are the shared ones
  check('a column\'s heat colours are its shared colours', [t.colorOf('status', 'delivered'), colorsOf(chart1).delivered], ['#3f8f5a', '#3f8f5a']);
  // region has none: the region with the most rows gets the palette's first colour
  const regionCounts = {};
  const regionColumn = t.model.allColumns.find(c => c.key === 'region');
  for (let r = 0; r < t.model.numRows; r++) { const v = regionColumn.raw(r); regionCounts[v] = (regionCounts[v] || 0) + 1; }
  const topRegion = Object.entries(regionCounts).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0][0];
  check('table colours: most rows first', t.colorOf('region', topRegion), TarangTable.PALETTE[0]);
  check('no colour for unknown values or number columns', [t.colorOf('status', 'nope'), t.colorOf('revenue', 1)], [null, null]);
  // fixing a colour: the charts follow, and the fixed colour isn't handed out twice
  t.setColors('status', { shipped: '#e66767' }); await frame(); await frame();
  check('fixed colour reaches the charts', [colorsOf(chart1).shipped, colorsOf(C1).shipped], ['#e66767', '#e66767']);
  const statusColors = ['delivered', 'shipped', 'processing', 'returned'].map(v => t.colorOf('status', v));
  check('fixed colour used once', statusColors.filter(c => c === '#e66767').length, 1);
  t.setColors('status', null); await frame(); await frame();
  // a rule: colours from a function; false for none; null leaves the value to the palette
  const others = Object.keys(regionCounts).filter(v => v !== topRegion).sort();
  t.setColorRule((key, v) => (key !== 'region' ? null : v === others[0] ? '#ffffff' : v === others[1] ? false : null));
  chart1.setOptions({ column: 'region' }); await frame(); await frame();
  check('rule: a colour, none, and the palette for the rest',
    [t.colorOf('region', others[0]), t.colorOf('region', others[1]), t.colorOf('region', topRegion)], ['#ffffff', null, TarangTable.PALETTE[0]]);
  check('rule reaches linked charts', colorsOf(chart1)[others[0]], '#ffffff');
  check('the column\'s heat colours beat the rule', (t.setColorRule(() => '#000000'), t.colorOf('status', 'delivered')), '#3f8f5a');
  t.setColorRule((key, v) => (key !== 'region' ? null : v === others[0] ? '#ffffff' : null));
  chart1.setOptions({ column: 'status' }); await frame(); await frame();
  t.setColors('status', { returned: '#123456' }); await frame();
  check('colors beat the rule', t.colorOf('status', 'returned'), '#123456');
  t.setColors('status', null);
  t.setColorRule((key, v) => { if (v === 'shipped') throw new Error('boom'); return null; });
  check('a throwing rule leaves the value to the palette', !!t.colorOf('status', 'shipped'), true);
  t.setColorRule(null); await frame(); await frame();
  check('opting out restores the chart\'s own colours', (chart1.setOptions({ linkColors: false }), JSON.stringify(colorsOf(chart1))), JSON.stringify(unlinked));
  C1.setOptions({ linkColors: false });
});
