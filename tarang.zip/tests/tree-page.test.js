// SPDX-License-Identifier: MIT
// Checks for tarang/tree.html, run inside the page (it loads this with ?test): the generated capture,
// the Frames table under the tree with its two tabs and charts, and how they link to the tree (filters, jumps,
// the address)
TT.run('Tree page: tree, Frames table, charts', async T => {
  const { check, ok, wait } = T;
  await T.until(() => typeof byFn !== 'undefined' && byFn && tree.model, 20000, 'the tree and its table');
  await wait(500);
  const M = tree.model, rows = () => byFn.model.numRows, scope = () => document.getElementById('scope').textContent;
  const col = k => byFn.model.allColumns.find(c => c.key === k || c.label === k);
  const sumExcl = () => { let s = 0; for (let r = 0; r < byFn.model.numRows; r++) s += col('excl bytes').raw(r); return s; };
  check('the sample: 100,000 nodes', M.n, 100000);
  check('the address keeps the sample', [new URLSearchParams(location.search).get('nodes'), !!new URLSearchParams(location.search).get('seed')], ['100000', true]);

  // ----- the two tabs -----
  check('first tab named after the root', document.getElementById('tabAll').textContent, 'Below main');
  const all = rows();
  // tag frames own their callees: nothing under a tag gets a row
  const isTagNode = i => M.fnDict[M.fn[i]].startsWith('TAG:');
  const underTag = i => { for (let p = M.parent[i]; p >= 0; p = M.parent[p]) if (isTagNode(p)) return true; return false; };
  let expected = 0, nested = 0;
  for (let i = 0; i < M.n; i++) { if (!underTag(i)) expected++; else if (isTagNode(i)) nested++; }
  ok('the sample has tag frames, some inside others', expected < M.n && nested > 0);
  check('a row per frame, but none under a tag', all, expected);
  check('whole capture: exclusive bytes add up to the total', Math.round(sumExcl()), Math.round(M.total[0]));
  const node = M.kids[M.kidsStart[M.roots[0]]];
  tree.select(node); await wait(500);
  check('whole capture ignores the selection', rows(), all);
  check('the address has the selection', new URLSearchParams(location.search).get('tree.sel'), tree.pathKey(node));
  document.querySelector('[data-scope="selection"]').click(); await wait(500);
  check('selection tab: below the node', [rows() < all, scope().startsWith('below ')], [true, true]);
  check('selection tab: adds up to its inclusive bytes', Math.round(sumExcl()), Math.round(M.inc[0][node]));
  tree.select(-1); await wait(500);
  check('nothing selected', [rows(), scope()], [0, 'Select rows in the tree']);

  // ----- table / chart filters -> the tree -----
  tree.select(node); await wait(600);
  const sys = M.tagSystemName[M.tag[node]];
  await byFn.setFilter('system', '=' + sys); await wait(300);
  check('a system filter on the table filters the tree', tree.filters, { system: '=' + sys });
  await byFn.setFilter('function', '=Core::Malloc'); await wait(300);
  check('a function filter too', tree.filters.function, '=Core::Malloc');
  tree.select(M.roots[0]); await wait(600);
  check('a new selection keeps the table\'s filters', byFn.getState().filters, { system: '=' + sys, function: '=Core::Malloc' });
  await byFn.clearFilters(); await wait(300);
  check('clearing the table clears the tree', tree.filters, {});
  ok('charts drawn', document.querySelectorAll('#pie svg path').length > 2 && document.querySelectorAll('#bars .tarang-chart-bar-row').length > 2);

  // ----- a table row -> that frame in the tree -----
  document.getElementById('tabAll').click(); await wait(500);
  const row = byFn.view.at(3);
  byFn.select(0, row); await wait(300);
  const jumped = tree.selected;
  check('a row click selects that frame in the tree', M.fnDict[M.fn[jumped]].replace(/^TAG:.*:/, ''), col('function').raw(row));
  ok('...with its path open', tree.pathOf(jumped).every(p => p === jumped || tree.lineNode(0) >= 0) && M.depth[jumped] > 0);
  T.info('jumped to depth ' + M.depth[jumped] + ': ' + tree.pathOf(jumped).map(p => M.fnDict[M.fn[p]]).join(' > '));
  document.querySelector('[data-scope="selection"]').click(); tree.select(M.roots[0]); await wait(600);
  const before = rows();
  byFn.select(0, byFn.view.at(5)); await wait(600);
  check('selection tab: a jump from the table keeps the table', rows(), before);
  document.getElementById('tabAll').click(); await wait(300);

  // ----- the Pinned tab: the pinned nodes, their comments and paths; kept in the browser -----
  const a = M.kids[M.kidsStart[M.roots[0]]], b = M.kids[M.kidsStart[a]];
  tree.setComment(a, 'look at this one'); tree.pin(b);
  check('the tab counts the pins', document.getElementById('tabPinned').textContent, 'Pinned (2)');
  document.getElementById('tabPinned').click(); await wait(600);
  check('Pinned tab: a row per pin', rows(), 2);
  const comments = Array.from({ length: rows() }, (_, r) => col('comment').raw(r));
  check('...with its comment', comments.sort(), ['', 'look at this one']);
  ok('...and its path', col('path').raw(0).startsWith(M.fnDict[M.fn[M.roots[0]]] + ' › '));
  tree.unpin(b); await wait(500);
  check('unpinning updates the tab', [rows(), document.getElementById('tabPinned').textContent], [1, 'Pinned (1)']);
  const stored = JSON.parse(localStorage.getItem(`tarang-tree-pins:100000:${new URLSearchParams(location.search).get('seed')}`) || '[]');
  check('pins are saved in the browser, by path', stored, [{ path: tree.pathKey(a), comment: 'look at this one' }]);
  tree.unpin(a); await wait(300);
  document.getElementById('tabAll').click(); await wait(300);

  // ----- tag frames (TAG:SYSTEM:name) -----
  {
    const tagRows = [];
    for (let r = 0; r < rows(); r++) if (isTagNode(rowNodes[r])) tagRows.push(r);
    ok('tag frames have rows', tagRows.length > 0);
    const r = tagRows[0], i = rowNodes[r];
    check('a tag row owns its subtree: exclusive = inclusive', [col('excl bytes').raw(r), col('excl allocs').raw(r)], [M.inc[0][i], M.inc[1][i]]);
    check('...shown by the part after the last ":"', col('function').raw(r), M.fnDict[M.fn[i]].split(':').pop());
    ok('no row is inside a tag', Array.from(rowNodes).every(j => !underTag(j)));
    check('the tree still shows the tag\'s own exclusive bytes', tree.model.exc[0][i] <= tree.model.inc[0][i], true);
    // a filter on the short name reaches the tree's whole name
    const short = col('function').raw(r);
    await byFn.setFilter('function', '=' + short); await wait(300);
    ok('a filter on a tag\'s name finds it in the tree', tree.filters.function.includes('=' + M.fnDict[M.fn[i]]));
    await byFn.clearFilters(); await wait(300);
    // the toggle: off gives every frame a row again (and says so in the address)
    const box = document.getElementById('tagsOwn');
    box.checked = false; box.dispatchEvent(new Event('change')); await wait(500);
    check('off: a row per frame', rows(), M.n);
    check('...kept in the address', new URLSearchParams(location.search).get('tags'), '0');
    check('...exclusive bytes still add up', Math.round(sumExcl()), Math.round(M.total[0]));
    box.checked = true; box.dispatchEvent(new Event('change')); await wait(500);
    check('back on', [rows(), new URLSearchParams(location.search).get('tags')], [expected, null]);
  }

  // ----- shared colours: the charts colour system and function; the tree's strips use the same colours -----
  await wait(300);
  check('linked columns: what the two charts colour', [...byFn.linkedColumns].sort(), ['function', 'system']);
  const ring = Object.fromEntries(pieChart.slices.filter(s => !s.other).map(s => [s.name, s.color]));
  const someSystem = Object.keys(ring).find(n => byFn.colorOf('system', n));
  check('ring colours are the table\'s', ring[someSystem], byFn.colorOf('system', someSystem));
  check('subsystem isn\'t coloured while no chart shows it', byFn.linkedColumns.has('subsystem'), false);
  pieChart.setOptions({ column: 'subsystem' }); await wait(300);
  check('switching the ring to subsystem links that instead', [...byFn.linkedColumns].sort(), ['function', 'subsystem']);
  pieChart.setOptions({ column: 'system' }); await wait(300);
});
