// SPDX-License-Identifier: MIT
// Checks for openlayers-mvp/index.html, run inside the page (it loads this with ?test): the map with its
// generated points and boxes, and the tarang-table under it, linked both ways (filters, clicks, selections, hover,
// dimming, a dropped CSV). Needs the network: OpenLayers comes from a CDN.
TT.run('Map page: map and table', async T => {
  const { check, ok, wait } = T;
  await T.until(() => typeof link !== 'undefined' && link && link.table, 30000, 'the map and its table');
  await wait(800);
  const t = link.table;
  // total alpha drawn on the WebGL data canvas (the second; the pulse canvas is the last)
  const alpha = () => new Promise(res => {
    rm.map.once('rendercomplete', () => {
      const c = rm.map.getViewport().querySelectorAll('canvas')[1];
      const k = document.createElement('canvas'); k.width = c.width; k.height = c.height; const x = k.getContext('2d'); x.drawImage(c, 0, 0);
      const d = x.getImageData(0, 0, k.width, k.height).data; let s = 0; for (let i = 3; i < d.length; i += 4) s += d[i]; res(Math.round(s / 255));
    });
    rm.map.render();
  });
  check('one table row per point and box', t.model.numRows, 110000);
  const a0 = await alpha();
  ok('points drawn', a0 > 1000, String(a0));

  // ----- hovering a table row dims the rest of the map (dimOnHover) -----
  const sc = document.querySelector('#table .tarang-scroller'), r = sc.getBoundingClientRect();
  sc.dispatchEvent(new MouseEvent('mousemove', { clientX: r.left + 160, clientY: r.top + 70, bubbles: true }));
  await wait(200);
  const hovered = t.hoveredRow, a1 = await alpha();
  sc.dispatchEvent(new MouseEvent('mouseleave'));
  await wait(200);
  const a2 = await alpha();
  ok('hovering a row dims the map', hovered >= 0 && a1 < a0 * 0.7, `hoveredRow ${hovered}, alpha ${a0} → ${a1}`);
  ok('leaving the table brightens it again', Math.abs(a2 - a0) < a0 * 0.05, `alpha ${a0} → ${a2}`);

  // ----- table filter -> map -----
  await t.setFilter('category', '=Alpha'); await wait(400);
  check('the map shows only the filtered rows', document.querySelector('[data-stat="Shown"]').textContent, `${t.view.count().toLocaleString()} of 110,000`);
  ok('fewer drawn after filtering', (await alpha()) < a0 * 0.6);
  await t.clearFilters(); await wait(400);
  check('clearing the filter shows all', document.querySelector('[data-stat="Shown"]').textContent, 'all');

  // ----- map click -> table row; Ctrl+click adds -----
  const clickAt = (pt, ctrl = false) => rm.map.dispatchEvent({ type: 'singleclick', coordinate: [pt.x, pt.y], pixel: rm.map.getPixelFromCoordinate([pt.x, pt.y]), originalEvent: new MouseEvent('click', { ctrlKey: ctrl }) });
  const p = rm.data.points[1234];
  rm.map.getView().setCenter([p.x, p.y]); rm.map.getView().setZoom(14); rm.map.renderSync();
  clickAt(p); await wait(300);
  const sel = t.selectedRows;
  ok('a clicked point selects its row', sel.length === 1 && Math.abs(rm.data.points[sel[0]].x - p.x) < 50, JSON.stringify(sel));
  const near = rm.data.points.findIndex((q, i) => i !== sel[0] && Math.hypot(q.x - p.x, q.y - p.y) > 30 && Math.hypot(q.x - p.x, q.y - p.y) < 400);
  if (near >= 0) {
    clickAt(rm.data.points[near], true); await wait(300);
    check('Ctrl+click adds another', t.selectedRows.length, 2);
  }
  ok('a selection dims the rest (no pulse on this page)', (await alpha()) < a0 * 0.8);

  // ----- table -> map -----
  t.select(1, 100000 + 7); await wait(300);
  ok('a cell click selects that box on the map', /TypeBox\s*ID7/.test(document.querySelector('.rm-details').textContent.replace(/\s+/g, '')));
  t.selectRows([3, 4, 5, 100001]); await wait(300);
  ok('selected rows are highlighted on the map', document.querySelector('.rm-details').textContent.includes('4 rows selected in the table'));
  check('the map does not echo it back', t.selectedRows.length, 4);
  t.clearRowSelection(); await wait(200);
  ok('clearing the table selection clears the map', document.querySelector('.rm-details').textContent.startsWith('Click a feature'));
  rm.highlight([10, 11, 12], [0]); await wait(300);
  check('a map-side selection selects the rows', t.selectedRows.slice().sort((a, b) => a - b), [10, 11, 12, 100000]);

  // ----- a dropped CSV: the table reloads, keeping what still fits -----
  await t.setSort('value', -1); await t.setFilter('value', '>500'); await wait(300);
  const dt = new DataTransfer();
  dt.items.add(new File(['id,x,y,category,value,owner\nA,100,100,Kilo,900,Ana\nB,200,200,Lima,100,Ben\nC,300,300,Kilo,700,Cho\n'], 'three.csv'));
  document.querySelector('.rm-map').dispatchEvent(new DragEvent('drop', { dataTransfer: dt, bubbles: true, cancelable: true }));
  await wait(1500);
  check('the table reloads from the CSV (boxes kept)', t.model.numRows, 3 + 10000);
  ok('its extra column comes along', t.columns.some(c => c.key === 'owner'));
  check('the filter is kept', t.getState().filters, { value: '>500' });
  check('the map follows it', document.querySelector('[data-stat="Shown"]').textContent, `${t.view.count().toLocaleString()} of 10,003`);
});
