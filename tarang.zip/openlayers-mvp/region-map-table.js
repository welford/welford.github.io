// SPDX-License-Identifier: MIT
/* region-map-table.js: a tarang-table of a RegionMap's points and boxes, linked to the map both ways
 *
 * Needs region-map.js and tarang-table.js (+ tarang-table.css) loaded first.
 *
 *   const link = await RegionMapTable.attach(rm, document.getElementById('table'), {
 *     filterMap: true,       // the map shows only the rows the table's filters let through
 *     table: { … },          // any other TarangTable.create options (title, totals, groupBy, urlState, …)
 *   });
 *   link.table               the TarangTable
 *   link.refresh()           rebuild the table from the map's data (done by itself when the map's data changes)
 *   link.destroy()           unlink and remove the table (the map stays)
 *
 * One row per point, then one per box. Columns: kind, id, category (in the map's colour), value, x, y for
 * points, x0, y0, x1, y1 for boxes, then every other field the data has (numbers when every value is one).
 * Columns a dataset doesn't use are left out.
 *
 * What is linked:
 *   table filters          → the map draws (and counts in regions) only the rows that pass
 *   click a cell           → that point / box is selected on the map, which pans to it if it's off screen
 *   select rows            → highlighted on the map (row numbers: click, Shift+click, drag, Ctrl/⌘+click)
 *   hover a row            → that feature is hovered on the map (with the map's dimOnHover, the rest dims)
 *   click a feature on map → its row is selected and scrolled to
 *   Shift+drag on the map  → the rows inside are selected (the table's ⤓ can save them)
 *   Ctrl/⌘+click on map    → that row is added to (or taken out of) the selected rows
 *   new data on the map    → the table reloads (a CSV dropped on the map, rm.setData, …)
 */
(function () {
'use strict';

const BASE = ['kind', 'id', 'category', 'value', 'x', 'y', 'x0', 'y0', 'x1', 'y1'];
const OWN = new Set(['x', 'y', 'x0', 'y0', 'x1', 'y1', 'cat', 'id', 'value']);   // fields read by name, not copied

// The map's data as tarang-table columns: { columns, rowCount }
function buildData(rm) {
  const { points, boxes } = rm.data;
  const nP = points.length, n = nP + boxes.length;
  const item = r => (r < nP ? points[r] : boxes[r - nP]);
  const text = (name, get) => {
    const dict = [''], index = new Map([['', 0]]), codes = new Uint32Array(n);
    for (let r = 0; r < n; r++) {
      const v = get(r, item(r));
      if (v == null || v === '') continue;
      const s = String(v);
      let c = index.get(s);
      if (c === undefined) { c = dict.length; dict.push(s); index.set(s, c); }
      codes[r] = c;
    }
    return TarangTable.textData(name, codes, dict);
  };
  const number = (name, get, most = 3) => {
    const values = new Float64Array(n).fill(NaN);
    let decimals = 0;
    for (let r = 0; r < n; r++) {
      const v = get(r, item(r));
      if (typeof v !== 'number' || !Number.isFinite(v)) continue;
      values[r] = v;
      if (decimals < most && !Number.isInteger(v)) {   // as many as the data uses, up to `most`
        while (decimals < most && Math.abs(v * 10 ** decimals - Math.round(v * 10 ** decimals)) > 1e-9) decimals++;
      }
    }
    return TarangTable.numberData(name, values, decimals);
  };
  const any = (list, test) => list.some(test);
  const all = [points, boxes];

  const columns = [text('kind', r => (r < nP ? 'point' : 'box'))];
  if (all.some(l => any(l, d => d.id != null && d.id !== ''))) columns.push(text('id', (r, d) => d.id));
  columns.push(text('category', (r, d) => rm.categoryOf(d.cat).name));
  if (all.some(l => any(l, d => typeof d.value === 'number'))) columns.push(number('value', (r, d) => d.value));
  // Coordinates: at most 2 decimals
  if (nP) { columns.push(number('x', (r, d) => (r < nP ? d.x : NaN), 2), number('y', (r, d) => (r < nP ? d.y : NaN), 2)); }
  if (boxes.length) for (const k of ['x0', 'y0', 'x1', 'y1']) columns.push(number(k, (r, d) => (r >= nP ? d[k] : NaN), 2));

  // Every other field: a number column when each value is a number (or text that reads as one), else text
  const extra = new Set();
  for (const l of all) for (const d of l) for (const k in d) if (!OWN.has(k)) extra.add(k);
  for (const k of extra) {
    if (BASE.includes(k)) continue;   // never shadow the columns above
    let numeric = true, seen = false;
    for (let r = 0; r < n && numeric; r++) {
      const v = item(r)[k];
      if (v == null || v === '') continue;
      seen = true;
      if (typeof v !== 'number' && !(typeof v === 'string' && v.trim() !== '' && Number.isFinite(Number(v)))) numeric = false;
    }
    columns.push(numeric && seen ? number(k, (r, d) => (d[k] == null || d[k] === '' ? NaN : Number(d[k]))) : text(k, (r, d) => d[k]));
  }
  return { columns, rowCount: n };
}

async function attach(rm, element, { filterMap = true, table: tableOptions = {} } = {}) {
  if (!window.TarangTable) throw new Error('RegionMapTable needs tarang-table.js loaded first');
  let nP = rm.data.points.length;
  let applying = false;   // changes we are making ourselves, so their echoes are ignored
  const quietly = fn => { applying = true; try { return fn(); } finally { applying = false; } };
  const rowOf = (kind, index) => (kind === 'box' ? nP + index : index);
  const featureOf = r => (r < nP ? ['point', r] : ['box', r - nP]);

  const transform = () => {
    const data = buildData(rm);
    return {
      data,
      transform: {
        // Heatmap colouring only on value (shading kinds, names or coordinates says nothing); categories get
        // their map colour as a tint instead
        columns: data.columns.map(c => (c.name === 'category'
          ? { source: 'category', heat: false, render: cell => ({ text: cell.display, background: rm.categoryOf(cell.value).color + '59' }) }
          : { source: c.name, heat: c.name === 'value' })),
        // Clicking any cell selects that point / box on the map
        onCellClick: cell => {
          const [kind, index] = featureOf(cell.rowIndex);
          quietly(() => rm.selectFeature(kind, index, { silent: true }));
        },
      },
    };
  };

  const first = transform();
  const table = await TarangTable.create(element, {
    title: 'Map data', panel: false, fileLoading: false, ...tableOptions,
    source: { data: first.data, label: 'the map' },
    transform: first.transform,
  });

  // Table filters → what the map draws
  function pushFilter() {
    if (!filterMap) return;
    const v = table.view, n = table.model.numRows, nB = n - nP;
    if (v.count() === n) { rm.setShown(null, null); return; }
    const pm = new Uint8Array(nP), bm = new Uint8Array(nB);
    for (let p = 0, c = v.count(); p < c; p++) { const r = v.at(p); if (r < nP) pm[r] = 1; else bm[r - nP] = 1; }
    rm.setShown(pm, bm);
  }

  const offTable = table.onChange(({ type }) => {
    if (type === 'load' || type === 'filter' || type === 'state') pushFilter();
    // The row under the pointer → that feature hovered on the map (white, and the rest dimmed with dimOnHover)
    if (type === 'hover') { const r = table.hoveredRow; rm.hover(...(r >= 0 && r < table.model.numRows ? featureOf(r) : [null])); }
    if (type === 'selection' && !applying) {
      // Rows picked in the table → highlighted on the map
      const rows = table.selectedRows, pi = [], bi = [];
      for (const r of rows) (r < nP ? pi : bi).push(r < nP ? r : r - nP);
      quietly(() => (rows.length
        ? rm.highlight(pi, bi, { silent: true, label: `${rows.length.toLocaleString()} row${rows.length === 1 ? '' : 's'} selected in the table` })
        : rm.clearSelection({ silent: true })));
    }
  });

  // The map's selection → the table's
  const offSelect = rm.on('select', sel => {
    if (applying) return;
    if (!sel) { quietly(() => table.clearRowSelection()); return; }
    let rows = [];
    if (sel.kind === 'point' || sel.kind === 'box') rows = [rowOf(sel.kind, sel.index)];
    else rows = [...(sel.pointIndexes || []), ...(sel.boxIndexes || []).map(i => nP + i)];
    quietly(() => table.selectRows(rows));
    const focus = sel.added ? rowOf(sel.added.kind, sel.added.index) : rows[0];   // a Ctrl/⌘+click: the row it added
    if (rows.length && focus != null) table.scrollToRow(focus);
  });

  // New data on the map → reload the table (keeping its sort and filters where the columns still exist)
  async function refresh() {
    const state = table.getState();
    nP = rm.data.points.length;
    const next = transform();
    await table.load({ data: next.data, label: 'the map' }, { transform: next.transform });
    table.setState(state);
    pushFilter();
  }
  const offData = rm.on('data', () => { refresh(); });

  pushFilter();
  return {
    table,
    refresh,
    destroy() {
      offTable(); offSelect(); offData();
      rm.setShown(null, null);
      table.destroy();
    },
  };
}

window.RegionMapTable = { attach, buildData };
})();
