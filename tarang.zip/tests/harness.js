// SPDX-License-Identifier: MIT
/* harness.js: the small test harness every test page uses.
 *
 *   <script src="harness.js"></script>            (from a page in tests/; demo pages load it with ?test)
 *   TT.run('Tarang table', async t => {
 *     t.check('sorted', got, want);               // passes when JSON.stringify(got) === JSON.stringify(want)
 *     t.ok('drawn', canvas.width > 0);
 *     t.info('1M rows in ' + ms + ' ms');         // shown with the results, never a failure
 *     await t.wait(100); await t.frame(); await t.until(() => window.thing, 5000);
 *     t.click(el, { x, y, ctrlKey }); t.key(el, 'ArrowDown', { shiftKey: true });
 *   });
 *
 * Errors the page throws (and promises it leaves rejected) count as failures. A page shows its own results
 * when opened on its own; inside tests/index.html it reports them to the runner (postMessage), and
 * window.__result (a promise) gives them to a headless run (run.ps1).
 */
(function () {
'use strict';
const results = [];   // { status: 'pass' | 'fail' | 'info', name, detail }
let done = false, settle;
window.__result = new Promise(r => { settle = r; });

addEventListener('error', e => { if (!done) results.push({ status: 'fail', name: 'Page error', detail: `${e.message} (${(e.filename || '').split('/').pop()}:${e.lineno})` }); });
addEventListener('unhandledrejection', e => { if (!done) results.push({ status: 'fail', name: 'Unhandled rejection', detail: String(e.reason && e.reason.stack || e.reason) }); });

const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const show = v => { try { return JSON.stringify(v); } catch { return String(v); } };
const t = {
  check(name, got, want) {
    const ok = same(got, want);
    results.push(ok ? { status: 'pass', name } : { status: 'fail', name, detail: `got ${show(got)}, want ${show(want)}` });
    return ok;
  },
  ok(name, cond, detail = '') {
    results.push(cond ? { status: 'pass', name } : { status: 'fail', name, detail: detail || 'was false' });
    return !!cond;
  },
  info(text) { results.push({ status: 'info', name: String(text) }); },
  // the old tests' log.push('INFO …') / ('ERRORS [...]') lines
  log: {
    push(line) {
      const s = String(line);
      if (/^ERRORS? /.test(s)) { const rest = s.replace(/^ERRORS? /, ''); if (rest !== '[]') results.push({ status: 'fail', name: 'Errors', detail: rest }); }
      else results.push({ status: 'info', name: s.replace(/^INFO /, '') });
    },
  },
  wait: ms => new Promise(r => setTimeout(r, ms)),
  frame: () => new Promise(r => requestAnimationFrame(() => setTimeout(r, 20))),
  async until(fn, ms = 10000, what = 'the page to be ready') {
    const end = Date.now() + ms;
    for (;;) {
      const v = fn();
      if (v) return v;
      if (Date.now() > end) throw new Error(`Timed out waiting for ${what}`);
      await t.wait(50);
    }
  },
  click(el, { x, y, ...mods } = {}) {
    const r = el.getBoundingClientRect();
    const o = { clientX: r.left + (x ?? r.width / 2), clientY: r.top + (y ?? r.height / 2), bubbles: true, cancelable: true, button: 0, ...mods };
    el.dispatchEvent(new MouseEvent('click', o));
  },
  key(el, key, mods = {}) { el.dispatchEvent(new KeyboardEvent('keydown', { key, bubbles: true, cancelable: true, ...mods })); },
};

async function run(name, fn) {
  const t0 = performance.now();
  try { await fn(t); } catch (err) { results.push({ status: 'fail', name: 'Exception', detail: String(err && err.stack || err) }); }
  await t.wait(50);   // errors thrown by timers the test started
  done = true;
  releaseWebGL();
  const summary = {
    name, ms: Math.round(performance.now() - t0),
    pass: results.filter(r => r.status === 'pass').length,
    fail: results.filter(r => r.status === 'fail').length,
    results,
  };
  settle(summary);
  if (window.parent !== window) window.parent.postMessage({ type: 'tarang-test-done', summary }, '*');
  else render(summary);
  return summary;
}

// Browsers keep only ~16 WebGL contexts alive at once, and a map holds several: when a page's checks are done,
// let its contexts go, so the pages run after it (tests/index.html) can have theirs. Only in the runner: a page
// opened on its own stays usable
function releaseWebGL() {
  if (window.parent === window) return;
  const lose = gl => { const ext = gl && gl.getExtension('WEBGL_lose_context'); if (ext) ext.loseContext(); };
  for (const c of document.querySelectorAll('canvas')) {
    try {
      if (c.getContext('2d')) continue;   // a 2D canvas (asking never makes a WebGL one): only WebGL ones give null
      lose(c.getContext('webgl2') || c.getContext('webgl'));
    } catch { /* not a canvas we can reach */ }
  }
}

// Opened on its own: the results over the page
function render(s) {
  const esc = v => String(v).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]);
  const box = document.createElement('div');
  box.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:99999;max-width:560px;max-height:60vh;overflow:auto;background:#171b23;'
    + 'color:#e6e8ec;border:1px solid #46506a;border-radius:8px;padding:10px 12px;font:12px/1.5 system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.5)';
  box.innerHTML = `<b style="color:${s.fail ? '#ff8a8a' : '#6fd3a8'}">${esc(s.name)}: ${s.pass} passed, ${s.fail} failed</b> <span style="color:#8b93a3">${s.ms} ms</span>`
    + s.results.map(r => `<div style="color:${r.status === 'fail' ? '#ff8a8a' : r.status === 'info' ? '#8b93a3' : '#e6e8ec'}">`
      + `${r.status === 'pass' ? '✓' : r.status === 'fail' ? '✗' : '·'} ${esc(r.name)}${r.detail ? `<br><code style="white-space:pre-wrap">${esc(r.detail)}</code>` : ''}</div>`).join('');
  document.body.appendChild(box);
}

window.TT = { run, ...t };
})();
