<#
  run.ps1: runs the test suites in headless Edge (Chrome works too) and prints the results.

    .\tests\run.ps1                       every suite, each in its own browser
    .\tests\run.ps1 -Only tree,map        just these groups (or suites with these words in their names)
    .\tests\run.ps1 -Page tests\tree-model.test.html     one page on its own (demo pages: add ?test)
    .\tests\run.ps1 -SameBrowser          all suites in one browser, as tests/index.html runs them
    .\tests\run.ps1 -ShowInfo             also print the timings and notes the tests log

  Each suite gets a fresh browser by default: some build a million rows, and the maps hold WebGL contexts that
  a browser only keeps ~16 of, so suites sharing one browser slow each other down.
  Exit code 0 when everything passed, 1 when anything failed (or didn't finish), so it can gate a commit or a
  build. The map suites load OpenLayers from a CDN, so they need the network.
#>
param(
  [string[]]$Only = @(),
  [string]$Page = '',
  [switch]$SameBrowser,
  [switch]$ShowInfo,
  [int]$TimeoutSec = 300,
  [int]$Port = 9444,
  [string]$Browser = ''
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot   # the folder holding tests/, tarang/, openlayers-mvp/

if (-not $Browser) {
  $Browser = @(
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
  ) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  if (-not $Browser) { throw 'No Edge or Chrome found: pass -Browser <path to the exe>' }
}
$fileUrl = { param($rel) 'file:///' + ((Join-Path $root $rel) -replace '\\', '/') }

# Opens a page in a fresh headless browser and returns what its window.__result settles with
function Invoke-Page([string]$url) {
  $profileDir = Join-Path $env:TEMP ('tarang-tests-' + (Get-Random))
  $browserArgs = @('--headless=new', '--disable-gpu', '--allow-file-access-from-files', "--remote-debugging-port=$Port",
    "--user-data-dir=$profileDir", '--window-size=1400,1000', '--no-first-run', $url)
  $proc = Start-Process $Browser -ArgumentList $browserArgs -PassThru
  try {
    $ws = $null
    for ($i = 0; $i -lt 100 -and -not $ws; $i++) {
      Start-Sleep -Milliseconds 300
      try {
        $pages = @(Invoke-RestMethod "http://127.0.0.1:$Port/json" | ForEach-Object { $_ }) | Where-Object { $_.type -eq 'page' }
        $pg = $pages | Where-Object { $_.url -like 'file:*' } | Select-Object -First 1
        if ($pg) { $ws = [string]$pg.webSocketDebuggerUrl }
      } catch {}
    }
    if (-not $ws) { throw 'The browser did not open the page' }
    $sock = New-Object System.Net.WebSockets.ClientWebSocket
    $sock.ConnectAsync([Uri]$ws, [Threading.CancellationToken]::None).Wait()
    Start-Sleep -Milliseconds 500
    # pages that load scripts from a CDN start their tests late: wait up to a minute for them to begin
    $expr = '(async () => { for (let i = 0; i < 600 && !window.__result; i++) await new Promise(r => setTimeout(r, 100));' +
      ' if (!window.__result) return JSON.stringify({ name: location.pathname.split("/").pop(), pass: 0, fail: 1, ms: 0,' +
      ' results: [{ status: "fail", name: "The tests never started", detail: "No harness on the page: is ?test missing, or did a script fail to load?" }] });' +
      ' return JSON.stringify(await window.__result); })()'
    $msg = '{"id":1,"method":"Runtime.evaluate","params":{"expression":' + (ConvertTo-Json $expr) + ',"awaitPromise":true,"returnByValue":true}}'
    $bytes = [Text.Encoding]::UTF8.GetBytes($msg)
    $sock.SendAsync([ArraySegment[byte]]$bytes, 'Text', $true, [Threading.CancellationToken]::None).Wait()
    $buf = New-Object byte[] 1048576
    $sb = New-Object Text.StringBuilder
    $cts = New-Object Threading.CancellationTokenSource ($TimeoutSec * 1000)
    do {
      $r = $sock.ReceiveAsync([ArraySegment[byte]]$buf, $cts.Token); $r.Wait()
      [void]$sb.Append([Text.Encoding]::UTF8.GetString($buf, 0, $r.Result.Count))
    } while (-not $r.Result.EndOfMessage)
    $reply = $sb.ToString() | ConvertFrom-Json
    if ($reply.result.exceptionDetails) { throw ('The page failed: ' + $reply.result.exceptionDetails.text) }
    return ($reply.result.result.value | ConvertFrom-Json)
  } finally {
    try { Stop-Process -Id $proc.Id -Force } catch {}
    Start-Sleep -Milliseconds 400
    Remove-Item -Recurse -Force $profileDir -ErrorAction SilentlyContinue
  }
}

function Show-Suite($s) {
  $mark = if ($s.fail) { 'FAIL' } else { ' ok ' }
  $color = if ($s.fail) { 'Red' } else { 'Green' }
  Write-Host ("[{0}] {1,-44} {2,4} passed {3,3} failed  {4,7} ms" -f $mark, $s.name, $s.pass, $s.fail, $s.ms) -ForegroundColor $color
  foreach ($t in $s.results) {
    if ($t.status -eq 'fail') { Write-Host ("        x {0}" -f $t.name) -ForegroundColor Red; if ($t.detail) { Write-Host ("          {0}" -f $t.detail) -ForegroundColor DarkRed } }
    elseif ($t.status -eq 'info' -and $ShowInfo) { Write-Host ("        . {0}" -f $t.name) -ForegroundColor DarkGray }
  }
}

$suites = @()
if ($Page) {
  $suites = @(Invoke-Page (& $fileUrl $Page))
  Show-Suite $suites[0]
} elseif ($SameBrowser) {
  $url = (& $fileUrl 'tests\index.html') + $(if ($Only.Count) { '?only=' + [uri]::EscapeDataString($Only -join ',') } else { '' })
  $res = Invoke-Page $url
  $suites = @($res.suites)
  $suites | ForEach-Object { Show-Suite $_ }
} else {
  # the list from tests/index.html, then each suite in its own browser
  $list = @((Invoke-Page ((& $fileUrl 'tests\index.html') + '?list')).list)
  $wanted = @($Only | ForEach-Object { $_.ToLower() })
  if ($wanted.Count) { $list = @($list | Where-Object { $n = $_.name.ToLower(); $g = $_.group; ($wanted -contains $g) -or ($wanted | Where-Object { $n.Contains($_) }) }) }
  if (-not $list.Count) { Write-Host 'No suites match.' -ForegroundColor Yellow; exit 1 }
  foreach ($item in $list) {
    try { $res = Invoke-Page ((& $fileUrl 'tests\index.html') + "?suite=$($item.index)"); $s = $res.suites[0] }
    catch { $s = [pscustomobject]@{ name = $item.name; pass = 0; fail = 1; ms = 0; results = @([pscustomobject]@{ status = 'fail'; name = 'Run failed'; detail = "$_" }) } }
    $suites += $s
    Show-Suite $s
  }
}

$failed = ($suites | Measure-Object -Property fail -Sum).Sum
$passed = ($suites | Measure-Object -Property pass -Sum).Sum
Write-Host ''
if ($failed) { Write-Host "$failed failed, $passed passed ($($suites.Count) suites)" -ForegroundColor Red; exit 1 }
Write-Host "All $passed checks passed ($($suites.Count) suites)" -ForegroundColor Green
exit 0
