// SPDX-License-Identifier: MIT
/* tarang-diff.js: compare two CSVs with the same layout, rows matched on a key column, shown in a TarangTable.
 * Needs tarang-table.js (and tarang-table.css) loaded first.
 *
 *   const diff = await TarangDiff.create(containerElement, {
 *     before: { url: 'march.csv' },        // { csv: text } | { url } | { file } | text | { data } (parsed already)
 *     after:  { url: 'april.csv' },
 *     key: 'id',                           // the column rows are matched on; each key must be unique in both files
 *     rename: { cost: 'price' },           // before-name -> after-name, for columns renamed between the files
 *     columns: {                           // per column (by its after-name), all optional:
 *       price: { tolerance: 0.01 },        //   numbers: equal when |after − before| <= tolerance
 *       total: { tolerance: '0.5%' },      //   ... or within a percentage of the before value
 *       name:  { ignoreCase: true, trim: true },          // text
 *       notes: { ignore: true },           //   shown, but not compared
 *       stamp: { equal: (after, before) => boolean },     // full control (raw values: number, string or null)
 *       qty:   { label, format, width, align, total, … }  // anything a TarangTable column takes
 *     },
 *     deltas: true,                        // per compared number column, hidden: "Δ price" (after − before) and
 *                                          //   "|Δ| price" (its size, to sort by the biggest changes either way);
 *                                          //   or ['diff'] / ['abs'] for one, false for none (also per column)
 *     look: { added: '#17352a', removed: { color: '#9aa2b1', strike: true }, changed: { background, color },
 *             addedColumn, removedColumn },   // colours: a colour alone is the background (the rest kept)
 *     deltaColors: { up: '#ff8a8a', down: '#6fd3a8' },   // Δ text by direction (true: these) instead of the
 *                                          //   default heatmap around 0
 *     table: { title, totals, groupBy, … },   // TarangTable.create options
 *   });
 *   diff.table                             the TarangTable (filters, grouping, totals, downloads … as usual)
 *   diff.summary                           { rows, same, changed, added, removed, changedByColumn,
 *                                            columns: { compared, added, removed, renamed, ignored }, ms }
 *   diff.show('all' | 'changes' | 'changed' | 'added' | 'removed' | 'same')   filters the status column
 *   diff.setOptions({ key, rename, columns, deltas, look, deltaColors, before, after })   compares again with new settings;
 *                                          the files are kept unless before / after are given, and so are the
 *                                          table's sort, filters and grouping
 *   diff.destroy()
 *   TarangDiff.compare(before, after, options) -> { data, transform, summary }
 *     the comparison alone: before / after are parsed tables (TarangTable.parseCsv); data is a { data } source
 *
 * One row per key: status (same / changed / added / removed), then every column holding the after value (the
 * before value on removed rows), and "changes", which lists the columns that changed in that row. Rows keep the
 * after file's order, with removed rows where they were in the before file. Changed cells read "before → after"
 * on yellow; added rows are green; removed rows are red and struck through. Sorting, filters and totals use the
 * after values. Each compared column `price` also has a hidden `price.before` ("price (before)" in the column
 * chooser) and, for numbers, `price.delta` and `price.absdelta`. Columns found in only one file are shown and marked, not compared.
 * Problems (duplicate or empty keys, unknown columns) throw an Error; create() also shows the message.
 */
(function () {
'use strict';
// Missing numbers are NaN, as in tarang-table: `v === v` reads "v has a value" and `v !== v` "v is missing"
// (NaN is the only value not equal to itself)

const SAME = 1, CHANGED = 2, ADDED = 3, REMOVED = 4;
const STATUS_DICT = ['', 'same', 'changed', 'added', 'removed'];
const DEFAULT_LOOK = {
  changed: { background: '#3a3418', color: '#ffe08a' },
  added: { background: '#17352a' },
  removed: { background: '#3a1d22', color: '#9aa2b1', strike: true },
  addedColumn: { background: '#162b23' },
  removedColumn: { background: '#2c1a1e', color: '#9aa2b1' },
};
// The look option: per part, a colour alone (its background) or { background, color, strike, … } over the default
function lookFor(given = {}) {
  const out = {};
  for (const k of Object.keys(DEFAULT_LOOK)) {
    const g = given[k];
    out[k] = typeof g === 'string' ? { ...DEFAULT_LOOK[k], background: g } : { ...DEFAULT_LOOK[k], ...(g || {}) };
  }
  return out;
}
const BLANK = '—';   // an empty value in "before → after"
const DIFF_KEYS = ['tolerance', 'ignoreCase', 'trim', 'ignore', 'equal', 'deltas'];   // column options for the comparison only

// ---------------------------------------------------------------------------
// Reading
// ---------------------------------------------------------------------------
async function readSource(source) {
  if (!source) throw new Error('missing a before or after source');
  if (Array.isArray(source.columns)) return source;   // parsed already
  if (source.data) return typeof source.data === 'function' ? source.data() : source.data;
  let text;
  if (typeof source === 'string') text = source;
  else if (typeof source === 'function') text = await source();
  else if (source.csv != null) text = source.csv;
  else if (source.file) text = await source.file.text();
  else if (source.url) {
    const r = await fetch(source.url);
    if (!r.ok) throw new Error(`${source.url}: ${r.status} ${r.statusText}`);
    text = await r.text();
  } else throw new Error('a source needs csv, url, file or data');
  return TarangTable.parseCsv(text);
}
const sourceLabel = s => (s && (s.label || (s.file && s.file.name) || (s.url && s.url.split('/').pop()))) || 'CSV';

// ---------------------------------------------------------------------------
// Values
// ---------------------------------------------------------------------------
// A number as the table writes it (see col.plain in tarang-table.js)
function plainNumber(v, decimals, trim) {
  if (v !== v) return '';
  if (decimals <= 0) return String(v);
  const s = v.toFixed(decimals);
  return trim ? s.replace(/\.?0+$/, '') : s;
}
// i => value as a string ('' when empty)
const textOf = d => (d.type === 'number' ? i => plainNumber(d.values[i], d.decimals, d.trim) : i => d.dict[d.codes[i]]);
// i => raw value: number, string, or null when empty
const rawOf = d => (d.type === 'number' ? i => (d.values[i] === d.values[i] ? d.values[i] : null) : i => d.dict[d.codes[i]] || null);

// Interning strings into a dictionary with '' as code 0
function dictBuilder() {
  const dict = [''], index = new Map([['', 0]]);
  const code = s => {
    let c = index.get(s);
    if (c === undefined) { c = dict.length; index.set(s, c); dict.push(s); }
    return c;
  };
  return { dict, code };
}

// (afterRow, beforeRow) => true when the two count as the same
function equality(name, a, b, opt) {
  if (typeof opt.equal === 'function') {
    const va = rawOf(a), vb = rawOf(b);
    return (i, j) => {
      try { return !!opt.equal(va(i), vb(j)); }
      catch (err) { throw new Error(`columns.${name}.equal: ${err.message}`); }
    };
  }
  if (a.type === 'number' && b.type === 'number') {
    const A = a.values, B = b.values;
    const tol = opt.tolerance;
    let abs = 0, rel = 0;
    if (typeof tol === 'number') abs = Math.abs(tol);
    else if (typeof tol === 'string' && /^\s*[\d.]+\s*%\s*$/.test(tol)) rel = parseFloat(tol) / 100;
    else if (tol != null) throw new Error(`columns.${name}.tolerance: use a number or a percentage like "0.5%"`);
    if (!abs && !rel) return (i, j) => A[i] === B[j] || (A[i] !== A[i] && B[j] !== B[j]);
    return (i, j) => {
      const x = A[i], y = B[j];
      if (x === y) return true;
      if (x !== x || y !== y) return x !== x && y !== y;
      // (plus a hair for floating point: 58.20 − 58.19 is 0.0100000000000051)
      return Math.abs(x - y) <= abs + rel * Math.abs(y) + 1e-9 * (Math.abs(x) + Math.abs(y));
    };
  }
  // Text (or one side text): compare normalised strings, each distinct value normalised once
  const norm = s => { if (opt.trim) s = s.trim(); if (opt.ignoreCase) s = s.toLowerCase(); return s; };
  const ids = dictBuilder();
  const side = d => {
    if (d.type === 'text') { const m = Int32Array.from(d.dict, s => ids.code(norm(s))); return i => m[d.codes[i]]; }
    const t = textOf(d);
    return i => ids.code(norm(t(i)));
  };
  const ia = side(a), ib = side(b);
  return (i, j) => ia(i) === ib(j);
}

// ---------------------------------------------------------------------------
// The comparison
// ---------------------------------------------------------------------------
// deltas: true (Δ and |Δ|) | false | a list of 'diff' (Δ, after − before) and 'abs' (|Δ|)
const DELTA_KINDS = ['diff', 'abs'];
function deltaKinds(spec, name) {
  if (spec === true) return DELTA_KINDS;
  if (!spec) return [];
  const list = Array.isArray(spec) ? spec : [spec];
  const bad = list.find(k => !DELTA_KINDS.includes(k));
  if (bad !== undefined) throw new Error(`${name ? `columns.${name}.` : ''}deltas: "${bad}" isn't one of ${DELTA_KINDS.join(', ')}`);
  return list;
}

function compare(before, after, options = {}) {
  const t0 = performance.now();
  const LOOK = lookFor(options.look);
  // deltaColors: Δ text coloured by direction instead of the heatmap (true: the defaults, growth red)
  const dcol = options.deltaColors ? { up: '#ff8a8a', down: '#6fd3a8', ...(options.deltaColors === true ? {} : options.deltaColors) } : null;
  const rename = options.rename || {}, colOpts = options.columns || {}, deltas = options.deltas === undefined ? true : options.deltas;
  const key = options.key;
  if (!key) throw new Error('no key column given (options.key)');
  deltaKinds(deltas);   // checked even when there are no number columns

  // Columns by their after-name
  const aBy = new Map(after.columns.map(d => [d.name, d]));
  const bBy = new Map(), renamedFrom = new Map();
  const bNames = new Set(before.columns.map(d => d.name));
  for (const from of Object.keys(rename)) {
    if (!bNames.has(from)) throw new Error(`rename: the before file has no column "${from}"`);
  }
  for (const d of before.columns) {
    const name = rename[d.name] || d.name;
    if (bBy.has(name)) throw new Error(`rename: two before columns would both be called "${name}"`);
    bBy.set(name, d);
    if (rename[d.name]) renamedFrom.set(name, d.name);
  }
  for (const name of Object.keys(colOpts)) {
    if (!aBy.has(name) && !bBy.has(name)) throw new Error(`columns: neither file has a column "${name}"`);
  }
  const ak = aBy.get(key), bk = bBy.get(key);
  if (!ak || !bk) throw new Error(`the key column "${key}" is not in the ${!ak && !bk ? 'before or after' : !ak ? 'after' : 'before'} file`);

  // Match rows on the key (as text, so 7 and "7" match)
  const nA = after.rowCount, nB = before.rowCount;
  const keyA = textOf(ak), keyB = textOf(bk);
  const problems = { before: [], after: [], emptyBefore: 0, emptyAfter: 0 };
  const bRow = new Map();
  for (let j = 0; j < nB; j++) {
    const k = keyB(j);
    if (k === '') problems.emptyBefore++;
    else if (bRow.has(k)) problems.before.push(k);
    else bRow.set(k, j);
  }
  const matchOfA = new Int32Array(nA).fill(-1), matchOfB = new Int32Array(nB).fill(-1);
  const addedKeys = new Set();
  for (let i = 0; i < nA; i++) {
    const k = keyA(i);
    if (k === '') { problems.emptyAfter++; continue; }
    const j = bRow.get(k);
    if (j === undefined) { if (addedKeys.has(k)) problems.after.push(k); else addedKeys.add(k); }
    else if (matchOfB[j] >= 0) problems.after.push(k);
    else { matchOfA[i] = j; matchOfB[j] = i; }
  }
  bRow.clear(); addedKeys.clear();
  const issues = [];
  const listKeys = ks => [...new Set(ks)].slice(0, 5).join(', ') + (new Set(ks).size > 5 ? ', …' : '');
  if (problems.before.length) issues.push(`${problems.before.length} duplicate key${problems.before.length === 1 ? '' : 's'} in the before file (${listKeys(problems.before)})`);
  if (problems.after.length) issues.push(`${problems.after.length} duplicate key${problems.after.length === 1 ? '' : 's'} in the after file (${listKeys(problems.after)})`);
  if (problems.emptyBefore) issues.push(`${problems.emptyBefore} row${problems.emptyBefore === 1 ? '' : 's'} with no ${key} in the before file`);
  if (problems.emptyAfter) issues.push(`${problems.emptyAfter} row${problems.emptyAfter === 1 ? '' : 's'} with no ${key} in the after file`);
  if (issues.length) {
    const err = new Error(`"${key}" can't be used as the key: ${issues.join('; ')}.`);
    err.problems = problems;
    throw err;
  }

  // Output rows: the after file's order, each removed row placed after the nearest earlier before row that
  // is still there (or first)
  const removedAt = new Map();   // after row (-1 = the start) -> before rows removed just after it
  let anchor = -1, removedCount = 0;
  for (let j = 0; j < nB; j++) {
    if (matchOfB[j] >= 0) { anchor = matchOfB[j]; continue; }
    let list = removedAt.get(anchor);
    if (!list) removedAt.set(anchor, list = []);
    list.push(j);
    removedCount++;
  }
  const n = nA + removedCount;
  const ai = new Int32Array(n), bi = new Int32Array(n);
  let o = 0;
  const putRemoved = list => { if (list) for (const j of list) { ai[o] = -1; bi[o] = j; o++; } };
  putRemoved(removedAt.get(-1));
  for (let i = 0; i < nA; i++) { ai[o] = i; bi[o] = matchOfA[i]; o++; putRemoved(removedAt.get(i)); }

  // Columns: the after file's, then those only in the before file
  const names = [...aBy.keys(), ...[...bBy.keys()].filter(k => !aBy.has(k))];
  const used = new Set(names);
  const unique = base => { let s = base, k = 2; while (used.has(s)) s = `${base}${k++}`; used.add(s); return s; };
  const statusName = unique('diff.status'), changesName = unique('diff.changes');

  const out = [];        // data columns
  const specs = [];      // the table's columns
  const compared = [];   // { name, eq, bits, count, fit }
  const columnsInfo = { compared: [], added: [], removed: [], renamed: [], ignored: [] };
  const status = new Uint32Array(n);
  // Which rows changed in a column: a bitset, one bit per output row, 32 to each Uint32 (an eighth of a byte per
  // row, even for millions). Row o is bit o % 32 of word Math.floor(o / 32); the shifts below are those, fast
  const bitsFor = rows => new Uint32Array(Math.ceil(rows / 32));
  const bit = (bits, o) => bits[o >>> 5] & (1 << (o & 31));       // o >>> 5: o / 32 (rounded down); o & 31: o % 32
  const setBit = (bits, o) => { bits[o >>> 5] |= 1 << (o & 31); };
  const rowLook = o => (status[o] === ADDED ? LOOK.added : status[o] === REMOVED ? LOOK.removed : null);

  for (const name of names) {
    const a = aBy.get(name), b = bBy.get(name), opt = colOpts[name] || {};
    const tableSpec = {};
    for (const [k, v] of Object.entries(opt)) if (!DIFF_KEYS.includes(k)) tableSpec[k] = v;
    const merged = mergeColumn(name, a, b, ai, bi, n);
    out.push(merged);
    const from = renamedFrom.get(name);
    if (from) columnsInfo.renamed.push([from, name]);
    const spec = { heat: false, ...tableSpec, source: name, label: tableSpec.label || (from ? `${name} (was ${from})` : name) };
    specs.push(spec);
    if (!a || !b) {   // only in one file: shown, not compared
      (a ? columnsInfo.added : columnsInfo.removed).push(name);
      spec.label = tableSpec.label || `${name} (${a ? 'added' : 'removed'} column)`;
      const look = a ? LOOK.addedColumn : LOOK.removedColumn;
      spec.render = ({ rowIndex: o }) => rowLook(o) || look;
      continue;
    }
    if (name === key || opt.ignore) {
      if (opt.ignore) columnsInfo.ignored.push(name);
      spec.render = ({ rowIndex: o }) => rowLook(o);
      continue;
    }
    columnsInfo.compared.push(name);
    const c = { name, eq: equality(name, a, b, opt), bits: bitsFor(n), count: 0, fit: [] };
    compared.push(c);
    // "before → after" in changed cells, the before value written like the after one
    const prev = beforeColumn(unique(`${name}.before`), b, bi, n);
    const fmtValue = typeof opt.format === 'function' ? opt.format : null;
    const beforeRaw = rawOf(prev), beforeText = merged.type === 'number' && prev.type === 'number'
      ? o => { const v = beforeRaw(o); return v === null ? BLANK : fmtValue ? String(fmtValue(v)) : plainNumber(v, merged.decimals, merged.trim); }
      : o => { const v = beforeRaw(o); return v === null ? BLANK : fmtValue ? String(fmtValue(v)) : String(v); };
    spec.fitRows = c.fit;
    spec.render = ({ rowIndex: o, display }) => rowLook(o)
      || (bit(c.bits, o) ? { ...LOOK.changed, text: `${beforeText(o)} → ${display === '' ? BLANK : display}` } : null);
    out.push(prev);
    specs.push({ heat: false, source: prev.name, label: `${name} (before)`, visible: false, ...(fmtValue ? { format: fmtValue } : {}) });
    const kinds = deltaKinds(opt.deltas !== undefined ? opt.deltas : deltas, name);
    if (kinds.length && a.type === 'number' && b.type === 'number') {
      const vals = new Float64Array(n);
      for (let o = 0; o < n; o++) vals[o] = ai[o] >= 0 && bi[o] >= 0 ? a.values[ai[o]] - b.values[bi[o]] : NaN;
      const d = Math.max(a.decimals, b.decimals);
      if (d > 0) { const p = 10 ** d; for (let o = 0; o < n; o++) vals[o] = Math.round(vals[o] * p) / p; }   // no float noise
      if (kinds.includes('diff')) {
        const delta = TarangTable.numberData(unique(`${name}.delta`), vals, d, a.trim || b.trim);
        out.push(delta);
        specs.push({ source: delta.name, label: `Δ ${name}`, visible: false,
          ...(dcol ? { heat: false, render: c => (c.value > 0 ? { color: dcol.up } : c.value < 0 ? { color: dcol.down } : null) } : { heat: { center: 0 } }) });
      }
      if (kinds.includes('abs')) {   // the size of the change either way: sort by it for the biggest changes
        const abs = TarangTable.numberData(unique(`${name}.absdelta`), vals.map(Math.abs), d, a.trim || b.trim);
        out.push(abs);
        specs.push({ source: abs.name, label: `|Δ| ${name}`, visible: false });
      }
    }
  }

  // Compare the matched rows
  const changes = dictBuilder(), changeCodes = new Uint32Array(n);
  const counts = { same: 0, changed: 0, added: 0, removed: 0 };
  for (let o = 0; o < n; o++) {
    const i = ai[o], j = bi[o];
    if (i < 0) { status[o] = REMOVED; counts.removed++; continue; }
    if (j < 0) { status[o] = ADDED; counts.added++; continue; }
    let which = null;
    for (const c of compared) {
      if (c.eq(i, j)) continue;
      setBit(c.bits, o);
      c.count++;
      if (c.fit.length < 100) c.fit.push(o);
      (which || (which = [])).push(c.name);
    }
    if (which) { status[o] = CHANGED; counts.changed++; changeCodes[o] = changes.code(which.join(', ')); }
    else { status[o] = SAME; counts.same++; }
  }

  out.unshift(TarangTable.textData(statusName, status, STATUS_DICT));
  specs.unshift({
    source: statusName, label: 'status', total: 'count',
    heat: false, render: ({ rowIndex: o }) => rowLook(o) || (status[o] === CHANGED ? { background: LOOK.changed.background } : null),
  });
  out.push(TarangTable.textData(changesName, changeCodes, changes.dict));
  specs.push({ source: changesName, label: 'changes', heat: false, render: ({ rowIndex: o }) => rowLook(o) });

  const changedByColumn = {};
  for (const c of compared) changedByColumn[c.name] = c.count;
  return {
    data: { columns: out, rowCount: n },
    transform: { columns: specs },
    statusKey: statusName,
    summary: { rows: n, ...counts, changedByColumn, columns: columnsInfo, ms: performance.now() - t0 },
  };
}

// One shown column: the after value, or the before value where the row (or the column) has no after
function mergeColumn(name, a, b, ai, bi, n) {
  const pick = (o) => (a && ai[o] >= 0 ? 0 : b && bi[o] >= 0 ? 1 : -1);   // which side o reads from
  if ((!a || a.type === 'number') && (!b || b.type === 'number')) {
    const vals = new Float64Array(n);
    for (let o = 0; o < n; o++) { const s = pick(o); vals[o] = s === 0 ? a.values[ai[o]] : s === 1 ? b.values[bi[o]] : NaN; }
    const decimals = Math.max(a ? a.decimals : 0, b ? b.decimals : 0);
    const trim = !!((a && a.trim) || (b && b.trim) || (a && b && a.decimals !== b.decimals));
    return TarangTable.numberData(name, vals, decimals, trim);
  }
  // Text on either side: one dictionary for both
  const db = dictBuilder();
  const side = d => {
    if (!d) return null;
    if (d.type === 'text') { const m = Int32Array.from(d.dict, db.code); return i => m[d.codes[i]]; }
    const t = textOf(d);
    return i => db.code(t(i));
  };
  const ca = side(a), cb = side(b), codes = new Uint32Array(n);
  for (let o = 0; o < n; o++) { const s = pick(o); codes[o] = s === 0 ? ca(ai[o]) : s === 1 ? cb(bi[o]) : 0; }
  return TarangTable.textData(name, codes, db.dict);
}

// The before file's values, lined up with the output rows (empty on added rows)
function beforeColumn(name, b, bi, n) {
  if (b.type === 'number') {
    const vals = new Float64Array(n);
    for (let o = 0; o < n; o++) vals[o] = bi[o] >= 0 ? b.values[bi[o]] : NaN;
    return TarangTable.numberData(name, vals, b.decimals, b.trim);
  }
  const codes = new Uint32Array(n);
  for (let o = 0; o < n; o++) codes[o] = bi[o] >= 0 ? b.codes[bi[o]] : 0;
  return TarangTable.textData(name, codes, b.dict);
}

// ---------------------------------------------------------------------------
// The table
// ---------------------------------------------------------------------------
const nextFrame = () => new Promise(r => { requestAnimationFrame(() => setTimeout(r, 0)); setTimeout(r, 100); });

async function create(container, options = {}) {
  let settings = { ...options };
  delete settings.before; delete settings.after;   // the sources (maybe large CSV text) aren't kept
  const note = document.createElement('div');
  note.className = 'tarang-diff-note';
  const say = (text, error = false) => {
    note.textContent = text;
    note.classList.toggle('tarang-diff-error', error);
    if (!note.isConnected) container.appendChild(note);
  };

  let before, after, result;
  try {
    say('Reading the files…');
    await nextFrame();
    [before, after] = await Promise.all([readSource(options.before), readSource(options.after)]);
    say('Comparing…');
    await nextFrame();
    result = compare(before, after, settings);
  } catch (err) {
    say(`Could not compare: ${err.message}`, true);
    throw err;
  }
  note.remove();
  const labels = { before: sourceLabel(options.before), after: sourceLabel(options.after) };
  const label = `${labels.before} → ${labels.after}`;
  const table = await TarangTable.create(container, {
    title: 'Differences', fileLoading: false, ...(options.table || {}),   // loading one file would replace the diff
    source: { data: result.data, label }, transform: result.transform,
  });

  const SHOW = { all: '', changes: '!=same', same: '=same', changed: '=changed', added: '=added', removed: '=removed' };
  return {
    table,
    get summary() { return result.summary; },
    show(which) {
      if (!(which in SHOW)) throw new Error(`show: use one of ${Object.keys(SHOW).join(', ')}`);
      return table.setFilter(result.statusKey, SHOW[which]);
    },
    // Compare again with new settings, or new files (before / after); throws, leaving the table as it was,
    // if they don't work
    async setOptions(changes) {
      const { before: newBefore, after: newAfter, ...rest } = changes;
      const next = { ...settings, ...rest };
      const [b, a] = await Promise.all([newBefore ? readSource(newBefore) : before, newAfter ? readSource(newAfter) : after]);
      const r = compare(b, a, next);
      settings = next;
      before = b; after = a; result = r;
      if (newBefore) labels.before = sourceLabel(newBefore);
      if (newAfter) labels.after = sourceLabel(newAfter);
      const label = `${labels.before} → ${labels.after}`;
      // Keep the sort, filters, grouping and which columns are shown (parts that no longer fit are dropped)
      const state = table.getState(), shown = new Map(table.columns.map(c => [c.key, c.visible]));
      await table.load({ data: r.data, label }, { transform: r.transform });
      for (const c of table.columns) {
        if (shown.has(c.key) && shown.get(c.key) !== c.visible) await table.setColumnVisible(c.key, shown.get(c.key));
      }
      await table.setState(state);
    },
    destroy() { table.destroy(); before = after = result = null; },
  };
}

window.TarangDiff = { create, compare };
})();
