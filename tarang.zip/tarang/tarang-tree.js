// SPDX-License-Identifier: MIT
/* tarang-tree.js: a virtualised call-tree table for large allocation captures (millions of nodes).
 *
 *   const tree = TarangTree.create(containerElement, {
 *     data: { function: 'main', 'inclusive_size_bytes': 123, …, children: [ … ] },   // one root, or an array of roots
 *     keys: { 'inclusive_size_bytes': 'bytes', children: 'kids' },   // optional: the names used in the data, when
 *                                  //   they differ from the full ones (see FIELDS below). Not needed for the short
 *                                  //   format, which is recognised on its own: { f: 'main', t: 'core', isb, iac, lsb,
 *                                  //   lac, c: [ … ] } (SHORT_KEYS; or say keys: 'short')
 *     title: 'Capture',            // shown in the toolbar
 *     percentOf: 'inclusive_size_bytes',   // what the (hidden at first) % of total / % of parent columns measure
 *     fileLoading: true,           // dropping a .json file on the tree (and the Load… button) replaces the data
 *     colorOf: (key, value) => '#rrggbb' | null,   // optional: colours shared with a table / charts (e.g. a
 *                                  //   TarangTable's colorOf). key: 'function', 'system' or 'subsystem'. Given, a
 *                                  //   coloured cell gets a strip of its colour at the left edge, as in tarang-table,
 *                                  //   and the tags are no longer coloured by the tree's own palette. Call
 *                                  //   tree.redraw() when the colours change
 *     onComment: ({ node, path, comment, previous, fn }) => {},   // a comment was written or changed (typing in
 *                                  //   the box, setComment): e.g. send it to a server. Not for pins without one
 *     urlState: 'tree',            // off by default: keep the selection, search, filters and sort in the page
 *                                  //   address, and restore them when the page opens with it:
 *                                  //   ?tree.sel=0.3.1,0.2&tree.q=Malloc&tree.f.tag=Audio&tree.sort=-inclusive_size_bytes
 *                                  //   A node is its path of places in the data (0.3.1: the first root's 4th
 *                                  //   child's 2nd child), so links hold while the data's order stays the same;
 *                                  //   one that goes deeper than the data opens as far as it can
 *     columns: ['function', 'inclusive_size_bytes', 'exclusive_size_bytes', 'tag', …],   // the starting order (keys or
 *                                  //   labels, or { key, width, visible, align }); Function is always first; columns left
 *                                  //   out start hidden (the ☰ menu can show them). Keys: FIELDS / METRICS /
 *                                  //   DERIVED below, plus 'tag', '% of total', '% of parent'
 *   });
 *   tree.load(data)                 replace the data (same shape)
 *   tree.setSearch(text)            'abc' paths to functions containing abc · '~abc' the same plus everything below
 *                                   each match · 'tag:Audio' only that tag (combine: 'tag:Audio ~mix') · '' clears
 *   tree.expandAll()  tree.collapseAll()  tree.expandToDepth(n)  tree.expandBelow(node)  tree.collapseBelow(node)
 *   tree.hotPath(node?, field?)     open the chain of biggest children from node (default: the selected node, or the
 *                                   biggest root) and select its end; field: by which metric, e.g.
 *                                   'inclusive_allocation_count' or 'excess_allocation_count' (default: the last used, at first bytes)
 *   tree.setSort(key, -1 | 1 | 0)   sort each node's children by a column (0: data order); the tree shape is kept
 *   tree.setFilter(key, text) -> error | null   a column's filter ('' removes it): >1MiB, <=500, >1% (of the total),
 *                                   =0, abc, =abc, !abc, a | b … (see compileFilter)   tree.clearFilters()   tree.filters
 *   tree.setPercentOf(field)        the metric for the % columns
 *   tree.setColumnVisible(key, bool)   tree.moveColumnTo(key, index)   (index 1 = first after Function)
 *   tree.setColumnOrder([key, …])   as the columns option   tree.columns -> [{ key, label, visible, width }] in order
 *   tree.select(node)  tree.selected (the cursor row)  tree.selection (all selected, in tree order)
 *   tree.reveal(node) -> bool      open the path to a node, select it and scroll to it (false: the filters hide it)
 *   tree.setSelection([node, …])  tree.copyPaths(nodes?)  tree.pathOf(node) -> [node, …] from the root
 *   tree.model                      the flattened data (typed arrays, see buildModel)
 *   tree.onChange(fn)               ({ type }) on 'load', 'expand', 'search', 'filter', 'sort', 'select', 'columns', 'pin', 'comment'
 *   Pins: tree.pin(node, comment?)  tree.unpin(node)  tree.togglePin(node)  tree.setComment(node, text) (pins it)
 *         tree.pins -> [{ node, path, comment }]   tree.setPins([{ path or node, comment }]) (e.g. saved ones back)
 *         tree.openCommentBox(node, x, y)   A pinned node shows a pin before its name and its comment after it.
 *         The comment box saves as you type and when it closes (Done, Enter, Esc or a click elsewhere)
 *   tree.redraw()                   repaint (after the colours opts.colorOf returns change)
 *   tree.destroy()
 *   TarangTree.buildModel(data, keys)   TarangTree.sample({ nodes, seed })   (generated data for demos)
 *
 * Each node: function, tag, and four inclusive metrics (bytes and allocation count still live at the end of the
 * capture, and both counted since the capture started: "lifetime"). Exclusive values are worked out as the
 * node's inclusive value minus its children's inclusive values. A node may leave any metric out (and its tag):
 * it then gets the sum of its children's values, or 0. Excess bytes / allocs are lifetime minus
 * inclusive: what was allocated during the capture but freed again (see DERIVED).
 * A tag is a chain separated by dots: "physics.simulation.world" is system "physics" and subsystem
 * "simulation.world", shown as two columns, System and Subsystem (coloured by the system); the whole tag is a
 * third column, Tag, hidden at first. =simulation on Subsystem, =physics on Tag and tag:physics in the search
 * match that and everything under it. The status line and copied call stacks give the whole tag.
 *
 * Mouse: click a row to select it (Ctrl/⌘+click adds or removes one, Shift+click a range); click ▸ (or double-click the row) to open / close; Shift+click ▸ opens / closes
 * everything below. Right-click a row for more. Right-click (or Ctrl/⌘+click) a header to filter that
 * column. Click a header to sort (big first, then small first, then data
 * order); drag a header sideways to move its column, or its right edge to resize it.
 * The ☰ at the start of the header opens every option: open to a depth / everything, collapse all, hot path
 * by each metric, KiB / MiB, clear filters, the columns (show, hide, ↑ ↓ to move) and loading a capture.
 * Keys: ↑ ↓ PgUp PgDn Home End move · → open / first child · ← close / parent · Enter open / close ·
 * * open everything below · H hot path from here (by the metric last chosen in "Hot path by…") ·
 * Shift+↑ ↓ (and PgUp PgDn Home End) select a range · Ctrl/⌘+A everything shown · Esc nothing · P pin / unpin ·
 * Ctrl/⌘+C copy the selected call stacks (each: its numbers in a # header, then one frame per line, indented).
 */
(function () {
'use strict';
// Missing numbers are NaN, as in tarang-table: `v === v` reads "v has a value" and `v !== v` "v is missing"
// (NaN is the only value not equal to itself)

// Field names in the data. `keys` (create / buildModel) maps any of them to the name a file uses instead
const FIELDS = { function: 'function', tag: 'tag', children: 'children' };
// The short format: the same fields with short names (about half the file). A file is read in it on its own
// when its root has "f" or "c" and no "function" (or with keys: 'short')
const SHORT_KEYS = {
  function: 'f', tag: 't', children: 'c',
  inclusive_size_bytes: 'isb', inclusive_allocation_count: 'iac', lifetime_size_bytes: 'lsb', lifetime_allocation_count: 'lac',
};
// The four inclusive metrics in the data; each also gets an exclusive column (worked out, not read)
const METRICS = [
  { field: 'inclusive_size_bytes', exclusive: 'exclusive_size_bytes', label: 'bytes', incl: 'Incl. bytes', excl: 'Excl. bytes', bytes: true },
  { field: 'inclusive_allocation_count', exclusive: 'exclusive_allocation_count', label: 'allocs', incl: 'Incl. allocs', excl: 'Excl. allocs' },
  { field: 'lifetime_size_bytes', exclusive: 'lifetime_exclusive_size_bytes', label: 'lifetime bytes', incl: 'Lifetime incl. bytes', excl: 'Lifetime excl. bytes', bytes: true },
  { field: 'lifetime_allocation_count', exclusive: 'lifetime_exclusive_allocation_count', label: 'lifetime allocs', incl: 'Lifetime incl. allocs', excl: 'Lifetime excl. allocs' },
];
// Columns worked out from two inclusive metrics: from[0] − from[1]
const DERIVED = [
  // excess: allocated since the capture started but freed again by its end
  { key: 'excess_size_bytes', label: 'Excess bytes', from: ['lifetime_size_bytes', 'inclusive_size_bytes'], bytes: true },
  { key: 'excess_allocation_count', label: 'Excess allocs', from: ['lifetime_allocation_count', 'inclusive_allocation_count'] },
];
const TAG_COLORS =['#7fb0ff', '#ffa064', '#6fd3a8', '#e6c25a', '#f08cb4', '#b4a6ff', '#ff8a8a', '#8fd0e0'];
const ROW_H = 22, HEAD_H = 24, INDENT = 14, TOGGLE_W = 16, CORNER_W = 30;   // CORNER_W: the ☰ at the start of the header
const FONT = '12px system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
const HEAD_FONT = '500 ' + FONT;
const C = {
  bg: '#11151c', headBg: '#1c212b', grid: 'rgba(255,255,255,0.05)', text: '#e6e8ec', muted: '#8b93a3',
  hover: 'rgba(255,255,255,0.06)', sel: 'rgba(255,213,74,0.16)', accent: '#ffd54a', match: '#ffd54a',
  bar: 'rgba(90,140,230,0.28)', barExcl: 'rgba(110,200,150,0.25)', barExcess: 'rgba(230,150,80,0.25)', comment: '#c9b26b', guide: 'rgba(255,255,255,0.07)', frozenLine: '#2a303c',
};
// Browsers cap element size, so the scrollable height is capped and mapped onto the true content height
const MAX_SCROLL_PX = /firefox/i.test(navigator.userAgent) ? 8_000_000 : 16_000_000;

const intFmt = new Intl.NumberFormat();
const pctFmt = new Intl.NumberFormat(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 });
function fmtBytes(v) {
  const a = Math.abs(v);
  if (a < 1024) return `${intFmt.format(v)} B`;
  const units = ['KiB', 'MiB', 'GiB', 'TiB'];   // 1024s
  let u = -1, x = v;
  do { x /= 1024; u++; } while (Math.abs(x) >= 1024 && u < units.length - 1);
  return `${x.toFixed(Math.abs(x) < 10 ? 2 : 1)} ${units[u]}`;
}
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

// ---------------------------------------------------------------------------
// Model: the nested data flattened depth-first into typed arrays. Node ids are in depth-first order, so a node's
// whole subtree is the id range [node, end[node]). kids lists each node's children (its own slice, which the view
// sorts in place); roots does the same for the top level.
// ---------------------------------------------------------------------------
function buildModel(data, keys = {}) {
  const top = Array.isArray(data) ? data : data ? [data] : [];
  // Which names the file uses: given keys, else the short format if the root looks like it, else the full names
  if (keys === 'short') keys = SHORT_KEYS;
  else if (!keys || !Object.keys(keys).length) {
    const r = top[0];
    keys = r && typeof r === 'object' && !(FIELDS.function in r) && ('f' in r || 'c' in r) ? SHORT_KEYS : {};
  }
  const k = name => keys[name] || name;
  const kFn = k(FIELDS.function), kTag = k(FIELDS.tag), kKids = k(FIELDS.children), kM = METRICS.map(m => k(m.field));

  // Pass 1: count (no recursion: captures can be deeper than the call stack)
  let n = 0;
  const st = [];
  for (let i = 0; i < top.length; i++) st.push(top[i]);
  while (st.length) {
    const o = st.pop();
    n++;
    const c = o && o[kKids];
    if (Array.isArray(c)) for (let i = 0; i < c.length; i++) st.push(c[i]);
  }

  // Pass 2: depth-first, children in data order
  const parent = new Int32Array(n), depth = new Uint32Array(n), end = new Int32Array(n);
  const fn = new Uint32Array(n), tag = new Uint32Array(n), kidsCount = new Int32Array(n);
  const inc = METRICS.map(() => new Float64Array(n));
  const fnDict = [], fnIndex = new Map(), tagDict = [''], tagIndex = new Map([['', 0]]);
  const sO = [], sP = [], sD = [];
  for (let i = top.length - 1; i >= 0; i--) { sO.push(top[i]); sP.push(-1); sD.push(0); }
  let id = 0, maxDepth = 0;
  const num = v => (typeof v === 'number' ? v : v == null || v === '' ? NaN : Number(v));
  while (sO.length) {
    const o = sO.pop() || {}, p = sP.pop(), d = sD.pop(), me = id++;
    parent[me] = p; depth[me] = d; if (d > maxDepth) maxDepth = d;
    if (p >= 0) kidsCount[p]++;
    const name = o[kFn] == null ? '(unknown)' : String(o[kFn]);
    let code = fnIndex.get(name);
    if (code === undefined) { code = fnDict.length; fnDict.push(name); fnIndex.set(name, code); }
    fn[me] = code;
    const t = o[kTag] == null ? '' : String(o[kTag]);
    let tc = tagIndex.get(t);
    if (tc === undefined) { tc = tagDict.length; tagDict.push(t); tagIndex.set(t, tc); }
    tag[me] = tc;
    for (let j = 0; j < kM.length; j++) inc[j][me] = num(o[kM[j]]);
    const c = o[kKids];
    if (Array.isArray(c)) for (let i = c.length - 1; i >= 0; i--) { sO.push(c[i]); sP.push(me); sD.push(d + 1); }
  }

  // Subtree ends, children lists, exclusive values, totals
  for (let i = 0; i < n; i++) end[i] = i + 1;
  for (let i = n - 1; i > 0; i--) { const p = parent[i]; if (p >= 0 && end[i] > end[p]) end[p] = end[i]; }
  const kidsStart = new Int32Array(n), kids = new Int32Array(n), fill = new Int32Array(n), childIndex = new Int32Array(n);
  for (let i = 0, s = 0; i < n; i++) { kidsStart[i] = s; s += kidsCount[i]; }
  const rootList = [];
  for (let i = 0; i < n; i++) {
    const p = parent[i];
    // childIndex: its place among its parent's children (or the roots) in the data, which sorting never changes
    if (p < 0) { childIndex[i] = rootList.length; rootList.push(i); } else { childIndex[i] = fill[p]; kids[kidsStart[p] + fill[p]++] = i; }
  }
  // A node without a value (left out, or not a number) gets the sum of its children's, or 0 without children:
  // so a frame that doesn't record its totals neither loses what is below it nor hands it to its parent's
  // exclusive value. Ids are depth-first, so going backwards finishes every child before its parent
  for (let j = 0; j < inc.length; j++) {
    const a = inc[j], below = new Float64Array(n);
    for (let i = n - 1; i >= 0; i--) {
      if (a[i] !== a[i]) a[i] = below[i];
      const p = parent[i];
      if (p >= 0) below[p] += a[i];
    }
  }
  const exc = inc.map(a => Float64Array.from(a));
  for (let j = 0; j < inc.length; j++) {
    const a = inc[j], e = exc[j];
    for (let i = 0; i < n; i++) { const p = parent[i]; if (p >= 0) e[p] -= a[i]; }
  }
  const roots = Int32Array.from(rootList);
  const total = inc.map(a => { let s = 0; for (const r of roots) if (a[r] === a[r]) s += a[r]; return s; });
  const maxOf = a => { let m = 0; for (let i = 0; i < a.length; i++) if (a[i] > m) m = a[i]; return m; };
  // Derived from two metrics per node (see DERIVED), e.g. excess = lifetime − inclusive
  const derived = DERIVED.map(d => {
    const a = inc[METRICS.findIndex(m => m.field === d.from[0])], b = inc[METRICS.findIndex(m => m.field === d.from[1])];
    const out = new Float64Array(n);
    for (let i = 0; i < n; i++) out[i] = a[i] - b[i];
    return out;
  });
  // Tags are chains: "physics.simulation.world" is system "physics", subsystem "simulation.world" (per tag code:
  // tagSystemName, tagSubsystem). A tag's colour follows its system (tagSystem: an index into systems)
  const tagSystemName = tagDict.map(t => t.split('.')[0]);
  const tagSubsystem = tagDict.map(t => t.split('.').slice(1).join('.'));
  const systems = [], systemIndex = new Map();
  const tagSystem = Int32Array.from(tagDict, t => {
    if (!t) return -1;
    const top = t.split('.')[0];
    let k = systemIndex.get(top);
    if (k === undefined) { k = systems.length; systems.push(top); systemIndex.set(top, k); }
    return k;
  });
  return {
    n, parent, depth, end, fn, tag, fnDict, tagDict, tagSystemName, tagSubsystem, tagSystem, systems, inc, exc, derived, kidsStart, kidsCount, kids, childIndex, roots, total,
    maxInc: inc.map(maxOf), maxExc: exc.map(maxOf), maxDerived: derived.map(maxOf), maxDepth,
  };
}

// ---------------------------------------------------------------------------
// The view
// ---------------------------------------------------------------------------
function create(container, options = {}) {
  const opts = { fileLoading: true, percentOf: METRICS[0].field, ...options };
  const root = document.createElement('div');
  root.className = 'tarang-tree-root';
  root.innerHTML = `
    <div class="tarang-tree-bar">
      <b class="tarang-tree-title"></b>
      <input type="text" class="tarang-tree-search" spellcheck="false" placeholder="Search functions…   ~abc: with everything below · tag:Audio">
      <button type="button" class="tarang-tree-clear-filters" title="Remove every column filter" hidden>Clear filters</button>
      <input type="file" class="tarang-tree-file" accept=".json,application/json" hidden>
      <span class="tarang-tree-info"></span>
    </div>
    <div class="tarang-tree-grid">
      <canvas class="tarang-tree-canvas"></canvas>
      <div class="tarang-tree-scroller" tabindex="0"><div class="tarang-tree-spacer"></div></div>
      <div class="tarang-tree-empty" hidden></div>
      <div class="tarang-tree-busy" hidden></div>
    </div>
    <div class="tarang-tree-status"><span class="tarang-tree-crumb"></span><span class="tarang-tree-sel-stats"></span></div>`;
  container.appendChild(root);
  const q = s => root.querySelector(s);
  const canvas = q('.tarang-tree-canvas'), scroller = q('.tarang-tree-scroller'), spacer = q('.tarang-tree-spacer'), grid = q('.tarang-tree-grid');
  const ctx = canvas.getContext('2d');
  if (opts.title) q('.tarang-tree-title').textContent = opts.title; else q('.tarang-tree-title').remove();


  // ----- columns -----
  const metricIndex = field => Math.max(0, METRICS.findIndex(m => m.field === field));
  let pctMetric = metricIndex(opts.percentOf);
  const columns = [
    { key: 'function', label: 'Function', kind: 'tree', width: 380, visible: true },
    // the tag split in two (physics | simulation.world), and whole (hidden at first)
    { key: 'system', label: 'System', kind: 'tag', part: 'system', width: 100, visible: true },
    { key: 'subsystem', label: 'Subsystem', kind: 'tag', part: 'subsystem', width: 150, visible: true },
    { key: 'tag', label: 'Tag', kind: 'tag', part: 'tag', width: 200, visible: false },
    // % columns start hidden: the inclusive bars already show each node's share of the total
    { key: '% of total', label: '% of total', kind: 'pct', of: 'total', width: 82, visible: false },
    { key: '% of parent', label: '% of parent', kind: 'pct', of: 'parent', width: 88, visible: false },
  ];
  METRICS.forEach((m, j) => {
    const w = m.label.startsWith('lifetime') ? 140 : 104;
    columns.push({ key: m.field, label: m.incl, kind: 'num', metric: j, excl: false, bytes: !!m.bytes, width: w, visible: true });
    columns.push({ key: m.exclusive, label: m.excl, kind: 'num', metric: j, excl: true, bytes: !!m.bytes, width: w, visible: true });
  });
  DERIVED.forEach((d, j) => columns.push({ key: d.key, label: d.label, kind: 'num', derived: j, bytes: !!d.bytes, width: 110, visible: true }));
  // where each column's text sits: numbers right, text left (the column box's Align changes it; Function stays left)
  for (const c of columns) c.align = c.kind === 'num' || c.kind === 'pct' ? 'right' : 'left';
  const shownCols = () => columns.filter(c => c.visible);
  // A column order: keys or labels (or { key, width, visible }), Function first whatever the list says. Columns
  // the list leaves out are hidden, after the listed ones (still in the ☰ menu)
  function applyColumnOrder(list) {
    const rest = columns.slice(1), picked = [];
    for (const spec of list) {
      const s = typeof spec === 'string' ? { key: spec } : spec || {};
      const c = columns.find(x => x.key === s.key || x.label === s.key);
      if (!c) { console.warn(`[tarang-tree] no column "${s.key}"`); continue; }
      if (s.width) c.width = s.width;
      if (['left', 'center', 'right'].includes(s.align) && c.kind !== 'tree') c.align = s.align;
      if (c === columns[0] || picked.includes(c)) continue;
      c.visible = s.visible !== false;
      picked.push(c);
    }
    for (const c of rest) if (!picked.includes(c)) c.visible = false;
    columns.splice(1, columns.length - 1, ...picked, ...rest.filter(c => !picked.includes(c)));
  }
  if (opts.columns) applyColumnOrder(opts.columns);

  // ----- state -----
  let M = null;                 // the model
  let expanded = null;          // Uint8Array per node
  let keep = null;              // Uint8Array per node, or null: search / filters hide the rest
  let matchMark = null;         // Uint8Array per node: search matches (drawn highlighted)
  let lines = new Int32Array(0), lineCount = 0, stackBuf = null;
  let sortKey = null, sortDir = 0, sortStamp = 1;   // children are sorted lazily, per node, when opened
  let sortedAt = null, rootsSortedAt = 0;
  let selected = -1, hoverLine = -1, search = '', human = true;
  const filters = new Map();    // column key -> { text, test(node) } (see compileFilter)
  const pins = new Map();       // pinned node -> its comment ('' for none); see pin()
  const listeners = new Set();
  const emit = type => {
    if (type === 'select' || type === 'search' || type === 'filter' || type === 'sort' || type === 'load') writeUrl();
    for (const fn of listeners) { try { fn({ type }); } catch (err) { console.error('[tarang-tree] onChange listener:', err); } }
  };

  // ----- values -----
  function value(col, i) {
    switch (col.kind) {
      case 'num': return col.derived != null ? M.derived[col.derived][i] : (col.excl ? M.exc : M.inc)[col.metric][i];
      case 'pct': {
        const v = M.inc[pctMetric][i];
        if (col.of === 'total') return M.total[pctMetric] ? (v / M.total[pctMetric]) * 100 : NaN;
        const p = M.parent[i], base = p >= 0 ? M.inc[pctMetric][p] : M.total[pctMetric];
        return base ? (v / base) * 100 : NaN;
      }
      case 'tag': return textOf(col).dict[M.tag[i]];
      default: return M.fnDict[M.fn[i]];
    }
  }
  // A text column's strings: dict[codes[node]] (the tag columns share the tag codes, each with its own strings)
  function textOf(col) {
    if (col.kind === 'tree') return { dict: M.fnDict, codes: M.fn };
    return { dict: col.part === 'system' ? M.tagSystemName : col.part === 'subsystem' ? M.tagSubsystem : M.tagDict, codes: M.tag };
  }
  function display(col, v) {
    if (col.kind === 'num') return v !== v ? '' : col.bytes && human ? fmtBytes(v) : intFmt.format(v);
    if (col.kind === 'pct') return v !== v ? '' : `${pctFmt.format(v)}%`;
    return v;
  }
  const barMax = col => (col.kind === 'pct' ? 100 : col.derived != null ? M.maxDerived[col.derived]
    : col.excl ? M.maxExc[col.metric] : Math.max(M.maxInc[col.metric], M.total[col.metric]));

  // ----- sorting (each node's children, in place, when that node is shown open) -----
  const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
  function comparator() {
    const col = columns.find(c => c.key === sortKey);
    if (!col || !sortDir) return (a, b) => a - b;   // data order (ids are depth-first, so siblings are in data order)
    if (col.kind === 'tree' || col.kind === 'tag') {
      const { dict, codes } = textOf(col);
      return (a, b) => sortDir * collator.compare(dict[codes[a]], dict[codes[b]]) || a - b;
    }
    return (a, b) => {
      const x = value(col, a), y = value(col, b);
      if (x !== x || y !== y) return (x !== x) - (y !== y) || a - b;   // empty values last
      return sortDir * (x - y) || a - b;
    };
  }
  let cmp = (a, b) => a - b;
  function sortSlice(arr, start, count) {
    if (count < 2) return;
    const part = Array.from(arr.subarray(start, start + count)).sort(cmp);
    arr.set(part, start);
  }
  function ensureSorted(node) {
    if (node < 0) { if (rootsSortedAt !== sortStamp) { sortSlice(M.roots, 0, M.roots.length); rootsSortedAt = sortStamp; } return; }
    if (sortedAt[node] !== sortStamp) { sortSlice(M.kids, M.kidsStart[node], M.kidsCount[node]); sortedAt[node] = sortStamp; }
  }

  // ----- visible lines: depth-first over the open nodes (and only what search / filters keep) -----
  function rebuildLines(keepRow = true) {
    if (!M) { lineCount = 0; return draw(); }
    const sel = selected;
    // reuse the last lines array (it doubles when it fills up); a small one to start with
    let out = lines.length >= 1024 ? lines : new Int32Array(1024), count = 0;
    if (!stackBuf || stackBuf.length < M.n + 1) stackBuf = new Int32Array(M.n + 1);
    const stack = stackBuf;
    let sp = 0;
    ensureSorted(-1);
    for (let r = M.roots.length - 1; r >= 0; r--) stack[sp++] = M.roots[r];
    while (sp) {
      const i = stack[--sp];
      if (keep && !keep[i]) continue;
      if (count === out.length) { const bigger = new Int32Array(out.length * 2); bigger.set(out); out = bigger; }
      out[count++] = i;
      if (expanded[i] && M.kidsCount[i]) {
        ensureSorted(i);
        const s = M.kidsStart[i];
        for (let c = M.kidsCount[i] - 1; c >= 0; c--) stack[sp++] = M.kids[s + c];
      }
    }
    lines = out; lineCount = count;
    lineOf = null;
    updateSpacer();
    if (keepRow && sel >= 0) scrollToNode(sel, false);
    draw();
    renderInfo();
  }
  // node -> line, built on demand (for keyboard moves and scrolling to a node)
  let lineOf = null;
  function lineOfNode(node) {
    if (!lineOf) { lineOf = new Int32Array(M.n).fill(-1); for (let l = 0; l < lineCount; l++) lineOf[lines[l]] = l; }
    return lineOf[node];
  }
  const hasKids = i => {
    if (!M.kidsCount[i]) return false;
    if (!keep) return true;
    const s = M.kidsStart[i];
    for (let c = 0; c < M.kidsCount[i]; c++) if (keep[M.kids[s + c]]) return true;
    return false;
  };

  // ----- scrolling -----
  let vx = 0, vy = 0, viewW = 0, viewH = 0;
  const contentH = () => lineCount * ROW_H;
  const frozenW = () => (columns[0].visible ? columns[0].width : 0);
  const scrollColsW = () => shownCols().filter(c => c !== columns[0]).reduce((s, c) => s + c.width, 0);
  function updateSpacer() {
    const h = contentH() + HEAD_H;
    spacer.style.height = Math.min(h, MAX_SCROLL_PX) + 'px';
    spacer.style.width = frozenW() + scrollColsW() + 'px';
    readScroll();
  }
  function readScroll() {
    const h = contentH() + HEAD_H, sh = Math.min(h, MAX_SCROLL_PX), room = Math.max(0, h - viewH), sroom = Math.max(1, sh - viewH);
    vy = h > MAX_SCROLL_PX ? (scroller.scrollTop / sroom) * room : scroller.scrollTop;
    vy = Math.max(0, Math.min(vy, room));
    vx = scroller.scrollLeft;
  }
  function setVY(y) {
    const h = contentH() + HEAD_H, sh = Math.min(h, MAX_SCROLL_PX), room = Math.max(0, h - viewH), sroom = Math.max(1, sh - viewH);
    y = Math.max(0, Math.min(y, room));
    scroller.scrollTop = h > MAX_SCROLL_PX ? (y / Math.max(1, room)) * sroom : y;
    vy = y;
    draw();
  }
  function scrollToNode(node, center = true) {
    const l = lineOfNode(node);
    if (l < 0) return false;
    const top = l * ROW_H, bodyH = viewH - HEAD_H;
    if (center) setVY(top - bodyH / 2 + ROW_H / 2);
    else if (top < vy) setVY(top);
    else if (top + ROW_H > vy + bodyH) setVY(top + ROW_H - bodyH);
    return true;
  }
  scroller.addEventListener('scroll', () => { readScroll(); draw(); });

  // ----- drawing -----
  let frame = 0;
  function draw() { if (!frame) frame = requestAnimationFrame(paint); }
  // opts.colorOf, guarded: a throwing callback leaves the cell uncoloured
  function sharedColor(key, value) {
    try { return opts.colorOf(key, value) || null; } catch { return null; }
  }
  function resize() {
    const r = grid.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    viewW = Math.max(1, Math.floor(r.width)); viewH = Math.max(1, Math.floor(r.height));
    canvas.width = viewW * dpr; canvas.height = viewH * dpr;
    canvas.style.width = viewW + 'px'; canvas.style.height = viewH + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    readScroll();
    draw();
  }
  const ro = new ResizeObserver(resize);
  ro.observe(grid);

  // x of each shown column (the first, Function, is frozen at the left)
  function layout() {
    const out = [];
    let x = frozenW() - vx;
    for (const c of shownCols()) {
      if (c === columns[0]) out.push({ c, x: 0, w: c.width });
      else { out.push({ c, x, w: c.width }); x += c.width; }
    }
    return out;
  }
  function paint() {
    frame = 0;
    ctx.fillStyle = C.bg; ctx.fillRect(0, 0, viewW, viewH);
    if (!M) return;
    const first = Math.floor(vy / ROW_H), last = Math.min(lineCount, Math.ceil((vy + viewH - HEAD_H) / ROW_H) + 1);
    const yOf = l => HEAD_H + l * ROW_H - vy;
    const cols = layout(), fw = frozenW();
    // row backgrounds: selection and hover
    for (let l = first; l < last; l++) {
      const i = lines[l], y = yOf(l);
      if (chosen.has(i)) { ctx.fillStyle = C.sel; ctx.fillRect(0, y, viewW, ROW_H); }
      else if (l === hoverLine) { ctx.fillStyle = C.hover; ctx.fillRect(0, y, viewW, ROW_H); }
    }
    ctx.font = FONT; ctx.textBaseline = 'middle';
    // scrolling columns first (clipped right of the frozen one), then the frozen tree column over them
    for (const pass of [false, true]) {
      for (const { c, x, w } of cols) {
        const frozen = c === columns[0];
        if (frozen !== pass) continue;
        const left = frozen ? 0 : Math.max(x, fw), right = Math.min(x + w, viewW);
        if (right <= left) continue;
        ctx.save();
        ctx.beginPath(); ctx.rect(left, HEAD_H, right - left, viewH - HEAD_H); ctx.clip();
        if (frozen) { ctx.fillStyle = C.bg; ctx.fillRect(0, HEAD_H, w, viewH - HEAD_H); for (let l = first; l < last; l++) { const i = lines[l]; if (chosen.has(i) || l === hoverLine) { ctx.fillStyle = chosen.has(i) ? C.sel : C.hover; ctx.fillRect(0, yOf(l), w, ROW_H); } if (i === selected && chosen.size > 1) { ctx.fillStyle = C.accent; ctx.fillRect(0, yOf(l), 2, ROW_H); } } }
        paintColumn(c, x, w, first, last, yOf);
        ctx.restore();
        // column divider
        ctx.fillStyle = frozen ? C.frozenLine : C.grid;
        if (x + w > (frozen ? 0 : fw)) ctx.fillRect(x + w - 1, HEAD_H, 1, viewH - HEAD_H);
      }
    }
    paintHeader(cols, fw);
  }
  function paintColumn(c, x, w, first, last, yOf) {
    if (c.kind === 'tree') return paintTree(x, w, first, last, yOf);
    const max = c.kind === 'num' || c.kind === 'pct' ? barMax(c) : 0;
    for (let l = first; l < last; l++) {
      const i = lines[l], y = yOf(l), v = value(c, i);
      ctx.textAlign = c.align;
      const tx = c.align === 'right' ? x + w - 8 : c.align === 'center' ? x + w / 2 : x + 8;
      if (c.kind === 'tag') {
        if (!v) continue;
        if (opts.colorOf) {   // shared colours: a strip, as in the table
          const strip = sharedColor(c.key, v);
          if (strip) { ctx.fillStyle = strip; ctx.fillRect(x + 1, y + 3, 3, ROW_H - 6); }
          ctx.fillStyle = C.text;
        } else ctx.fillStyle = TAG_COLORS[M.tagSystem[M.tag[i]] % TAG_COLORS.length];   // one colour per top system
        ctx.fillText(v, tx, y + ROW_H / 2);
        continue;
      }
      if (v === v && max > 0 && v > 0) {
        ctx.fillStyle = c.derived != null ? C.barExcess : c.excl ? C.barExcl : C.bar;
        ctx.fillRect(x + 2, y + 3, Math.max(1, Math.min(1, v / max) * (w - 4)), ROW_H - 6);
      }
      ctx.fillStyle = v < 0 ? '#ff8a8a' : C.text;
      ctx.fillText(display(c, v), tx, y + ROW_H / 2);
    }
  }
  function paintTree(x, w, first, last, yOf) {
    ctx.textAlign = 'left';
    for (let l = first; l < last; l++) {
      const i = lines[l], y = yOf(l), d = M.depth[i], ix = x + 6 + d * INDENT;
      // indent guides
      ctx.fillStyle = C.guide;
      for (let g = 0; g < d; g++) ctx.fillRect(x + 6 + g * INDENT + 5, y, 1, ROW_H);
      if (hasKids(i)) {
        ctx.fillStyle = C.muted;
        ctx.beginPath();
        const cx = ix + 5, cy = y + ROW_H / 2;
        if (expanded[i]) { ctx.moveTo(cx - 4, cy - 2); ctx.lineTo(cx + 4, cy - 2); ctx.lineTo(cx, cy + 3); }
        else { ctx.moveTo(cx - 2, cy - 4); ctx.lineTo(cx + 3, cy); ctx.lineTo(cx - 2, cy + 4); }
        ctx.closePath(); ctx.fill();
      }
      // a pinned node: a pin before its name, and its comment after it
      let tx = ix + TOGGLE_W;
      const pinned = pins.has(i);
      if (pinned) { drawPin(tx + 4, y + ROW_H / 2); tx += 13; }
      const name = M.fnDict[M.fn[i]];
      const strip = opts.colorOf ? sharedColor('function', name) : null;   // at the cell's edge, clear of the indent
      if (strip) { ctx.fillStyle = strip; ctx.fillRect(x + 1, y + 3, 3, ROW_H - 6); }
      ctx.fillStyle = matchMark && matchMark[i] ? C.match : C.text;
      ctx.fillText(name, tx, y + ROW_H / 2);
      const note = pinned && pins.get(i);
      if (note) {
        ctx.font = 'italic ' + FONT; ctx.fillStyle = C.comment;
        ctx.fillText('— ' + note.replace(/\s+/g, ' '), tx + ctx.measureText(name).width + 10, y + ROW_H / 2);
        ctx.font = FONT;
      }
    }
  }
  // A small map pin, centred on (x, y)
  function drawPin(x, y) {
    ctx.fillStyle = C.accent;
    ctx.beginPath(); ctx.arc(x, y - 2, 3.6, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.moveTo(x - 2.4, y); ctx.lineTo(x + 2.4, y); ctx.lineTo(x, y + 5); ctx.closePath(); ctx.fill();
    ctx.fillStyle = C.headBg; ctx.beginPath(); ctx.arc(x, y - 2, 1.3, 0, Math.PI * 2); ctx.fill();
  }
  function paintHeader(cols, fw) {
    ctx.fillStyle = C.headBg; ctx.fillRect(0, 0, viewW, HEAD_H);
    ctx.font = HEAD_FONT; ctx.textBaseline = 'middle';
    for (const pass of [false, true]) {
      for (const { c, x, w } of cols) {
        const frozen = c === columns[0];
        if (frozen !== pass) continue;
        const left = frozen ? 0 : Math.max(x, fw), right = Math.min(x + w, viewW);
        if (right <= left) continue;
        ctx.save();
        ctx.beginPath(); ctx.rect(left, 0, right - left, HEAD_H); ctx.clip();
        if (frozen) { ctx.fillStyle = C.headBg; ctx.fillRect(0, 0, w, HEAD_H); }
        const arrow = c.key === sortKey && sortDir ? (sortDir < 0 ? ' ▼' : ' ▲') : '';
        const filtered = filters.has(c.key);
        ctx.fillStyle = arrow || filtered ? C.accent : C.muted;
        // the label follows the column's alignment; a filtered column gets a funnel at its left edge (after
        // the ☰ on Function), as in tarang-table
        const al = frozen ? 'left' : c.align;
        ctx.textAlign = al;
        const textX = frozen ? x + CORNER_W : x + 8;
        ctx.fillText(c.label + arrow, al === 'right' ? x + w - 8 : al === 'center' ? x + w / 2 + (filtered ? 6 : 0) : textX + (filtered ? 13 : 0), HEAD_H / 2);
        if (filtered) {
          const fx = textX - 1, fy = HEAD_H / 2 - 4;
          ctx.fillStyle = C.accent;
          ctx.beginPath(); ctx.moveTo(fx, fy); ctx.lineTo(fx + 8, fy); ctx.lineTo(fx + 5, fy + 4);
          ctx.lineTo(fx + 5, fy + 8); ctx.lineTo(fx + 3, fy + 8); ctx.lineTo(fx + 3, fy + 4); ctx.closePath(); ctx.fill();
        }
        // the ☰ options menu sits in the corner, at the start of the Function header
        if (frozen) { ctx.fillStyle = cornerHover ? C.text : C.muted; ctx.fillText('☰', x + 9, HEAD_H / 2); }
        ctx.restore();
        ctx.fillStyle = frozen ? C.frozenLine : 'rgba(255,255,255,0.08)';
        ctx.fillRect(x + w - 1, 0, 1, HEAD_H);
      }
    }
    ctx.fillStyle = C.frozenLine; ctx.fillRect(0, HEAD_H - 1, viewW, 1);
    // dragging a column: its header lit, and a line where it would go
    if (colDrag && colDrag.active) {
      const it = cols.find(c => c.c === colDrag.col);
      if (it) { ctx.fillStyle = 'rgba(255,213,74,0.12)'; ctx.fillRect(Math.max(it.x, fw), 0, it.w, viewH); }
      const x = Math.max(fw, dropX(colDrag.x));
      ctx.fillStyle = C.accent; ctx.fillRect(x - 1, 0, 3, viewH);
    }
  }

  // ----- hit testing -----
  function hitAt(e) {
    const r = scroller.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
    const cols = layout(), fw = frozenW();
    let col = null;
    for (const it of cols) {
      const frozen = it.c === columns[0];
      const left = frozen ? 0 : Math.max(it.x, fw);
      if (px >= left && px < it.x + it.w) { col = it; break; }
    }
    if (py < HEAD_H) {
      // near a header's right edge: resize
      const edge = cols.find(it => Math.abs(px - (it.x + it.w)) <= 4 && (it.c === columns[0] || it.x + it.w > fw));
      return { header: true, col, edge, corner: !edge && !!col && col.c === columns[0] && px - col.x < CORNER_W - 4 };
    }
    const l = Math.floor((py - HEAD_H + vy) / ROW_H);
    if (l < 0 || l >= lineCount) return { col };
    const i = lines[l];
    let toggle = false;
    if (col && col.c.kind === 'tree') {
      const ix = col.x + 6 + M.depth[i] * INDENT;
      toggle = px >= ix - 2 && px < ix + TOGGLE_W && hasKids(i);
    }
    return { line: l, node: i, col, toggle };
  }

  // ----- mouse -----
  let resizing = null, cornerHover = false;
  let colDrag = null;   // dragging a header sideways: { col, startX, x, active }
  scroller.addEventListener('mousemove', e => {
    if (resizing || colDrag) return;
    const h = hitAt(e);
    scroller.style.cursor = h.header && h.edge ? 'col-resize' : h.header ? 'pointer' : h.toggle ? 'pointer' : '';
    const ch = !!h.corner;
    if (ch !== cornerHover) { cornerHover = ch; draw(); }
    const l = h.line ?? -1;
    if (l !== hoverLine) { hoverLine = l; draw(); }
  });
  scroller.addEventListener('mouseleave', () => { if (hoverLine !== -1) { hoverLine = -1; draw(); } });
  scroller.addEventListener('mousedown', e => {
    if (e.button !== 0) return;
    const h = hitAt(e);
    if (h.header && h.edge) {
      resizing = { col: h.edge.c, startX: e.clientX, startW: h.edge.c.width };
      e.preventDefault();
      return;
    }
    // any header but Function (always first) can be dragged sideways to move it
    if (h.header && h.col && h.col.c !== columns[0]) {
      colDrag = { col: h.col.c, startX: e.clientX, x: e.clientX, active: false };
      e.preventDefault();
    }
  });
  window.addEventListener('mousemove', onResizeMove);
  window.addEventListener('mouseup', onResizeEnd);
  function onResizeMove(e) {
    if (colDrag) {
      if (!colDrag.active && Math.abs(e.clientX - colDrag.startX) < 5) return;   // a click, so far
      colDrag.active = true; colDrag.x = e.clientX;
      scroller.style.cursor = 'grabbing';
      draw();
      return;
    }
    if (!resizing) return;
    resizing.col.width = Math.max(50, resizing.startW + e.clientX - resizing.startX);
    resizing.moved = true;
    updateSpacer(); draw();
  }
  function onResizeEnd() {
    if (colDrag) {
      const d = colDrag;
      colDrag = null;
      scroller.style.cursor = '';
      if (d.active) {
        swallowClick = true;   // a drag must not also sort
        // before that column, or just after the last shown one (not past the hidden ones)
        const before = dropBefore(d.x), from = columns.indexOf(d.col);
        const shown = shownCols(), last = shown[shown.length - 1];
        const to = before ? columns.indexOf(before) - (columns.indexOf(before) > from ? 1 : 0)
          : columns.indexOf(last) + (columns.indexOf(last) > from ? 0 : 1);
        moveColumnTo(d.col.key, to);
      } else draw();
      return;
    }
    if (resizing) { const moved = resizing.moved; resizing = null; if (moved) { swallowClick = true; emit('columns'); } }
  }
  // Where a dragged column would land: before the shown column whose middle is right of the pointer (null: at the end)
  function dropBefore(clientX) {
    const r = scroller.getBoundingClientRect(), px = clientX - r.left;
    for (const { c, x, w } of layout()) {
      if (c === columns[0]) continue;
      if (px < x + w / 2) return c;
    }
    return null;
  }
  function dropX(clientX) {
    const before = dropBefore(clientX), cols = layout();
    if (before) return cols.find(it => it.c === before).x;
    const last = cols[cols.length - 1];
    return last ? last.x + last.w : frozenW();
  }
  let swallowClick = false;
  scroller.addEventListener('click', e => {
    if (swallowClick) { swallowClick = false; return; }
    const h = hitAt(e);
    if (h.header) {
      if (h.corner) { openOptionsMenu(e.clientX, e.clientY + 8); return; }   // ☰
      if (h.edge || !h.col) return;
      const c = h.col.c;
      if (e.ctrlKey || e.metaKey) { openColumnBox(c, e.clientX, e.clientY); return; }   // its filter / sort box
      // numbers: big first, then small first, then data order; text: A→Z, Z→A, data order
      const firstDir = c.kind === 'num' || c.kind === 'pct' ? -1 : 1;
      const next = c.key !== sortKey || !sortDir ? firstDir : sortDir === firstDir ? -firstDir : 0;
      setSort(c.key, next);
      return;
    }
    if (h.node == null) return;
    scroller.focus({ preventScroll: true });
    if (h.toggle) {   // ▸: open / close (Shift: everything below); the selection is left as it is
      if (e.shiftKey) (expanded[h.node] ? collapseBelow : expandBelow)(h.node);
      else toggle(h.node);
      if (chosen.size <= 1) select(h.node, false);
      return;
    }
    if (e.shiftKey) selectRange(h.node, e.ctrlKey || e.metaKey);
    else if (e.ctrlKey || e.metaKey) toggleChosen(h.node);
    else select(h.node, false);
  });
  scroller.addEventListener('dblclick', e => {
    const h = hitAt(e);
    if (h.node != null && !h.toggle && !h.header && hasKids(h.node)) toggle(h.node);
  });
  scroller.addEventListener('contextmenu', e => {
    const h = hitAt(e);
    if (h.header && h.corner) { e.preventDefault(); openOptionsMenu(e.clientX, e.clientY); return; }
    if (h.header && h.col) { e.preventDefault(); openColumnBox(h.col.c, e.clientX, e.clientY); return; }
    if (h.node == null) return;
    e.preventDefault();
    if (!chosen.has(h.node)) select(h.node, false);   // right-clicking inside a selection keeps it
    openMenu(e.clientX, e.clientY, h.node);
  });

  // ----- keyboard -----
  scroller.addEventListener('keydown', e => {
    if (!M || !lineCount) return;
    let l = selected >= 0 ? lineOfNode(selected) : -1;
    const page = Math.max(1, Math.floor((viewH - HEAD_H) / ROW_H) - 1);
    // moving the cursor; with Shift, the selection stretches from the anchor to it
    const go = to => {
      to = Math.max(0, Math.min(lineCount - 1, to));
      if (e.shiftKey && anchor >= 0) selectRange(lines[to]); else select(lines[to], false);
      e.preventDefault();
    };
    if (e.key === 'Escape' && chosen.size) { e.preventDefault(); select(-1, false); return; }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'a' || e.key === 'A')) { e.preventDefault(); setSelection(Array.from(lines.subarray(0, lineCount))); return; }
    switch (e.key) {
      case 'ArrowDown': return go(l + 1);
      case 'ArrowUp': return go(l < 0 ? 0 : l - 1);
      case 'PageDown': return go(l + page);
      case 'PageUp': return go(l - page);
      case 'Home': return go(0);
      case 'End': return go(lineCount - 1);
    }
    if (selected < 0) return;
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      if (hasKids(selected) && !expanded[selected]) toggle(selected);
      else if (hasKids(selected)) go(l + 1);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      if (expanded[selected] && hasKids(selected)) toggle(selected);
      else if (M.parent[selected] >= 0) select(M.parent[selected], false);
    } else if (e.key === 'Enter') { e.preventDefault(); if (hasKids(selected)) toggle(selected); }
    else if (e.key === '*') { e.preventDefault(); expandBelow(selected); }
    else if (e.key === 'h' || e.key === 'H') { e.preventDefault(); hotPath(selected); }
    else if ((e.key === 'p' || e.key === 'P') && !e.ctrlKey && !e.metaKey) {   // pin / unpin the selection
      e.preventDefault();
      const sel = chosen.size ? [...chosen] : [selected], on = !sel.every(i => pins.has(i));
      for (const i of sel) { if (on) pins.set(i, pins.get(i) || ''); else pins.delete(i); }
      pinChanged();
    }
    else if ((e.ctrlKey || e.metaKey) && (e.key === 'c' || e.key === 'C')) { e.preventDefault(); copyPaths(); }
  });

  // ----- expand / collapse -----
  function toggle(i) { expanded[i] = expanded[i] ? 0 : 1; rebuildLines(); emit('expand'); }
  function expandBelow(i) { expanded.fill(1, i, M.end[i]); rebuildLines(); emit('expand'); }
  function collapseBelow(i) { expanded.fill(0, i, M.end[i]); rebuildLines(); emit('expand'); }
  function expandAll() { if (M) { expanded.fill(1); rebuildLines(); emit('expand'); } }
  function collapseAll() { if (M) { expanded.fill(0); rebuildLines(); emit('expand'); } }
  function expandToDepth(n) { if (!M) return; for (let i = 0; i < M.n; i++) expanded[i] = M.depth[i] < n ? 1 : 0; rebuildLines(); emit('expand'); }
  // Open the path to a node, select it and scroll it to the middle. False if the search / filters hide it
  function reveal(i) {
    if (!M || i < 0 || i >= M.n) return false;
    for (let p = M.parent[i]; p >= 0; p = M.parent[p]) expanded[p] = 1;
    rebuildLines(false);
    emit('expand');
    if (lineOfNode(i) < 0) return false;
    select(i, true);
    return true;
  }
  // Open the chain of biggest children from a node, and select the end of it. `field`: which inclusive metric
  // or derived column (excess …) "biggest" means (default: the last one chosen in the toolbar, at first bytes)
  let hotField = METRICS[0].field;
  const valuesOf = field => { const d = DERIVED.findIndex(x => x.key === field); return d >= 0 ? M.derived[d] : M.inc[metricIndex(field)]; };
  function hotPath(from = selected, field) {
    if (!M || !M.n) return -1;
    if (field != null) hotField = field;
    let i = from;
    const a = valuesOf(hotField);
    if (i < 0) { i = M.roots[0]; for (const r of M.roots) if (a[r] > a[i]) i = r; }
    for (let p = M.parent[i]; p >= 0; p = M.parent[p]) expanded[p] = 1;   // its own path is open
    for (;;) {
      if (keep && !keep[i]) break;
      let best = -1;
      const s = M.kidsStart[i];
      for (let c = 0; c < M.kidsCount[i]; c++) {
        const k = M.kids[s + c];
        if ((!keep || keep[k]) && (best < 0 || a[k] > a[best])) best = k;
      }
      if (best < 0) break;
      expanded[i] = 1;
      i = best;
    }
    // a deep path indents far: widen the Function column so its end can be read (up to 60% of the view)
    ctx.font = FONT;
    const need = 6 + M.depth[i] * INDENT + TOGGLE_W + ctx.measureText(M.fnDict[M.fn[i]]).width + 12;
    if (need > columns[0].width) { columns[0].width = Math.min(Math.ceil(need), Math.max(columns[0].width, Math.floor(viewW * 0.6))); updateSpacer(); }
    rebuildLines(false);
    select(i, true);
    emit('expand');
    return i;
  }

  // ----- search -----
  // 'abc': functions containing abc (any case), with the path to each · '~abc': also everything below a match ·
  // 'tag:Audio': nodes with that tag · words combine (all must hold)
  function setSearch(text) {
    search = String(text || '').trim();
    const box = q('.tarang-tree-search');
    if (box.value.trim() !== search) box.value = search;
    applyFilters(true);
    emit('search');
  }
  // ----- column filters -----
  // Numbers: >1MiB  <=500  =0  !=0  >=1MiB<10MiB (both)  a | b (either). Units: B KiB MiB GiB TiB (1024s; KB MB GB
  // TB are read the same), % (of that metric's total, so ">1%" hides what is smaller than 1% of everything).
  // Text: abc (contains)  =abc (exactly)  !abc (doesn't contain)  !=abc (isn't). With "|", any of the plain
  // ones and none of the "!" ones. Case is ignored.
  const UNITS = { b: 1, kib: 1024, mib: 1024 ** 2, gib: 1024 ** 3, tib: 1024 ** 4, kb: 1024, mb: 1024 ** 2, gb: 1024 ** 3, tb: 1024 ** 4 };
  const NUM_TERM = /^(>=|<=|!=|>|<|=)?(-?(?:\d+\.?\d*|\.\d+))(kib|mib|gib|tib|kb|mb|gb|tb|b|%)?/i;
  function percentBase(col) {
    if (col.derived != null) { let s = 0; for (const r of M.roots) s += M.derived[col.derived][r]; return s; }
    return M.total[col.metric];
  }
  function compileFilter(col, text) {
    const alts = String(text).split('|').map(s => s.trim()).filter(Boolean);
    if (!alts.length) return null;
    if (col.kind === 'tree' || col.kind === 'tag') {
      const { dict, codes } = textOf(col);
      const terms = alts.map(a => (a.startsWith('!=') ? { not: true, eq: a.slice(2).trim().toLowerCase() }
        : a.startsWith('=') ? { eq: a.slice(1).trim().toLowerCase() }
        : a.startsWith('!') ? { not: true, has: a.slice(1).trim().toLowerCase() }
        : { has: a.toLowerCase() }));
      const yes = terms.filter(t => !t.not), no = terms.filter(t => t.not);
      // a tag is a chain of systems: =rendering also matches rendering.shaders and everything under it
      const chain = col.kind === 'tag';
      const is = (t, v) => (t.eq != null ? v === t.eq || (chain && v.startsWith(t.eq + '.')) : v.includes(t.has));
      // decided once per dictionary entry, not per node
      const ok = Uint8Array.from(dict, s => { const v = s.toLowerCase(); return (!yes.length || yes.some(t => is(t, v))) && no.every(t => !is(t, v)) ? 1 : 0; });
      return i => ok[codes[i]] === 1;
    }
    const conds = alts.map(a => {
      let rest = a.replace(/[\s,]/g, '');
      const parts = [];
      while (rest) {
        const m = NUM_TERM.exec(rest);
        if (!m) throw new Error(`Can't read "${a}". Try >1MiB, <=500, >=1MiB<10MiB, >1%, =0`);
        let v = parseFloat(m[2]);
        const unit = (m[3] || '').toLowerCase();
        if (unit === '%') v = col.kind === 'pct' ? v : (v / 100) * percentBase(col);
        else if (unit) v *= UNITS[unit];
        parts.push([m[1] || '=', v]);
        rest = rest.slice(m[0].length);
      }
      return parts;
    });
    const hold = (op, v, x) => (op === '>' ? v > x : op === '<' ? v < x : op === '>=' ? v >= x : op === '<=' ? v <= x : op === '!=' ? v !== x : v === x);
    return i => { const v = value(col, i); return v === v && conds.some(parts => parts.every(([op, x]) => hold(op, v, x))); };
  }
  // A column's filter ('' / null removes it); returns an error message if the text can't be read, else null
  function setFilter(key, text) {
    const col = columnOf(key);
    if (!col) return `No column "${key}"`;
    const t = String(text ?? '').trim().replace(/^[|\s]+|[|\s]+$/g, '');   // a "|" left at either end (while choosing more) is dropped
    if (!t) filters.delete(col.key);
    else {
      let test;
      try { test = M ? compileFilter(col, t) : null; } catch (err) { return err.message; }
      filters.set(col.key, { text: t, test });
    }
    applyFilters();
    renderFilterUi();
    emit('filter');
    return null;
  }
  function clearFilters() {
    if (!filters.size) return;
    filters.clear();
    applyFilters();
    renderFilterUi();
    emit('filter');
  }
  // After new data: the same filter texts, read against it (any that no longer read are dropped)
  function recompileFilters() {
    for (const [key, f] of filters) {
      try { f.test = compileFilter(columnOf(key), f.text); } catch { filters.delete(key); }
    }
    renderFilterUi();
  }
  function renderFilterUi() {
    const b = q('.tarang-tree-clear-filters');
    b.hidden = !filters.size;
    b.textContent = `Clear filters (${filters.size})`;
    draw();
  }
  let matchCount = 0;
  function applyFilters(jumpToMatch = false) {
    if (!M) return;
    matchMark = null; keep = null; matchCount = 0;
    const words = search.split(/\s+/).filter(Boolean);
    const tags = words.filter(w => /^tag:/i.test(w)).map(w => w.slice(4).toLowerCase());
    const rest = words.filter(w => !/^tag:/i.test(w));
    let below = false;
    const textParts = rest.map(w => { if (w.startsWith('~')) { below = true; return w.slice(1); } return w; }).filter(Boolean);
    const needle = textParts.join(' ').toLowerCase();
    const n = M.n, searching = !!(needle || tags.length), tests = [...filters.values()].map(f => f.test).filter(Boolean);
    if (searching || tests.length) {
      // the search matches per dictionary entry first (far fewer than nodes)
      const fnOk = needle ? Uint8Array.from(M.fnDict, f => (f.toLowerCase().includes(needle) ? 1 : 0)) : null;
      // tag:rendering matches rendering and everything under it (rendering.shaders, …)
      const tagOk = tags.length ? Uint8Array.from(M.tagDict, t => { const v = t.toLowerCase(); return tags.some(x => v === x || v.startsWith(x + '.')) ? 1 : 0; }) : null;
      const hit = new Uint8Array(n);
      for (let i = 0; i < n; i++) {
        if ((fnOk && !fnOk[M.fn[i]]) || (tagOk && !tagOk[M.tag[i]])) continue;
        let ok = true;
        for (const t of tests) if (!t(i)) { ok = false; break; }
        if (ok) { hit[i] = 1; matchCount++; }
      }
      // Kept: the matches, the path to each (and with ~, everything below them). Opened: with a search, every
      // path to a match; with column filters only, the path to a match whose parent doesn't match (a filter
      // like ">1%" just prunes the tree as it is, while ">1MiB" on exclusive bytes opens up to what it found)
      keep = new Uint8Array(n);
      const onPath = new Uint8Array(n), opened = new Uint8Array(n);   // each path is walked once
      for (let i = 0; i < n; i++) {
        if (!hit[i]) continue;
        keep[i] = 1;
        if (below) keep.fill(1, i, M.end[i]);   // ~: its subtree (one id range)
        for (let p = M.parent[i]; p >= 0 && !onPath[p]; p = M.parent[p]) { onPath[p] = 1; keep[p] = 1; }
        const p0 = M.parent[i];
        if (searching || (p0 >= 0 && !hit[p0])) {
          for (let p = p0; p >= 0 && !opened[p]; p = M.parent[p]) { opened[p] = 1; expanded[p] = 1; }
        }
      }
      if (searching) matchMark = hit;   // search matches are drawn highlighted (filter matches would be most rows)
    }
    rebuildLines(false);
    // a new search goes to its first match; otherwise keep the selected row in view
    if (matchMark && matchCount && (jumpToMatch || selected < 0)) { for (let l = 0; l < lineCount; l++) if (matchMark[lines[l]]) { select(lines[l], true); break; } }
    else if (selected >= 0 && !scrollToNode(selected, false)) setVY(0);
  }
  let searchTimer = 0;
  q('.tarang-tree-search').addEventListener('input', e => { clearTimeout(searchTimer); searchTimer = setTimeout(() => setSearch(e.target.value), 200); });
  q('.tarang-tree-search').addEventListener('keydown', e => { if (e.key === 'Escape') setSearch(''); if (e.key === 'Enter') { clearTimeout(searchTimer); setSearch(e.target.value); } });

  // ----- sort / percent / columns -----
  function setSort(key, dir) {
    sortKey = dir ? key : null; sortDir = dir || 0;
    sortStamp++; cmp = comparator();
    rebuildLines();
    emit('sort');
  }
  function setPercentOf(field) {
    pctMetric = metricIndex(field);

    if (sortKey && columns.find(c => c.key === sortKey)?.kind === 'pct') { sortStamp++; cmp = comparator(); }
    applyFilters();   // filters on the % columns measure this too
    renderStatus();
  }
  const columnOf = key => columns.find(x => x.key === key || x.label === key);
  function setColumnVisible(key, on) {
    const c = columnOf(key);
    if (!c || c === columns[0]) return;   // the tree column always shows
    c.visible = !!on;
    updateSpacer(); draw();
    emit('columns');
  }
  // Move a column to a place in the order (Function stays first, so 1 is the first place after it)
  function moveColumnTo(key, index) {
    const c = columnOf(key);
    if (!c || c === columns[0]) return;
    columns.splice(columns.indexOf(c), 1);
    columns.splice(Math.max(1, Math.min(columns.length, index)), 0, c);
    updateSpacer(); draw();
    if (menu && menu.dataset.kind === 'options') { const st = menu.scrollTop; openOptionsMenu(+menu.dataset.x, +menu.dataset.y); menu.scrollTop = st; }   // keep it in step
    emit('columns');
  }

  // ----- pins and comments -----
  // A pinned node keeps a comment ('' for none); pinning never changes what's shown or how it's sorted
  function pinChanged() { draw(); renderStatus(); emit('pin'); }
  function pin(i, comment) {
    if (!M || i < 0 || i >= M.n) return;
    pins.set(i, comment != null ? String(comment) : pins.get(i) || '');
    pinChanged();
  }
  function unpin(i) { if (pins.delete(i)) pinChanged(); }
  function togglePin(i) { if (pins.has(i)) unpin(i); else pin(i); }
  // pins it too; '' keeps it pinned without a comment. A change calls opts.onComment({ node, path, comment,
  // previous, fn }) and emits 'comment' (pinning alone, or setPins, doesn't)
  function setComment(i, text) {
    if (!M || i < 0 || i >= M.n) return;
    const comment = String(text ?? '').trim(), previous = pins.get(i) || '';
    pin(i, comment);
    if (comment === previous) return;
    if (opts.onComment) {
      try { opts.onComment({ node: i, path: pathKey(i), comment, previous, fn: M.fnDict[M.fn[i]] }); } catch (err) { console.error('[tarang-tree] onComment:', err); }
    }
    emit('comment');
  }
  // [{ node, path, comment }] in tree (data) order; path: its place in the data, as links use (pathKey)
  function pinList() { return [...pins].sort((a, b) => a[0] - b[0]).map(([node, comment]) => ({ node, path: pathKey(node), comment })); }
  // Replace the pins: [{ node } or { path }, comment] (paths that aren't in this capture are skipped); returns
  // how many were placed
  function setPins(list) {
    pins.clear();
    let placed = 0;
    for (const p of list || []) {
      const node = p.node != null ? p.node : (findPath(p.path) || {}).complete ? findPath(p.path).node : -1;
      if (node >= 0 && node < M.n) { pins.set(node, String(p.comment || '')); placed++; }
    }
    pinChanged();
    return placed;
  }
  // A box to write a node's comment in (from the row menu, or your own button: tree.openCommentBox). What's
  // typed is saved as it's typed (a moment after each pause) and whenever the box closes, however it closes:
  // there's no Save to forget. The first words pin the node; opening it and closing it empty changes nothing
  const COMMENT_SAVE_MS = 400;
  function openCommentBox(i, x, y) {
    if (!M || i < 0) return;
    showMenu(x, y, m => {
      m.classList.add('tarang-tree-pop');
      const title = document.createElement('div');
      title.className = 'tarang-tree-pop-title';
      title.innerHTML = `Comment <span>on ${esc(M.fnDict[M.fn[i]])}</span>`;
      const box = document.createElement('textarea');
      box.className = 'tarang-tree-comment-input'; box.rows = 3; box.spellcheck = true;
      box.placeholder = 'What is this, or what to do about it…';
      box.value = pins.get(i) || '';
      const hint = document.createElement('div');
      hint.className = 'tarang-tree-pop-help';
      hint.textContent = 'Saved as you type. Writing one pins the node.';
      const foot = document.createElement('div');
      foot.className = 'tarang-tree-pop-row tarang-tree-pop-foot';
      foot.innerHTML = '<button type="button" data-unpin>Unpin</button><button type="button" data-done>Done</button>';
      m.append(title, box, hint, foot);
      let timer = 0, unpinned = false;
      const save = () => {
        clearTimeout(timer);
        if (unpinned) return;
        const text = box.value.trim();
        if (!pins.has(i) && !text) return;        // nothing written on an unpinned node: leave it be
        if (text !== (pins.get(i) || '')) setComment(i, text);
      };
      const un = foot.querySelector('[data-unpin]');
      un.hidden = !pins.has(i);
      box.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => { save(); un.hidden = !pins.has(i); }, COMMENT_SAVE_MS); });
      m.onClose = save;                           // Done, Esc, Enter, a click elsewhere: all keep what's there
      foot.querySelector('[data-done]').addEventListener('click', () => { closeMenu(); scroller.focus({ preventScroll: true }); });
      un.addEventListener('click', () => { unpinned = true; clearTimeout(timer); unpin(i); closeMenu(); });
      box.addEventListener('keydown', e => {
        // Enter finishes (Shift+Enter for a new line); Esc closes too, keeping what's written
        if ((e.key === 'Enter' && !e.shiftKey) || e.key === 'Escape') { e.preventDefault(); closeMenu(); scroller.focus({ preventScroll: true }); }
      });
      setTimeout(() => { box.focus(); box.setSelectionRange(box.value.length, box.value.length); });
    });
  }

  // ----- selection, status line -----
  // `selected` is the row you're on (the cursor: keys move it, the status line shows its path); `chosen` is
  // every selected node, which is just that one unless Ctrl/⌘+click or Shift+click added more
  const chosen = new Set();
  let anchor = -1;   // where a Shift+click range starts
  function select(i, center = true) {
    selected = i; anchor = i;
    chosen.clear();
    if (i >= 0) { chosen.add(i); scrollToNode(i, center); }
    selectionChanged();
  }
  function selectionChanged() { if (!restoring) linkNote = ''; draw(); renderStatus(); emit('select'); }
  // Ctrl/⌘+click: one node in or out, without losing the rest
  function toggleChosen(i) {
    if (chosen.has(i)) chosen.delete(i); else chosen.add(i);
    selected = i; anchor = i;
    selectionChanged();
  }
  // Shift+click / Shift+arrows: every shown row from the anchor to this one (Ctrl/⌘ too: added to the rest)
  function selectRange(i, add = false) {
    const a = anchor >= 0 ? lineOfNode(anchor) : -1, b = lineOfNode(i);
    if (a < 0 || b < 0) { select(i, false); return; }
    if (!add) chosen.clear();
    for (let l = Math.min(a, b); l <= Math.max(a, b); l++) chosen.add(lines[l]);
    selected = i;
    scrollToNode(i, false);
    selectionChanged();
  }
  function setSelection(nodes) {
    chosen.clear();
    for (const i of nodes) if (i >= 0 && i < M.n) chosen.add(i);
    selected = chosen.size ? [...chosen][chosen.size - 1] : -1;
    anchor = selected;
    if (selected >= 0) scrollToNode(selected, false);
    selectionChanged();
  }
  // The selection in tree order (as shown; any hidden by filters after, in data order)
  function selection() {
    return [...chosen].sort((a, b) => { const la = lineOfNode(a), lb = lineOfNode(b); return (la < 0) - (lb < 0) || la - lb || a - b; });
  }
  // Selected nodes without a selected ancestor: summing these doesn't count anything twice
  function selectionTops() { return selection().filter(i => { for (let p = M.parent[i]; p >= 0; p = M.parent[p]) if (chosen.has(p)) return false; return true; }); }
  function pathOf(i) { const out = []; for (let p = i; p >= 0; p = M.parent[p]) out.unshift(p); return out; }
  // A node's call stack as text for pasting: its numbers in a # header, then the path from the root, each
  // frame indented one more space
  function pathText(i) {
    const at = f => M.inc[METRICS.findIndex(m => m.field === f)][i];
    const calls = c => `${c} call${c === 1 ? '' : 's'}`;
    const rule = '# ' + Array(18).fill('-').join(' ');
    return [
      rule,
      `# Active:   ${at('inclusive_size_bytes')} bytes over ${calls(at('inclusive_allocation_count'))}`,
      `# Lifetime: ${at('lifetime_size_bytes')} bytes over ${calls(at('lifetime_allocation_count'))}`,
      `# Tag : ${M.tagDict[M.tag[i]] || '(none)'}`,
      rule,
      ...pathOf(i).map((p, d) => ' '.repeat(d) + M.fnDict[M.fn[p]]),
    ].join('\n') + '\n';
  }
  // Every selected node's call stack, one after another (a blank line between)
  function copyPaths(nodes = selection()) {
    if (nodes.length && navigator.clipboard) navigator.clipboard.writeText(nodes.map(pathText).join('\n'));
  }
  function renderStatus() {
    const crumb = q('.tarang-tree-crumb'), stats = q('.tarang-tree-sel-stats');
    if (!M || selected < 0) { crumb.textContent = M ? 'Click a row to see its path (Ctrl/⌘+click or Shift+click to select more).' : ''; stats.textContent = ''; return; }
    crumb.innerHTML = pathOf(selected).map(p => `<a data-node="${p}">${esc(M.fnDict[M.fn[p]])}</a>`).join('<span class="tarang-tree-sep">›</span>');
    crumb.scrollLeft = crumb.scrollWidth;   // a long path shows its end (the selected node)
    const bytes = METRICS.findIndex(m => m.field === 'inclusive_size_bytes');
    const count = METRICS.findIndex(m => m.field === 'inclusive_allocation_count');
    const b = c => (human ? fmtBytes(c) : `${intFmt.format(c)} B`);
    if (chosen.size > 1) {
      // the selection added up; a node inside another selected one is already in that one's inclusive values
      const tops = selectionTops();
      let sb = 0, se = 0, sc = 0;
      for (const i of chosen) se += M.exc[bytes][i];
      for (const i of tops) { sb += M.inc[bytes][i]; sc += M.inc[count][i]; }
      const nested = chosen.size - tops.length;
      stats.textContent = `${intFmt.format(chosen.size)} selected · ${b(sb)} incl · ${b(se)} excl · ${intFmt.format(sc)} allocs`
        + (nested ? ` (${intFmt.format(nested)} inside others, counted once)` : '') + (linkNote ? ` · ${linkNote}` : '');
      return;
    }
    stats.textContent = `${b(M.inc[bytes][selected])} incl · ${b(M.exc[bytes][selected])} excl · ${intFmt.format(M.inc[count][selected])} allocs`
      + (M.tagDict[M.tag[selected]] ? ` · ${M.tagDict[M.tag[selected]]}` : '') + (pins.get(selected) ? ` · 📌 ${pins.get(selected)}` : '') + (linkNote ? ` · ${linkNote}` : '');
  }
  // ----- links: selection, search, filters and sort kept in the page address (opts.urlState) -----
  // A node is its path of places in the data: 0.3.1 = the first root's 4th child's 2nd child. The data's order
  // is stable and sorting never changes these, so the same capture gives the same node
  const P = (opts.urlState || 'tree') + '.';
  const MAX_LINKED = 200;   // past this many selected nodes, the address keeps only the cursor row
  function pathKey(i) { return pathOf(i).map(p => M.childIndex[p]).join('.'); }
  // -> { node, complete } (complete: false when the data ends before the path does), or null
  function findPath(key) {
    const parts = String(key).split('.');
    if (!M || !parts.length || parts.some(x => !/^\d+$/.test(x))) return null;
    let node = -1, depth = 0;
    for (const s of parts) {
      const k = +s;
      let found = -1;
      if (node < 0) { for (const r of M.roots) if (M.childIndex[r] === k) { found = r; break; } }
      else { const st = M.kidsStart[node]; for (let c = 0; c < M.kidsCount[node]; c++) { const x = M.kids[st + c]; if (M.childIndex[x] === k) { found = x; break; } } }
      if (found < 0) break;
      node = found; depth++;
    }
    return node < 0 ? null : { node, complete: depth === parts.length };
  }
  // The page address with this tree's state (other parameters left as they are)
  function linkFor(nodes = selection()) {
    const u = new URL(location.href), sp = u.searchParams;
    for (const k of [...sp.keys()]) if (k.startsWith(P)) sp.delete(k);
    const sel = nodes.length > MAX_LINKED ? (selected >= 0 ? [selected] : []) : nodes;
    if (sel.length) sp.set(P + 'sel', sel.map(pathKey).join(','));
    if (search) sp.set(P + 'q', search);
    for (const [k, f] of filters) sp.set(P + 'f.' + k, f.text);
    if (sortKey && sortDir) sp.set(P + 'sort', (sortDir < 0 ? '-' : '') + sortKey);
    return u.toString();
  }
  let urlTimer = 0, restoring = false, urlRead = false;
  function writeUrl() {
    if (!opts.urlState || restoring || !M) return;
    clearTimeout(urlTimer);
    urlTimer = setTimeout(() => { try { history.replaceState(history.state, '', linkFor()); } catch { /* not allowed here */ } }, 150);
  }
  // On the first load: sort, filters, search, then the selection (its paths opened)
  function readUrl() {
    if (!opts.urlState || urlRead) return;
    urlRead = true;
    let sp;
    try { sp = new URL(location.href).searchParams; } catch { return; }
    restoring = true;
    try {
      const sort = sp.get(P + 'sort');
      if (sort && columnOf(sort.replace(/^-/, ''))) setSort(sort.replace(/^-/, ''), sort.startsWith('-') ? -1 : 1);
      for (const [k, v] of sp) if (k.startsWith(P + 'f.')) setFilter(k.slice(P.length + 2), v);
      if (sp.get(P + 'q')) setSearch(sp.get(P + 'q'));
      const keys = (sp.get(P + 'sel') || '').split(',').filter(Boolean);
      const found = keys.map(findPath).filter(Boolean);
      if (found.length) {
        for (const { node } of found) for (let p = M.parent[node]; p >= 0; p = M.parent[p]) expanded[p] = 1;
        rebuildLines(false);
        setSelection(found.map(f => f.node));
        scrollToNode(found[0].node, true);
      }
      const short = keys.length - found.filter(f => f.complete).length;
      if (short) linkNote = `${short} linked path${short === 1 ? '' : 's'} not all in this capture: opened as far as ${short === 1 ? 'it goes' : 'they go'}`;
      renderStatus();
    } finally { restoring = false; }
    writeUrl();
  }
  let linkNote = '';
  function copyLink(nodes) { if (navigator.clipboard) navigator.clipboard.writeText(linkFor(nodes)); }

  q('.tarang-tree-crumb').addEventListener('click', e => { const n = e.target.dataset && e.target.dataset.node; if (n != null) select(+n, true); });
  function renderInfo() {
    if (!M) { q('.tarang-tree-info').textContent = ''; return; }
    const parts = [`${intFmt.format(M.n)} nodes`, `${intFmt.format(lineCount)} shown`];
    if (search) parts.push(`${intFmt.format(matchCount)} match${matchCount === 1 ? '' : 'es'}`);
    q('.tarang-tree-info').textContent = parts.join(' · ');
  }

  // ----- toolbar -----
  q('.tarang-tree-clear-filters').addEventListener('click', () => clearFilters());
  function setHuman(on) { human = !!on; draw(); renderStatus(); }

  // ----- popup menus -----
  let menu = null;
  // a menu can leave something to do as it closes (menu.onClose), however it closes: the comment box saves
  function closeMenu() { if (menu) { const m = menu; menu = null; m.remove(); document.removeEventListener('mousedown', outside, true); if (m.onClose) m.onClose(); } }
  function outside(e) { if (menu && !menu.contains(e.target)) closeMenu(); }
  function showMenu(x, y, build) {
    closeMenu();
    menu = document.createElement('div');
    menu.className = 'tarang-tree-menu';
    build(menu);
    root.appendChild(menu);
    const w = menu.offsetWidth, h = menu.offsetHeight;
    menu.style.left = Math.max(8, Math.min(x, innerWidth - w - 8)) + 'px';
    menu.style.top = Math.max(8, Math.min(y, innerHeight - h - 8)) + 'px';
    setTimeout(() => document.addEventListener('mousedown', outside, true));
  }
  function item(m, label, fn, hint) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'tarang-tree-menu-item';
    b.innerHTML = `<span>${esc(label)}</span>${hint ? `<kbd>${esc(hint)}</kbd>` : ''}`;
    b.addEventListener('click', () => { closeMenu(); fn(); });
    m.appendChild(b);
  }
  function openMenu(x, y, node) {
    showMenu(x, y, m => {
      const name = M.fnDict[M.fn[node]];
      // pins: this row, or every selected row when it's one of several
      const many = chosen.size > 1 && chosen.has(node), group = many ? [...chosen] : [node];
      const allPinned = group.every(i => pins.has(i));
      item(m, allPinned ? (many ? `Unpin these ${intFmt.format(group.length)}` : 'Unpin') : (many ? `Pin these ${intFmt.format(group.length)}` : 'Pin'), () => {
        for (const i of group) { if (allPinned) pins.delete(i); else pins.set(i, pins.get(i) || ''); }
        pinChanged();
      }, 'P');
      item(m, pins.get(node) ? 'Edit comment…' : 'Add comment…', () => openCommentBox(node, x, y));
      const sep = document.createElement('div'); sep.className = 'tarang-tree-menu-sep'; m.appendChild(sep);
      if (hasKids(node)) {
        item(m, 'Expand everything below', () => expandBelow(node), '*');
        item(m, 'Collapse everything below', () => collapseBelow(node), 'Shift+click ▸');
        item(m, 'Hot path from here by bytes', () => hotPath(node, 'inclusive_size_bytes'));
        item(m, 'Hot path from here by allocations', () => hotPath(node, 'inclusive_allocation_count'));
        item(m, 'Hot path from here by excess allocations', () => hotPath(node, 'excess_allocation_count'));
      }
      item(m, `Search for "${name.length > 40 ? name.slice(0, 40) + '…' : name}"`, () => setSearch(name));
      item(m, 'Search it with everything below (~)', () => setSearch('~' + name));
      if (M.tagDict[M.tag[node]]) item(m, `Only tag "${M.tagDict[M.tag[node]]}"`, () => setSearch('tag:' + M.tagDict[M.tag[node]]));
      if (chosen.size > 1 && chosen.has(node)) item(m, `Copy ${intFmt.format(chosen.size)} call stacks`, () => copyPaths(), 'Ctrl+C');
      else item(m, 'Copy call stack', () => copyPaths([node]), 'Ctrl+C');
      item(m, chosen.size > 1 && chosen.has(node) ? `Copy link to these ${intFmt.format(chosen.size)}` : 'Copy link to this', () => copyLink(chosen.size > 1 && chosen.has(node) ? selection() : [node]));
    });
  }
  // A column's box (right-click or Ctrl/⌘+click its header), laid out like tarang-table's: title, Sort and Align
  // rows, the filter with (for text columns) the closest values to click, the syntax, then Clear / Done
  const FILTER_HELP = {
    num: '<span class="tarang-tree-mono">&gt;1MiB</span> · <span class="tarang-tree-mono">&lt;=500</span> · <span class="tarang-tree-mono">=0</span> · <span class="tarang-tree-mono">!=0</span>'
      + '<br><span class="tarang-tree-mono">&gt;=1MiB&lt;10MiB</span> both · <span class="tarang-tree-mono">&gt;1%</span> of the total'
      + '<br>Either: <span class="tarang-tree-mono">&lt;10 | &gt;100</span> · units B KiB MiB GiB TiB',
    text: '<span class="tarang-tree-mono">pa</span> contains · <span class="tarang-tree-mono">=main</span> exact'
      + '<br><span class="tarang-tree-mono">!Core</span> not containing · <span class="tarang-tree-mono">!=main</span> not exact'
      + '<br>Either: <span class="tarang-tree-mono">=Audio | =UI</span>',
    system: '<span class="tarang-tree-mono">=physics</span> exact · <span class="tarang-tree-mono">phy</span> contains · <span class="tarang-tree-mono">!core</span> not containing'
      + '<br>Either: <span class="tarang-tree-mono">=audio | =ui</span>',
    subsystem: '<span class="tarang-tree-mono">=simulation</span> that and all below it (simulation.world …)'
      + '<br><span class="tarang-tree-mono">world</span> contains · <span class="tarang-tree-mono">!=simulation</span> none of it'
      + '<br>Either: <span class="tarang-tree-mono">=simulation | =queries</span>',
    tag: '<span class="tarang-tree-mono">=physics</span> that system and all below it · <span class="tarang-tree-mono">=physics.simulation</span>'
      + '<br><span class="tarang-tree-mono">shad</span> contains · <span class="tarang-tree-mono">!core</span> not containing'
      + '<br>Either: <span class="tarang-tree-mono">=audio | =ui</span>',
  };
  // Nodes per distinct value of a text column, counted once per load. Tags offer their first and first two
  // levels ("rendering", "rendering.shaders"), each counting every node at or below it
  let valueCounts = null;
  function suggestValues(col, query, limit = 8) {
    if (!valueCounts || valueCounts.M !== M) valueCounts = { M };
    if (!valueCounts[col.key]) {
      let dict, counts;
      if (col.kind === 'tree') {
        dict = M.fnDict; counts = new Uint32Array(dict.length);
        for (let i = 0; i < M.fn.length; i++) counts[M.fn[i]]++;
      } else {
        // the column's strings (system, subsystem or whole tag), and for the dotted ones their first level too
        const strings = textOf(col).dict, depth = col.part === 'system' ? 1 : 2;
        const perTag = new Uint32Array(M.tagDict.length);
        for (let i = 0; i < M.tag.length; i++) perTag[M.tag[i]]++;
        const levels = new Map();
        strings.forEach((t, c) => {
          if (!t || !perTag[c]) return;
          const parts = t.split('.');
          for (let k = 1; k <= Math.min(depth, parts.length); k++) { const p = parts.slice(0, k).join('.'); levels.set(p, (levels.get(p) || 0) + perTag[c]); }
        });
        dict = [...levels.keys()]; counts = Uint32Array.from(levels.values());
      }
      valueCounts[col.key] = { dict, counts, lower: dict.map(s => s.toLowerCase()) };
    }
    const dict = valueCounts[col.key].dict;
    const { counts, lower } = valueCounts[col.key], q = query.trim().toLowerCase(), out = [];
    // nothing typed: the most common; else starting with it first, then containing it (most common first in each)
    for (let c = 0; c < dict.length; c++) {
      if (!counts[c] || !dict[c]) continue;
      const at = q ? lower[c].indexOf(q) : 0;
      if (at < 0) continue;
      out.push({ value: dict[c], count: counts[c], rank: at === 0 ? 0 : 1 });
    }
    return out.sort((a, b) => a.rank - b.rank || b.count - a.count || a.value.localeCompare(b.value)).slice(0, limit);
  }
  function openColumnBox(col, x, y) {
    const isNum = col.kind === 'num' || col.kind === 'pct', isText = !isNum;
    const html = (tag, cls, inner) => { const e = document.createElement(tag); if (cls) e.className = cls; if (inner != null) e.innerHTML = inner; return e; };
    showMenu(x, y, m => {
      m.classList.add('tarang-tree-pop');
      m.append(html('div', 'tarang-tree-pop-title', `${esc(col.label)} <span>(${isNum ? 'number' : 'text'})</span>`));
      // Sort ▲ ▼ None, and Align: buttons that stay lit for the current choice; the box stays open
      const sortRow = html('div', 'tarang-tree-pop-row', '<span class="tarang-tree-pop-label">Sort</span>'
        + '<button type="button" data-sort="1">▲ Ascending</button><button type="button" data-sort="-1">▼ Descending</button><button type="button" data-sort="0">None</button>');
      const lightSort = () => sortRow.querySelectorAll('[data-sort]').forEach(b => {
        const d = +b.dataset.sort;
        b.classList.toggle('tarang-tree-on', sortKey && sortDir ? sortKey === col.key && sortDir === d : d === 0);
      });
      sortRow.addEventListener('click', e => { const b = e.target.closest('[data-sort]'); if (b) { setSort(col.key, +b.dataset.sort); lightSort(); } });
      lightSort();
      m.appendChild(sortRow);
      if (col.kind !== 'tree') {   // the tree column stays left (its indentation)
        const alignRow = html('div', 'tarang-tree-pop-row', '<span class="tarang-tree-pop-label">Align</span>'
          + '<button type="button" data-align="left">Left</button><button type="button" data-align="center">Centre</button><button type="button" data-align="right">Right</button>');
        const lightAlign = () => alignRow.querySelectorAll('[data-align]').forEach(b => b.classList.toggle('tarang-tree-on', col.align === b.dataset.align));
        alignRow.addEventListener('click', e => { const b = e.target.closest('[data-align]'); if (b) { col.align = b.dataset.align; lightAlign(); draw(); emit('columns'); } });
        lightAlign();
        m.appendChild(alignRow);
        const colRow = html('div', 'tarang-tree-pop-row', '<span class="tarang-tree-pop-label">Column</span><button type="button" data-hide>Hide</button>');
        colRow.querySelector('[data-hide]').addEventListener('click', () => { closeMenu(); setColumnVisible(col.key, false); });
        m.appendChild(colRow);
      }
      // The filter
      const input = html('input');
      input.type = 'text'; input.autocomplete = 'off'; input.spellcheck = false;
      input.placeholder = isNum ? 'Filter, e.g. >1MiB' : col.kind === 'tag' ? (col.part === 'subsystem' ? 'Filter, e.g. =simulation' : 'Filter, e.g. =physics') : 'Filter, e.g. Render';
      input.value = (filters.get(col.key) || {}).text || '';
      const sugg = html('div', 'tarang-tree-sugg'); sugg.hidden = true;
      const err = html('div', 'tarang-tree-pop-err');
      const help = html('div', 'tarang-tree-pop-help', FILTER_HELP[isNum ? 'num' : col.kind === 'tag' ? col.part : 'text']);
      const foot = html('div', 'tarang-tree-pop-row tarang-tree-pop-foot', '<button type="button" data-clear>Clear</button><button type="button" data-done>Done</button>');
      m.append(input, sugg, err, help, foot);
      let timer = 0, list = [], index = -1, earlier = [], negate = false;
      const apply = text => { const e = setFilter(col.key, text); err.textContent = e || ''; input.classList.toggle('tarang-tree-bad', !!e); return !e; };
      // Text columns: the values closest to what's typed after the last "|", to click (or + to add another)
      function renderSugg() {
        if (!isText || !M) { sugg.hidden = true; list = []; return; }
        const terms = input.value.split('|');
        const last = /^\s*(!=|!|==|=)?(.*)$/.exec(terms.pop());
        earlier = terms.map(t => t.trim()).filter(Boolean);
        const taken = new Set(earlier.map(t => t.replace(/^(!=|!|==|=)/, '').trim().toLowerCase()));
        negate = !!last[1] && last[1].startsWith('!');
        list = suggestValues(col, last[2], 8 + taken.size).filter(s => !taken.has(s.value.toLowerCase())).slice(0, 8);
        index = Math.min(index, list.length - 1);
        sugg.hidden = !list.length;
        sugg.innerHTML = list.map((s, i) => `<div class="tarang-tree-sugg-row${i === index ? ' tarang-tree-on' : ''}">`
          + `<button type="button" data-sugg="${i}" title="${negate ? 'Exclude' : 'Show only'} “${esc(s.value)}”"><span>${negate ? '≠ ' : ''}${esc(s.value)}</span><span class="tarang-tree-n">${intFmt.format(s.count)}</span></button>`
          + `<button type="button" class="tarang-tree-add" data-sugg-add="${i}" title="Add “${esc(s.value)}” and keep choosing (either / or) · Ctrl+click">+</button></div>`).join('');
      }
      // add: false = use it as the last term, apply and close; true = add it and keep choosing
      function pick(i, add) {
        const s = list[i];
        if (!s) return;
        const text = [...earlier, (negate ? '!=' : '=') + s.value].join(' | ') + (add ? ' | ' : '');
        input.value = text;
        clearTimeout(timer);
        apply(text);
        if (add) { index = -1; renderSugg(); input.focus(); input.setSelectionRange(text.length, text.length); } else closeMenu();
      }
      sugg.addEventListener('mousedown', e => e.preventDefault());   // keep focus in the text box
      sugg.addEventListener('click', e => {
        const a = e.target.closest('[data-sugg-add]');
        if (a) { pick(+a.dataset.suggAdd, true); return; }
        const b = e.target.closest('[data-sugg]');
        if (b) pick(+b.dataset.sugg, e.ctrlKey || e.metaKey);
      });
      input.addEventListener('input', () => { index = -1; renderSugg(); clearTimeout(timer); timer = setTimeout(() => apply(input.value), 250); });
      input.addEventListener('keydown', e => {
        if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && list.length) {
          e.preventDefault();
          index = e.key === 'ArrowDown' ? Math.min(list.length - 1, index + 1) : Math.max(-1, index - 1);
          renderSugg();
          return;
        }
        if (e.key === 'Enter') {
          if (index >= 0) { pick(index, e.ctrlKey || e.metaKey); return; }   // Ctrl+Enter: add, keep choosing
          clearTimeout(timer);
          if (apply(input.value)) closeMenu();
        }
        if (e.key === 'Escape') closeMenu();
      });
      foot.querySelector('[data-clear]').addEventListener('click', () => { input.value = ''; apply(''); closeMenu(); });
      foot.querySelector('[data-done]').addEventListener('click', () => { clearTimeout(timer); if (apply(input.value)) closeMenu(); });
      renderSugg();
      setTimeout(() => { input.focus(); input.select(); });
    });
  }
  // The ☰ menu (the corner of the header, like tarang-table's): opening the tree, hot paths, sizes, filters,
  // the columns (show / hide, ↑ ↓ to move; Function stays first) and loading a capture
  function openOptionsMenu(x, y) {
    showMenu(x, y, m => {
      m.classList.add('tarang-tree-options');
      m.dataset.kind = 'options'; m.dataset.x = x; m.dataset.y = y;
      const head = text => { const h = document.createElement('div'); h.className = 'tarang-tree-menu-head'; h.textContent = text; m.appendChild(h); };
      // a row of small buttons; each runs and closes the menu
      const chips = list => {
        const row = document.createElement('div');
        row.className = 'tarang-tree-chips';
        for (const [label, fn, title] of list) {
          const b = document.createElement('button');
          b.type = 'button'; b.className = 'tarang-tree-chip'; b.textContent = label;
          if (title) b.title = title;
          b.addEventListener('click', () => { closeMenu(); fn(); scroller.focus({ preventScroll: true }); });
          row.appendChild(b);
        }
        m.appendChild(row);
      };
      head('Open the tree');
      chips([...[1, 2, 3, 4, 5, 6, 8].map(d => [String(d), () => expandToDepth(d), `Open to depth ${d}`]),
        ['All', expandAll, 'Open everything'], ['Collapse all', collapseAll, 'Close everything']]);
      head('Hot path by (from the selected row; H repeats it)');
      chips([...METRICS.map(mt => [mt.label, () => hotPath(selected, mt.field)]), ...DERIVED.map(d => [d.label.toLowerCase(), () => hotPath(selected, d.key)])]);
      head('Show');
      const human2 = document.createElement('label');
      human2.className = 'tarang-tree-menu-check';
      human2.innerHTML = `<input type="checkbox" ${human ? 'checked' : ''}> Sizes as KiB / MiB (else exact bytes)`;
      human2.querySelector('input').addEventListener('change', e => setHuman(e.target.checked));
      m.appendChild(human2);
      if (filters.size) item(m, `Clear filters (${filters.size})`, clearFilters);
      head('Columns');
      columns.forEach((c, i) => {
        const row = document.createElement('div');
        row.className = 'tarang-tree-menu-col';
        const fixed = c === columns[0];
        row.innerHTML = `<label class="tarang-tree-menu-check"><input type="checkbox" ${c.visible ? 'checked' : ''} ${fixed ? 'disabled' : ''}> ${esc(c.label)}</label>`
          + `<button type="button" class="tarang-tree-move" data-d="-1" title="Move left" ${fixed || i <= 1 ? 'disabled' : ''}>↑</button>`
          + `<button type="button" class="tarang-tree-move" data-d="1" title="Move right" ${fixed || i === columns.length - 1 ? 'disabled' : ''}>↓</button>`;
        row.querySelector('input').addEventListener('change', e => setColumnVisible(c.key, e.target.checked));
        row.querySelectorAll('.tarang-tree-move').forEach(b => b.addEventListener('click', () => moveColumnTo(c.key, columns.indexOf(c) + +b.dataset.d)));
        m.appendChild(row);
      });
      if (opts.fileLoading) {
        const s = document.createElement('div'); s.className = 'tarang-tree-menu-sep'; m.appendChild(s);
        item(m, 'Load a JSON capture…', () => q('.tarang-tree-file').click(), 'or drop one');
      }
    });
  }

  // ----- loading -----
  function busy(text) { const b = q('.tarang-tree-busy'); b.textContent = text || ''; b.hidden = !text; }
  const nextFrame = () => new Promise(r => requestAnimationFrame(() => setTimeout(r)));
  function load(data) {
    const t0 = performance.now();
    M = buildModel(data, opts.keys);
    expanded = new Uint8Array(M.n);
    sortedAt = new Uint32Array(M.n);
    rootsSortedAt = 0; sortStamp++; cmp = comparator();
    selected = -1; hoverLine = -1; anchor = -1; chosen.clear(); pins.clear();
    // start with the roots and one level open
    for (const r of M.roots) expanded[r] = 1;
    q('.tarang-tree-empty').hidden = M.n > 0;
    q('.tarang-tree-empty').textContent = 'No call stacks in this data.';
    recompileFilters();
    applyFilters();
    renderStatus();
    readUrl();   // the first time: what the address asks for (urlState)
    emit('load');
    return { nodes: M.n, ms: performance.now() - t0 };
  }
  async function loadFile(file) {
    busy(`Reading ${file.name}…`);
    await nextFrame();
    try {
      const data = JSON.parse(await file.text());
      busy('Building the tree…'); await nextFrame();
      load(data);
    } catch (err) { alert(`Could not read ${file.name}: ${err.message}`); }
    finally { busy(false); }
  }
  if (opts.fileLoading) {

    q('.tarang-tree-file').addEventListener('change', e => { if (e.target.files[0]) loadFile(e.target.files[0]); e.target.value = ''; });
    grid.addEventListener('dragover', e => { e.preventDefault(); grid.classList.add('tarang-tree-dropping'); });
    grid.addEventListener('dragleave', e => { if (!grid.contains(e.relatedTarget)) grid.classList.remove('tarang-tree-dropping'); });
    grid.addEventListener('drop', e => { e.preventDefault(); grid.classList.remove('tarang-tree-dropping'); if (e.dataTransfer.files[0]) loadFile(e.dataTransfer.files[0]); });
  }

  resize();
  if (opts.data) load(opts.data); else { q('.tarang-tree-empty').hidden = false; q('.tarang-tree-empty').textContent = 'Load or drop a JSON capture.'; }

  return {
    load, setSearch, expandAll, collapseAll, expandToDepth, expandBelow, collapseBelow, hotPath, setSort,
    setFilter, clearFilters, setPercentOf, setColumnVisible, moveColumnTo, select, pathOf,
    reveal,            // (node) open the path to it, select it, scroll to it; false if filters hide it
    pin, unpin, togglePin, setComment, setPins, openCommentBox,   // see "Pins" in the notes at the top
    get pins() { return pinList(); },
    openOptionsMenu,   // (x, y) the ☰ menu, from your own button
    setHuman,          // (bool) sizes as KiB / MiB, or exact bytes
    redraw: draw,      // repaint, e.g. after the colours colorOf returns have changed
    get selection() { return selection(); },   // every selected node, in tree order
    setSelection,                             // ([node, …]) replace the selection
    copyPaths,                                // ([node, …]?) copy call stacks (default: the selection)
    pathKey,    // (node) -> its place in the data as a path: "0.3.1" (what links use)
    findPath,   // ("0.3.1") -> { node, complete } | null
    linkFor,    // ([node, …]?) -> the page address linking to them (and the search, filters, sort)
    pathText,   // (node) -> the call stack as text, as Copy call stack / Ctrl+C copies it
    get filters() { return Object.fromEntries([...filters].map(([k, f]) => [k, f.text])); },
    setColumnOrder(list) { applyColumnOrder(list); updateSpacer(); draw(); emit('columns'); },
    get selected() { return selected; },
    get model() { return M; },
    get columns() { return columns.map(c => ({ key: c.key, label: c.label, visible: c.visible, width: c.width, align: c.align })); },
    get lineCount() { return lineCount; },
    lineNode: l => (l >= 0 && l < lineCount ? lines[l] : -1),
    onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    destroy() {
      ro.disconnect(); closeMenu();
      window.removeEventListener('mousemove', onResizeMove);
      window.removeEventListener('mouseup', onResizeEnd);
      if (frame) cancelAnimationFrame(frame);
      root.remove();
    },
  };
}

// ---------------------------------------------------------------------------
// Sample data: a made-up game capture, with the full field names
// ---------------------------------------------------------------------------
// Mulberry32: a small, fast seeded random number generator (the same seed always gives the same numbers, so
// the sample data is the same each time). Returns a function giving numbers in [0, 1). The constants and
// shifts are the algorithm's own: they scramble a 32-bit counter
function mulberry32(a) {
  return () => {
    a = (a + 0x6D2B79F5) | 0;   // | 0: keep it a 32-bit integer
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 2 ** 32;   // >>> 0: as an unsigned 32-bit number, then scaled to [0, 1)
  };
}
// short: write the short format (f, t, isb, …, c) instead of the full names
function sample({ nodes = 50000, seed = 7, short = false } = {}) {
  const K = short ? SHORT_KEYS : { function: 'function', tag: 'tag', children: 'children', inclusive_size_bytes: 'inclusive_size_bytes',
    inclusive_allocation_count: 'inclusive_allocation_count', lifetime_size_bytes: 'lifetime_size_bytes', lifetime_allocation_count: 'lifetime_allocation_count' };
  const rand = mulberry32(seed);
  // Each function's tag: its system's chain, e.g. rendering.shaders.compile (lined up with fns)
  const areas = [
    { sys: 'rendering', ns: 'Render', fns: ['DrawScene', 'CullObjects', 'BuildCommandList', 'UploadTextures', 'CompileShader', 'AllocateBuffer', 'SubmitFrame', 'UpdateLights'],
      tags: ['rendering.scene', 'rendering.scene.culling', 'rendering.commands', 'rendering.textures.upload', 'rendering.shaders.compile', 'rendering.buffers', 'rendering.commands.submit', 'rendering.scene.lighting'] },
    { sys: 'audio', ns: 'Audio', fns: ['MixVoices', 'DecodeStream', 'LoadBank', 'UpdateEmitters', 'AllocVoice', 'ResampleBlock'],
      tags: ['audio.mixer', 'audio.streaming.decode', 'audio.banks', 'audio.emitters', 'audio.mixer.voices', 'audio.mixer.resample'] },
    { sys: 'physics', ns: 'Physics', fns: ['Step', 'Broadphase', 'SolveContacts', 'BuildIslands', 'RaycastBatch', 'AllocManifold'],
      tags: ['physics.sim', 'physics.collision.broadphase', 'physics.collision.contacts', 'physics.sim.islands', 'physics.queries', 'physics.collision.manifolds'] },
    { sys: 'gameplay', ns: 'Game', fns: ['TickActors', 'SpawnActor', 'UpdateAI', 'PathFind', 'ApplyDamage', 'RunScript', 'SaveCheckpoint'],
      tags: ['gameplay.actors', 'gameplay.actors.spawn', 'gameplay.ai', 'gameplay.ai.navigation', 'gameplay.combat', 'gameplay.scripting', 'gameplay.saves'] },
    { sys: 'ui', ns: 'UI', fns: ['Layout', 'DrawWidgets', 'ShapeText', 'LoadFont', 'BuildAtlas'],
      tags: ['ui.layout', 'ui.widgets', 'ui.text.shaping', 'ui.text.fonts', 'ui.text.atlas'] },
    { sys: 'online', ns: 'Net', fns: ['PollSockets', 'Serialize', 'Deserialize', 'ReplicateState', 'Compress'],
      tags: ['online.sockets', 'online.replication.serialize', 'online.replication.deserialize', 'online.replication', 'online.compression'] },
    { sys: 'core', ns: 'Core', fns: ['Malloc', 'Realloc', 'StringBuilder::Append', 'Array::Grow', 'HashMap::Rehash', 'Pool::Alloc'],
      tags: ['core.allocation', 'core.allocation.realloc', 'core.strings', 'core.containers', 'core.containers.hash', 'core.allocation.pools'] },
  ];
  const pick = a => a[Math.floor(rand() * a.length)];
  // About 2% of the frames from depth 3 down are tag frames, TAG:SYSTEM:name (a file being read, an asset
  // being built…), some inside others. They have their own random numbers, so the capture's shape and sizes
  // are the same as without them
  const tagRand = mulberry32(seed ^ 0x7a6),
    TAGS = [['FILEIO', ['ReadMe.txt', 'config.ini', 'levels/forest.map', 'saves/slot1.sav', 'shaders.pak']],
      ['ASSET', ['textures/rock.dds', 'meshes/tree.fbx', 'audio/ambience.bnk', 'fonts/ui.ttf']],
      ['SCRIPT', ['quests/intro.lua', 'ai/patrol.lua', 'ui/menu.lua']]];
  const tagName = () => { const [sys, names] = TAGS[Math.floor(tagRand() * TAGS.length)]; return `TAG:${sys}:${names[Math.floor(tagRand() * names.length)]}`; };
  const upTo = n => Math.floor(rand() * n);   // a whole number from 0 to n − 1
  // Builds a node with `share` descendants: its children split the share between them, unevenly (so some
  // branches are big and deep, most are small), and inclusive values are summed up from them
  function make(name, tag, depth, share) {
    const node = { [K.function]: name, [K.tag]: tag };
    const kids = [];
    if (share > 0 && depth < 60) {
      // children: 7 under the root (one per system), 3–7 near the top, 1–4 further down
      const want = Math.min(share, depth === 0 ? 7 : depth < 3 ? 3 + upTo(5) : 1 + upTo(4));
      // rand() ** 2.5 makes most weights small and a few large: a few big branches, many small ones
      const weights = Array.from({ length: want }, () => rand() ** 2.5 + 0.01);
      const sum = weights.reduce((a, b) => a + b, 0);
      let left = share - want;   // each child is one; the rest is shared out
      for (let c = 0; c < want; c++) {
        const mine = c === want - 1 ? left : Math.min(left, Math.round(((share - want) * weights[c]) / sum));
        left -= mine;
        // mostly the same system as the caller
        const area = depth === 0 ? areas[c % areas.length] : rand() < 0.85 ? areas.find(a => tag.startsWith(a.sys)) || pick(areas) : pick(areas);
        const f = upTo(area.fns.length);
        // about a third of the frames are templates: Render::DrawScene<Mesh>
        const fnName = `${area.ns}::${area.fns[f]}${rand() < 0.3 ? '<' + pick(['Mesh', 'Texture', 'Voice', 'Actor', 'Packet', 'Glyph']) + '>' : ''}`;
        kids.push(make(depth >= 2 && tagRand() < 0.02 ? tagName() : fnName, area.tags[f], depth + 1, mine));
      }
    }
    // own allocations: 85% of leaves and 30% of inner frames allocate. The powers skew the sizes like a real
    // capture: most frames make a few small allocations, a few make many or large ones
    const own = kids.length === 0 ? rand() < 0.85 : rand() < 0.3;
    let count = own ? 1 + Math.floor(rand() ** 3 * 400) : 0;                // 1–400 still live, mostly few
    let bytes = own ? Math.round(count * (16 + rand() ** 4 * 65536)) : 0;   // 16 B – 64 KiB each, mostly small
    const freed = own ? Math.round(count * rand() * 6) : 0;                  // up to 6 freed for each still live
    let lifeCount = count + freed, lifeBytes = bytes + Math.round(freed * (16 + rand() * 4096));   // freed ones: 16 B – 4 KiB
    for (const k of kids) {
      bytes += k[K.inclusive_size_bytes] || 0; count += k[K.inclusive_allocation_count] || 0;
      lifeBytes += k[K.lifetime_size_bytes] || 0; lifeCount += k[K.lifetime_allocation_count] || 0;
    }
    if (kids.length) node[K.children] = kids;
    // nothing allocated here or below: like a real capture, no numbers and no tag
    if (!count && !lifeCount) { delete node[K.tag]; return node; }
    node[K.inclusive_size_bytes] = bytes;
    node[K.inclusive_allocation_count] = count;
    node[K.lifetime_size_bytes] = lifeBytes;
    node[K.lifetime_allocation_count] = lifeCount;
    return node;
  }
  return make('main', 'core', 0, Math.max(0, nodes - 1));
}

window.TarangTree = { create, buildModel, sample, FIELDS, METRICS, SHORT_KEYS };
})();
