// SPDX-License-Identifier: MIT
/* tarang-chart.js: charts drawn from a TarangTable's data, kept in step with it. Needs tarang-table.js (and
 * tarang-table.css) loaded first. No other dependencies; charts are SVG.
 *
 *   const chart = TarangChart.chart(containerElement, table, {   // (TarangChart.pie is the same function)
 *     column: 'status',        // the categories: a column key (or label); text, or numbers used as categories
 *                              //   (lines: optional, one line per category; without it, one line)
 *     value: 'revenue',        // optional: sum this number column per category (default: count the rows; lines
 *                              //   also count negative values)
 *     filtered: true,          // follow the table's filters (and its hidden rows); false: every row
 *     clickToFilter: true,     // clicking a slice (or its legend row) filters the table to it; click again to clear.
 *                              //   Lines / columns: clicking a point or column filters the x column to that period
 *                              //   (Ctrl/⌘+click adds or removes periods); the legend filters by category
 *     type: 'pie',             // 'pie', 'bar' (horizontal bars, biggest first, in the same colours as the pie),
 *                              //   'line' (values along the x column, one line per category of `column`), or
 *                              //   'column' (the same as vertical columns, the categories stacked or side by side),
 *                              //   'sankey' (rows flowing through `stages`; see below), or 'treemap' (rectangles
 *                              //   sized by the value, drilling down through `stages`: click one to go into it,
 *                              //   the breadcrumb or a right-click climbs back. With clickToFilter the drill
 *                              //   path is the table's filters (=North on region …), so the other charts follow
 *                              //   it; at the last stage a click filters to that category, like a pie slice)
 *     stages: ['region', 'product', 'status'],   // sankey: the columns rows flow through, in order (2–6);
 *                              //   treemap: the columns to drill down through, in order (1 or more)
 *     colorBy: 'region',       // sankey: the stage whose categories colour the flows (default: the first)
 *     routes: false,           // sankey: true draws each route (one value per stage) as its own strand, kept in
 *                              //   the same place on both sides of every node, so a selection lights whole routes
 *                              //   without anything moving; clicking a strand picks its whole route
 *     x: 'date',               // lines / columns: the column they run along: dates (text like 2026-01-31),
 *                              //   numbers (binned when there are many), or text (its values in order)
 *     bucket: 'auto',          // ... along dates: 'day' | 'week' | 'month' | 'year' | 'auto' (about 120 points)
 *     stack: 'stack',          // columns split by `column`: 'stack' (one column, in parts), 'group' (side by
 *                              //   side) or 'percent' (stacked, every column full height: each part's share)
 *     lines: 'overlap',        // lines split by `column`: 'overlap' (each from 0), 'stack' (filled areas, each
 *                              //   on top of the ones below, the top edge the total) or 'percent' (stacked
 *                              //   to 100%: each category's share of every point)
 *     linkColors: false,       // true: take category colours from the table (table.colorOf: the values with the
 *                              //   most rows get the colours, so every linked chart agrees, whatever it sums),
 *                              //   and mark the coloured column's cells in the table with a strip of each colour
 *     slices: 6,               // at most this many slices (2–9; bars 2–20): the rest are folded into "Other"
 *     donut: false,            // pie only: true for a ring, with the total in the middle
 *     title: 'Orders by status',   // default: the column's label
 *     pickers: true,           // a ☰ menu in the chart's header with every setting above: "Chart ▸" (pie / ring /
 *                              //   bars), "Slices by ▸" / "Sized by ▸" (searchable lists of the table's columns;
 *                              //   the title then follows the column), "Most slices ▸", and Follow the table's
 *                              //   filters / Click to filter switches. With pickers, column can be left out: the
 *                              //   first text column is used
 *   });
 *   chart.update()             redraw now (it redraws by itself when the table's data, filters or size change)
 *   chart.setOptions({ … })    change any of the options above (title: null to have it follow the column)
 *   chart.options              the current options, including what the pickers chose
 *   chart.slices               [{ name, value, share, color, other }] as drawn
 *   chart.destroy()
 *
 * Colours follow the category, not its size: the biggest categories over all the rows get the colours, in
 * order, when the data loads, and keep them while filters change the sizes (so a category never changes
 * colour under you). Categories outside those are "Other", in grey.
 * With clickToFilter, the chart ignores the table's filter on its own column, so all slices stay visible and
 * the ones that filter leaves out are dimmed: the pie works as a filter control.
 */
(function () {
'use strict';
// Missing numbers are NaN, as in tarang-table: `v === v` reads "v has a value" and `v !== v` "v is missing"
// (NaN is the only value not equal to itself)

// Categorical palette (dark-surface steps), in its validated order; "Other" is a recessive grey
const SLOTS = ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#008300', '#9085e9', '#e66767'];
const OTHER = '#4b4f59';
// Bars can show more categories than there are colours: past the 8th, named bars share this neutral slate
// (repeating a palette colour would make two categories look like one)
const EXTRA = '#5b6578';
const MAX_BARS = 20;
const NEUTRAL = '#6b7486';   // flow nodes outside the colour stage
const MAX_STAGES = 6;
const SURFACE = '#171b23';   // the gap between slices is drawn in the chart's background
const SVGNS = 'http://www.w3.org/2000/svg';
const LABEL_MIN_SHARE = 0.07;   // slices this big get their percentage written on them

const svgEl = (name, attrs = {}) => {
  const n = document.createElementNS(SVGNS, name);
  for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
  return n;
};
const htmlEl = (name, cls, text) => {
  const n = document.createElement(name);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;   // names come from the data: always text, never HTML
  return n;
};
// A share as a percentage that never reads 0% or 100% unless it is
const pct = s => (s === 0 || s === 1 ? `${s * 100}%` : s < 0.01 ? '<1%' : s > 0.99 ? '>99%' : `${Math.round(s * 100)}%`);

// ---------------------------------------------------------------------------
// Lines: dates, buckets and axis ticks
// ---------------------------------------------------------------------------
const UNITS = ['day', 'week', 'month', 'year'];
const DAY = 86_400_000;
const MAX_POINTS = 5000;   // a finer date unit than this many points is coarsened

// A date written as 2026-01-31 (optionally with a time) or 31/01/2026, as UTC milliseconds; NaN otherwise
function parseDate(s) {
  let m = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T ](\d{1,2}):(\d{2})(?::(\d{2}))?)?/.exec(s);
  if (m) return Date.UTC(+m[1], m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
  m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s);
  return m ? Date.UTC(+m[3], m[2] - 1, +m[1]) : NaN;
}
// The start of the day / week (Monday) / month / year holding t, and the next one after a start
function unitStart(t, unit) {
  const d = new Date(t);
  if (unit === 'day') return Math.floor(t / DAY) * DAY;
  if (unit === 'week') { const day = Math.floor(t / DAY); return (day - ((day + 3) % 7)) * DAY; }   // 1970-01-01 was a Thursday
  if (unit === 'month') return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1);
  return Date.UTC(d.getUTCFullYear(), 0, 1);
}
function unitNext(t, unit) {
  const d = new Date(t);
  if (unit === 'day') return t + DAY;
  if (unit === 'week') return t + 7 * DAY;
  if (unit === 'month') return Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1);
  return Date.UTC(d.getUTCFullYear() + 1, 0, 1);
}
// The finest unit that keeps the line to about 120 points
function autoUnit(span) {
  if (span <= 120 * DAY) return 'day';
  if (span <= 120 * 7 * DAY) return 'week';
  if (span <= 120 * 31 * DAY) return 'month';
  return 'year';
}
function dateLabel(t, unit, multiYear) {
  const o = { timeZone: 'UTC' };
  if (unit === 'year') o.year = 'numeric';
  else if (unit === 'month') Object.assign(o, { month: 'short', year: 'numeric' });
  else Object.assign(o, { day: 'numeric', month: 'short' }, multiYear ? { year: '2-digit' } : {});
  return new Date(t).toLocaleDateString(undefined, o);
}
// About `count` round tick values covering lo..hi
function niceTicks(lo, hi, count = 5) {
  if (!(hi > lo)) { hi = lo + 1; }
  const raw = (hi - lo) / count, mag = 10 ** Math.floor(Math.log10(raw)), f = raw / mag;
  const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * mag;
  const ticks = [];
  for (let v = Math.floor(lo / step) * step; v <= hi + step * 1e-9; v += step) ticks.push(+v.toFixed(12));
  if (ticks[ticks.length - 1] < hi) ticks.push(ticks[ticks.length - 1] + step);
  return ticks;
}
const compact = new Intl.NumberFormat(undefined, { notation: 'compact', maximumFractionDigits: 1 });
const COLLATOR = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });

// A column part from (x, y), w wide and h high; round: 'top' | 'bottom' rounds that end (4px), else square
// Squarified treemap layout (Bruls, Huizing & van Wijk): lays items (biggest first, `v` > 0) out in rows along the
// shorter side of what's left, keeping each rectangle close to square; sets item.rect = { x, y, w, h }
function squarify(items, x, y, w, h) {
  const total = items.reduce((s, it) => s + it.v, 0);
  if (!items.length || !(total > 0) || w <= 0 || h <= 0) { for (const it of items) it.rect = { x, y, w: 0, h: 0 }; return; }
  const scale = (w * h) / total;
  const area = items.map(it => it.v * scale);
  // the worst aspect ratio in a row of areas summing to s (min r, max R) laid along a side of length side
  const worst = (s, r, R, side) => Math.max((side * side * R) / (s * s), (s * s) / (side * side * r));
  let i = 0;
  while (i < items.length) {
    const side = Math.min(w, h);
    let j = i, s = 0, r = Infinity, R = 0, best = Infinity;
    while (j < items.length) {
      const a = area[j], s2 = s + a, r2 = Math.min(r, a), R2 = Math.max(R, a), wr = worst(s2, r2, R2, side);
      if (j > i && wr > best) break;
      s = s2; r = r2; R = R2; best = wr; j++;
    }
    if (w >= h) {   // a column at the left, as tall as what's left
      const cw = s / h;
      let cy = y;
      for (let k = i; k < j; k++) { const hh = area[k] / cw; items[k].rect = { x, y: cy, w: cw, h: hh }; cy += hh; }
      x += cw; w -= cw;
    } else {        // a row at the top, as wide as what's left
      const rh = s / w;
      let cx = x;
      for (let k = i; k < j; k++) { const ww = area[k] / rh; items[k].rect = { x: cx, y, w: ww, h: rh }; cx += ww; }
      y += rh; h -= rh;
    }
    i = j;
  }
}

function barPath(x, y, w, h, round) {
  const r = round ? Math.min(4, w / 2, h) : 0;
  const f = n => n.toFixed(1);
  if (!r) return `M${f(x)} ${f(y)}h${f(w)}v${f(h)}h${f(-w)}Z`;
  if (round === 'top') {
    return `M${f(x)} ${f(y + h)}V${f(y + r)}Q${f(x)} ${f(y)} ${f(x + r)} ${f(y)}H${f(x + w - r)}Q${f(x + w)} ${f(y)} ${f(x + w)} ${f(y + r)}V${f(y + h)}Z`;
  }
  return `M${f(x)} ${f(y)}H${f(x + w)}V${f(y + h - r)}Q${f(x + w)} ${f(y + h)} ${f(x + w - r)} ${f(y + h)}H${f(x + r)}Q${f(x)} ${f(y + h)} ${f(x)} ${f(y + h - r)}Z`;
}

function pie(container, table, options = {}) {
  let opts = { filtered: true, clickToFilter: true, slices: 6, donut: false, ...options };
  const root = htmlEl('div', 'tarang-chart');
  const head = htmlEl('div', 'tarang-chart-head');
  const titleEl = htmlEl('div', 'tarang-chart-title'), subEl = htmlEl('div', 'tarang-chart-sub');
  const headText = htmlEl('div', 'tarang-chart-head-text');
  headText.append(titleEl, subEl);
  head.appendChild(headText);
  const pickers = opts.pickers ? makeMenu() : null;
  if (pickers) head.appendChild(pickers.el);
  const body = htmlEl('div', 'tarang-chart-body');
  const tip = htmlEl('div', 'tarang-chart-tip');
  tip.hidden = true;
  root.append(head, body, tip);
  container.appendChild(root);

  const isBar = () => opts.type === 'bar';
  const isLine = () => opts.type === 'line';
  const isColumn = () => opts.type === 'column';
  const isSeries = () => isLine() || isColumn();   // drawn along an x column
  const isSankey = () => opts.type === 'sankey';
  const isTreemap = () => opts.type === 'treemap';
  const usesStages = () => isSankey() || isTreemap();   // drawn from a list of columns (opts.stages)
  const maxSlices = () => (isBar() ? MAX_BARS : SLOTS.length + 1);   // bars can show more than a pie can
  const sliceCount = () => Math.max(2, Math.min(maxSlices(), opts.slices | 0 || 6));
  let identity = null;   // { col, valCol, colorOf: Map(category -> slot), order: [category] } from all rows
  let drawn = [];        // the slices as last drawn
  let hot = -1;          // index of the hovered slice
  let coloured = [];     // the column(s) whose categories the last drawing coloured
  const linkToken = {};  // this chart, to the table's linkColors

  const columnOf = key => {
    if (key == null || !table.model) return null;
    const all = table.model.allColumns;
    return all.find(c => c.key === key) || all.find(c => c.label === key) || null;
  };

  // Each row's category as a small integer: text columns use their dictionary codes, number columns an index
  // per distinct value. names[c] is how category c reads; filterText[c] the table filter that selects it.
  function categories(col) {
    const n = table.model.numRows;
    if (col.type === 'text') {
      const dict = col.data.dict, codes = col.data.codes;
      return {
        count: dict.length, of: i => codes[i],
        name: c => (dict[c] === '' ? '(blank)' : col.formatValue ? col.formatValue(dict[c]) : dict[c]),
        filterText: c => (dict[c].includes('|') ? null : `=${dict[c]}`),   // "|" would split the filter
        raw: c => dict[c],
      };
    }
    const vals = col.data.values, ids = new Map(), back = [];
    const idx = new Int32Array(n);
    for (let i = 0; i < n; i++) {
      const v = vals[i], key = v === v ? v : 'blank';
      let c = ids.get(key);
      if (c === undefined) { c = back.length; ids.set(key, c); back.push(key); }
      idx[i] = c;
    }
    return {
      count: back.length, of: i => idx[i],
      name: c => (back[c] === 'blank' ? '(blank)' : col.formatValue ? col.formatValue(back[c]) : String(back[c])),
      filterText: c => (back[c] === 'blank' ? null : `=${back[c]}`),
      raw: c => back[c],
    };
  }

  // Sum the measure per category over the rows that pass `tests` (and aren't hidden)
  function tally(cats, valCol, tests, hidden) {
    const n = table.model.numRows, sums = new Float64Array(cats.count), rep = new Int32Array(cats.count).fill(-1);
    const vals = valCol ? valCol.data.values : null;
    let rows = 0, negatives = 0;
    rows: for (let i = 0; i < n; i++) {
      if (hidden && hidden[i]) continue;
      for (const t of tests) if (!t(i)) continue rows;
      const c = cats.of(i);
      if (rep[c] < 0) rep[c] = i;
      rows++;
      if (vals) {
        const v = vals[i];
        if (v > 0) sums[c] += v; else if (v < 0) negatives++;
      } else sums[c]++;
    }
    return { sums, rep, rows, negatives };
  }

  // Which categories get colours: the biggest over all rows, fixed until the data or options change
  function buildIdentity(col, valCol) {
    const cats = categories(col);
    const all = tally(cats, valCol, [], null);
    const max = sliceCount();
    const ranked = [];
    for (let c = 0; c < cats.count; c++) if (all.sums[c] > 0) ranked.push(c);
    ranked.sort((a, b) => all.sums[b] - all.sums[a] || String(cats.raw(a)).localeCompare(String(cats.raw(b))));
    const named = ranked.length <= max ? ranked : ranked.slice(0, max - 1);   // leave a slot for "Other"
    const colorOf = new Map(named.map((c, k) => [c, k]));
    // A category's colour: the table's (linkColors, text columns), else the chart's own by rank; read when drawn,
    // so switching linkColors or the table's fixed colours needs no rebuild
    const colorFor = c => {
      if (opts.linkColors && table.colorOf && col.type === 'text') return table.colorOf(col, cats.raw(c)) || EXTRA;
      const k = colorOf.get(c);
      return k == null ? EXTRA : SLOTS[k] || EXTRA;
    };
    return { col, valCol, cats, colorOf, colorFor, order: named };
  }

  // Columns worth slicing by: any with values (not an empty, render-only column)
  const sliceable = c => !(c.type === 'text' && c.data.dict.length <= 1);

  // The ☰ menu: every setting of the chart.
  //   Chart ▸                    pie, ring, bars, lines or columns
  //   Along ▸ / Dates by ▸       lines and columns: the x column, and how dates are grouped
  //   Slices by ▸ / Sized by ▸   searchable lists of the table's columns (the title follows the column)
  //   Columns ▸ / Lines ▸        split columns: stacked, side by side or 100%; split lines: overlapping,
  //                              stacked areas or 100%
  //   Most slices ▸              2–9 (bars 2–20), the rest folded into "Other"
  //   ✓ Follow the table's filters / ✓ Click a slice to filter the table   switch on / off in place
  // Keyboard: ↑ ↓ move, → or Enter opens a list, Enter picks, ← / Esc go back.
  function makeMenu() {
    const btn = htmlEl('button', 'tarang-chart-menu-btn', '☰');
    btn.type = 'button';
    btn.title = 'Chart settings';
    btn.setAttribute('aria-haspopup', 'menu');
    let main = null, sub = null, current = { column: '', value: '', x: '' };
    const columnItems = () => table.model.allColumns.filter(sliceable).map(c => ({ key: c.key, label: c.label, meta: c.type === 'number' ? 'numbers' : '' }));
    // `show`: whether the row applies to the current kind of chart
    const LISTS = {
      chart: { label: 'Chart', search: null,
        items: () => [{ key: 'pie', label: 'Pie', meta: '' }, { key: 'ring', label: 'Ring', meta: 'total in the middle' },
          { key: 'bar', label: 'Bars', meta: `up to ${MAX_BARS}` }, { key: 'line', label: 'Lines', meta: 'along a column' },
          { key: 'column', label: 'Columns', meta: 'along a column' }, { key: 'sankey', label: 'Flow', meta: 'between columns' },
          { key: 'treemap', label: 'Treemap', meta: 'drill down columns' }] },
      colorBy: { label: 'Colour by', search: null, show: () => isSankey(),
        items: () => (opts.stages || []).map(k => columnOf(k)).filter(Boolean).map(c => ({ key: c.key, label: c.label, meta: '' })) },
      x: { label: 'Along', search: 'Search columns…', show: () => isSeries(),
        items: () => table.model.allColumns.filter(sliceable).map(c => ({ key: c.key, label: c.label, meta: c.type === 'number' ? 'numbers' : axisKind(c) === 'date' ? 'dates' : '' })) },
      bucket: { label: 'Dates by', search: null, show: () => isSeries() && lineAxisKind() === 'date',
        items: () => [{ key: 'auto', label: 'automatic', meta: lastUnit ? lastUnit : '' }, ...UNITS.map(u => ({ key: u, label: u, meta: '' }))] },
      column: { label: () => (isLine() ? 'Lines by' : isColumn() ? 'Split by' : isBar() ? 'Bars by' : 'Slices by'), search: 'Search columns…', show: () => !usesStages(),
        items: () => (isSeries() ? [{ key: '', label: isLine() ? '(one line)' : '(no split)', meta: '' }, ...columnItems()] : columnItems()) },
      stack: { label: 'Columns', search: null, show: () => isColumn() && !!current.column,
        items: () => [{ key: 'stack', label: 'stacked', meta: '' }, { key: 'group', label: 'side by side', meta: '' },
          { key: 'percent', label: 'stacked 100%', meta: 'shares' }] },
      lines: { label: 'Lines', search: null, show: () => isLine() && !!current.column,
        items: () => [{ key: 'overlap', label: 'overlapping', meta: '' }, { key: 'stack', label: 'stacked areas', meta: 'total on top' },
          { key: 'percent', label: 'stacked 100%', meta: 'shares' }] },
      value: { label: () => (isSeries() ? 'Values' : 'Sized by'), search: 'Search number columns…',
        items: () => [{ key: '', label: 'count of rows', meta: '' },
          ...table.model.allColumns.filter(c => c.type === 'number').map(c => ({ key: c.key, label: `sum of ${c.label}`, meta: '' }))] },
      slices: { label: () => (isSankey() ? 'Most per stage' : isTreemap() ? 'Colours per level' : isLine() ? 'Most lines' : isColumn() ? 'Most splits' : isBar() ? 'Most bars' : 'Most slices'), search: null,   // short: no search box
        show: () => !isSeries() || !!current.column,
        items: () => Array.from({ length: maxSlices() - 1 }, (_, k) => ({ key: String(k + 2), label: String(k + 2), meta: `${k + 1} + Other` })) },
    };
    const TOGGLES = [
      ['filtered', 'Follow the table\'s filters'],
      ['clickToFilter', () => (isTreemap() ? 'Drill in by filtering the table' : isSankey() ? 'Click a node or flow to filter the table' : isSeries() ? (isColumn() ? 'Click a column or name to filter the table' : 'Click a point or name to filter the table') : isBar() ? 'Click a bar to filter the table' : 'Click a slice to filter the table')],
      ['routes', 'Keep routes together', () => isSankey()],
      ['linkColors', 'Colours shared with the table', () => !!table.colorOf],
    ];
    const chosen = which => (which === 'slices' ? String(sliceCount())
      : which === 'colorBy' ? sankeyColorKey()
      : which.startsWith('stage:') ? (which === 'stage:add' ? '' : (opts.stages || [])[+which.slice(6)] || '')
      : which === 'chart' ? (isTreemap() ? 'treemap' : isSankey() ? 'sankey' : isColumn() ? 'column' : isLine() ? 'line' : isBar() ? 'bar' : opts.donut ? 'ring' : 'pie')
      : which === 'stack' ? (opts.stack === 'group' || opts.stack === 'percent' ? opts.stack : 'stack')
      : which === 'lines' ? (opts.lines === 'stack' || opts.lines === 'percent' ? opts.lines : 'overlap')
      : which === 'bucket' ? (UNITS.includes(opts.bucket) ? opts.bucket : 'auto') : current[which]);
    const text = l => (typeof l === 'function' ? l() : l);
    // Flow stages: a row per stage (pick another column, or remove it), then "Add a stage"
    const REMOVE = '\u0000remove';
    // "(remove this stage)" while there are more than the fewest it needs: flows 2 stages, treemaps 1
    const stageList = i => ({
      label: i < 0 ? 'Add a stage' : `Stage ${i + 1}`, search: 'Search columns…',
      items: () => [...(i >= 0 && (opts.stages || []).length > (isTreemap() ? 1 : 2) ? [{ key: REMOVE, label: '(remove this stage)', meta: '' }] : []), ...columnItems()],
    });
    const listOf = which => LISTS[which] || stageList(which === 'stage:add' ? -1 : +which.slice(6));
    function entries() {   // the main menu's rows, in order
      const out = [];
      for (const [which, list] of Object.entries(LISTS)) {
        if (list.show && !list.show()) continue;
        out.push([which, list]);
        if (which === 'chart' && usesStages()) {
          (opts.stages || []).forEach((_, i) => out.push([`stage:${i}`, stageList(i)]));
          if ((opts.stages || []).length < MAX_STAGES) out.push(['stage:add', stageList(-1)]);
        }
      }
      return out;
    }

    function close() {
      if (sub) sub.remove();
      if (main) main.remove();
      sub = main = null;
      btn.classList.remove('tarang-on');
      document.removeEventListener('pointerdown', outside, true);
      window.removeEventListener('resize', close);
      window.removeEventListener('scroll', onScroll, true);
    }
    const outside = e => { if (![main, sub, btn].some(n => n && n.contains(e.target))) close(); };
    // Close when the chart moves on screen (the page, or a box around it, scrolled); other scrolling is fine
    const onScroll = e => { const t = e.target; if (t === document || (t.contains && t.contains(btn))) close(); };
    // Fixed position (the chart's card may clip), kept inside the window
    function place(pop, x, y) {
      pop.style.left = `${Math.max(8, Math.min(x, innerWidth - pop.offsetWidth - 8))}px`;
      pop.style.top = `${Math.max(8, Math.min(y, innerHeight - pop.offsetHeight - 8))}px`;
    }

    function open() {
      close();
      main = htmlEl('div', 'tarang-chart-menu');
      main.setAttribute('role', 'menu');
      const rows = entries().map(([which, list]) => {
        const row = htmlEl('button', 'tarang-chart-menu-row');
        row.type = 'button';
        row.setAttribute('role', 'menuitem');
        row.setAttribute('aria-haspopup', 'menu');
        const now = list.items().find(it => it.key === chosen(which));
        row.append(htmlEl('span', 'tarang-chart-menu-label', text(list.label)), htmlEl('span', 'tarang-chart-menu-value', now ? now.label : which === 'stage:add' ? '' : '—'),
          htmlEl('span', 'tarang-chart-menu-arrow', '▸'));
        row.dataset.which = which;
        row.addEventListener('click', () => openSub(which, row, true));
        row.addEventListener('pointerenter', () => { if (!sub || sub.dataset.which !== which) openSub(which, row, false); });
        main.appendChild(row);
        return row;
      });
      main.appendChild(htmlEl('div', 'tarang-chart-menu-sep'));
      for (const [key, label, when] of TOGGLES) {
        if (when && !when()) continue;
        const row = htmlEl('button', 'tarang-chart-menu-row tarang-chart-menu-toggle');
        row.type = 'button';
        row.setAttribute('role', 'menuitemcheckbox');
        const check = htmlEl('span', 'tarang-chart-check');
        const show = () => { check.textContent = opts[key] ? '✓' : ''; row.setAttribute('aria-checked', !!opts[key]); };
        show();
        row.append(check, htmlEl('span', 'tarang-chart-menu-name', text(label)));
        row.addEventListener('click', () => {   // the menu stays open, so the change can be seen
          opts = { ...opts, [key]: !opts[key] };
          show();
          render();
        });
        row.addEventListener('pointerenter', closeSub);
        main.appendChild(row);
        rows.push(row);
      }
      main.addEventListener('keydown', e => {
        const k = rows.indexOf(document.activeElement);
        if (e.key === 'Escape') { e.preventDefault(); close(); btn.focus(); }
        else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); rows[(k + (e.key === 'ArrowDown' ? 1 : rows.length - 1)) % rows.length].focus(); }
        else if (e.key === 'ArrowRight' && k >= 0 && rows[k].dataset.which) { e.preventDefault(); openSub(rows[k].dataset.which, rows[k], true); }
      });
      document.body.appendChild(main);
      const r = btn.getBoundingClientRect();
      place(main, r.right - main.offsetWidth, r.bottom + 4);
      btn.classList.add('tarang-on');
      rows[0].focus();
      document.addEventListener('pointerdown', outside, true);
      window.addEventListener('resize', close);
      window.addEventListener('scroll', onScroll, true);
    }

    function openSub(which, row, focus) {
      if (sub) sub.remove();
      main.querySelectorAll('.tarang-chart-menu-row').forEach(r => r.classList.toggle('tarang-on', r === row));
      sub = htmlEl('div', 'tarang-chart-menu tarang-chart-menu-sub');
      sub.dataset.which = which;
      sub.setAttribute('role', 'menu');
      const list = htmlEl('div', 'tarang-chart-menu-list');
      let search = null;
      const list0 = listOf(which);
      if (list0.search) {
        search = document.createElement('input');
        search.type = 'text';
        search.className = 'tarang-chart-search';
        search.placeholder = list0.search;
        search.setAttribute('aria-label', list0.search);
        sub.appendChild(search);
      }
      sub.appendChild(list);
      list.tabIndex = -1;   // takes the keys when there is no search box
      const keys = search || list;
      const all = list0.items(), now = chosen(which);
      let shown = [], hi = 0;

      function setHi(k) {
        hi = k;
        [...list.children].forEach((b, j) => b.classList.toggle('tarang-hot', j === k));
        if (list.children[k]) list.children[k].scrollIntoView({ block: 'nearest' });
      }
      function fill() {
        const q = search ? search.value.trim().toLowerCase() : '';
        // Matches only, those starting with the text first
        shown = !q ? all : all.filter(it => it.label.toLowerCase().includes(q))
          .sort((a, b) => a.label.toLowerCase().startsWith(q) === b.label.toLowerCase().startsWith(q) ? 0 : a.label.toLowerCase().startsWith(q) ? -1 : 1);
        list.replaceChildren(...shown.map((it, k) => {
          const b = htmlEl('button', 'tarang-chart-menu-item');
          b.type = 'button';
          b.tabIndex = -1;
          b.setAttribute('role', 'menuitemradio');
          b.setAttribute('aria-checked', it.key === now);
          b.append(htmlEl('span', 'tarang-chart-check', it.key === now ? '✓' : ''), htmlEl('span', 'tarang-chart-menu-name', it.label),
            htmlEl('span', 'tarang-chart-menu-meta', it.meta));
          b.addEventListener('click', () => pick(which, it.key));
          b.addEventListener('pointermove', () => { if (hi !== k) setHi(k); });
          return b;
        }));
        if (!shown.length) list.appendChild(htmlEl('div', 'tarang-chart-menu-none', 'Nothing matches'));
        setHi(q ? 0 : Math.max(0, shown.findIndex(it => it.key === now)));
      }
      if (search) search.addEventListener('input', fill);
      keys.addEventListener('keydown', e => {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (shown.length) setHi((hi + (e.key === 'ArrowDown' ? 1 : shown.length - 1)) % shown.length); }
        else if (e.key === 'Enter') { e.preventDefault(); if (shown[hi]) pick(which, shown[hi].key); }
        else if (e.key === 'Escape' || (e.key === 'ArrowLeft' && !(search && search.value))) {
          e.preventDefault(); e.stopPropagation();
          closeSub();
          row.focus();
        }
      });
      document.body.appendChild(sub);
      fill();
      const r = row.getBoundingClientRect(), m = main.getBoundingClientRect();
      const x = m.right + 4 + sub.offsetWidth <= innerWidth - 8 ? m.right + 4 : m.left - sub.offsetWidth - 4;   // right, or else left
      place(sub, x, r.top - 7);
      if (focus) keys.focus();
    }
    function closeSub() {
      if (!sub) return;
      sub.remove();
      sub = null;
      if (main) main.querySelectorAll('.tarang-chart-menu-row').forEach(r => r.classList.remove('tarang-on'));
    }

    function pick(which, key) {
      close();
      if (which === 'slices') opts = { ...opts, slices: +key };
      else if (which === 'bucket') opts = { ...opts, bucket: key };
      else if (which === 'stack') opts = { ...opts, stack: key };
      else if (which === 'lines') opts = { ...opts, lines: key };
      else if (which === 'colorBy') opts = { ...opts, colorBy: key };
      else if (which.startsWith('stage:')) {
        const stages = [...(opts.stages || [])];
        if (which === 'stage:add') stages.push(key);
        else if (key === REMOVE) stages.splice(+which.slice(6), 1);
        else stages[+which.slice(6)] = key;
        opts = { ...opts, stages, title: null };
      } else if (which === 'chart') opts = { ...opts, type: ['bar', 'line', 'column', 'sankey', 'treemap'].includes(key) ? key : 'pie', donut: key === 'ring', title: null };
      else opts = { ...opts, [which]: key || null, title: null };   // a new column: the title follows it
      identity = null;
      render();
      btn.focus();
    }

    btn.addEventListener('click', () => (main ? close() : open()));
    return {
      el: btn,
      sync(col, valCol, xcol) { current = { column: col ? col.key : '', value: valCol ? valCol.key : '', x: xcol ? xcol.key : '' }; },
      close,
    };
  }

  function message(text) {
    body.replaceChildren(htmlEl('div', 'tarang-chart-empty', text));
    drawn = [];
  }

  // ----- lines -----
  let axisCache = null, lastUnit = '';
  const kinds = new WeakMap();
  // What a column makes as an x axis: 'number', 'date' (text that reads as dates), or 'text' (its values in order)
  function axisKind(c) {
    if (c.type === 'number') return 'number';
    if (!kinds.has(c)) {
      const dict = c.data.dict;
      let seen = 0, dates = true;
      for (let k = 0; k < dict.length && seen < 50; k++) {   // a sample is enough to tell
        if (dict[k] === '') continue;
        seen++;
        if (parseDate(dict[k]) !== parseDate(dict[k])) { dates = false; break; }
      }
      kinds.set(c, seen && dates ? 'date' : 'text');
    }
    return kinds.get(c);
  }
  const lineAxisKind = () => { const x = columnOf(opts.x); return x ? axisKind(x) : ''; };

  // The x axis: each row's point index (-1: none), and each point's position and label
  function buildAxis(xcol, bucket) {
    const n = table.model.numRows;
    if (xcol.type === 'number') {
      const vals = xcol.data.values, seen = new Set();
      let min = Infinity, max = -Infinity, many = false;
      for (let i = 0; i < n; i++) {
        const v = vals[i];
        if (v !== v) continue;
        if (v < min) min = v;
        if (v > max) max = v;
        if (!many) { seen.add(v); if (seen.size > 200) many = true; }
      }
      if (min === Infinity) return { count: 0 };
      const f = v => (xcol.formatValue ? xcol.formatValue(v) : (+v.toFixed(6)).toLocaleString());
      if (!many) {   // few distinct values: a point each
        const xs = [...seen].sort((a, b) => a - b), at = new Map(xs.map((v, k) => [v, k]));
        return { kind: 'number', count: xs.length, of: i => (vals[i] === vals[i] ? at.get(vals[i]) : -1), pos: k => xs[k], label: k => f(xs[k]), tick: k => f(xs[k]),
          filterText: k => `=${+xs[k].toFixed(xcol.decimals)}`, what: 'value' };   // number filters compare at the shown decimals
      }
      const B = 100, w = (max - min) / B;   // many: 100 equal bins
      return { kind: 'number', count: B, of: i => { const v = vals[i]; return v === v ? Math.min(B - 1, Math.floor((v - min) / w)) : -1; },
        pos: k => min + (k + 0.5) * w, label: k => `${f(min + k * w)} – ${f(min + (k + 1) * w)}`, tick: k => f(min + k * w),
        filterText: k => `>=${+(min + k * w).toPrecision(12)}${k === B - 1 ? `<=${+max.toPrecision(12)}` : `<${+(min + (k + 1) * w).toPrecision(12)}`}`, what: 'range' };
    }
    const dict = xcol.data.dict, codes = xcol.data.codes;
    if (axisKind(xcol) === 'date') {
      const times = dict.map(s => (s === '' ? NaN : parseDate(s)));
      let lo = Infinity, hi = -Infinity;
      for (const t of times) if (t === t) { if (t < lo) lo = t; if (t > hi) hi = t; }
      if (lo === Infinity) return { count: 0 };
      let unit = UNITS.includes(bucket) ? bucket : autoUnit(hi - lo);
      const countFor = u => { let k = 0; for (let t = unitStart(lo, u); t <= hi && k <= MAX_POINTS; t = unitNext(t, u)) k++; return k; };
      while (unit !== 'year' && countFor(unit) > MAX_POINTS) unit = UNITS[UNITS.indexOf(unit) + 1];   // too fine: coarser
      const starts = [], at = new Map();
      for (let t = unitStart(lo, unit); t <= hi; t = unitNext(t, unit)) { at.set(t, starts.length); starts.push(t); }
      const codeTo = Int32Array.from(times, t => (t === t ? at.get(unitStart(t, unit)) : -1));
      const multiYear = new Date(lo).getUTCFullYear() !== new Date(hi).getUTCFullYear();
      const label = k => dateLabel(starts[k], unit, multiYear);
      // The filter for a period: its dates as exact values (e.g. "=2026-01-05 | =2026-01-07"); a period with very
      // many distinct values (timestamps) uses the ISO prefix instead ("2026-01" for a month), or can't be picked
      const inBucket = starts.map(() => []);
      codeTo.forEach((b, c) => { if (b >= 0) inBucket[b].push(dict[c]); });
      const iso = dict.every(s => s === '' || /^\d{4}-\d{2}-\d{2}/.test(s));
      const filterText = k => {
        const vs = inBucket[k];
        if (!vs.length) return null;
        if (vs.length <= 60 && !vs.some(v => v.includes('|'))) return vs.map(v => `=${v}`).join(' | ');
        if (iso && unit === 'month') return new Date(starts[k]).toISOString().slice(0, 7);
        if (iso && unit === 'year') return new Date(starts[k]).toISOString().slice(0, 5);
        if (iso && unit === 'day') return new Date(starts[k]).toISOString().slice(0, 10);
        return null;
      };
      return { kind: 'date', unit, count: starts.length, of: i => codeTo[codes[i]], pos: k => starts[k], label, tick: label, filterText, what: unit };
    }
    // Text: its distinct values in order (numbers inside them compared as numbers), evenly spaced
    const order = [];
    for (let c = 0; c < dict.length; c++) if (dict[c] !== '') order.push(c);
    order.sort((a, b) => COLLATOR.compare(dict[a], dict[b]));
    const codeTo = new Int32Array(dict.length).fill(-1);
    order.forEach((c, k) => { codeTo[c] = k; });
    const label = k => (xcol.formatValue ? xcol.formatValue(dict[order[k]]) : dict[order[k]]);
    return { kind: 'text', count: order.length, of: i => codeTo[codes[i]], pos: k => k, label, tick: label,
      filterText: k => (dict[order[k]].includes('|') ? null : `=${dict[order[k]]}`), what: 'value' };
  }

  // Where the tooltip goes: beside the pointer, inside the chart
  function placeTip(e) {
    tip.hidden = false;
    const box = root.getBoundingClientRect();
    let x = e.clientX - box.left + 14, y = e.clientY - box.top + 14;
    if (x + tip.offsetWidth > box.width - 4) x = e.clientX - box.left - tip.offsetWidth - 14;
    if (y + tip.offsetHeight > box.height - 4) y = e.clientY - box.top - tip.offsetHeight - 14;
    tip.style.left = `${Math.max(4, x)}px`; tip.style.top = `${Math.max(4, y)}px`;
  }

  // A line per category of `column` (or one line), along the x column; values are row counts or sums
  function renderLine() {
    if (pickers && !columnOf(opts.x)) {   // start along the first date column (else number, else any)
      const all = table.model.allColumns.filter(sliceable);
      const first = all.find(c => axisKind(c) === 'date') || all.find(c => c.type === 'number') || all[0];
      if (first) opts = { ...opts, x: first.key };
    }
    const xcol = columnOf(opts.x), col = opts.column ? columnOf(opts.column) : null, valCol = opts.value ? columnOf(opts.value) : null;
    if (pickers) pickers.sync(col, valCol, xcol);
    titleEl.textContent = opts.title || (xcol ? `${valCol ? valCol.label : 'rows'} over ${xcol.label}${col ? ` · by ${col.label}` : ''}` : 'Chart');
    const fail = text => { subEl.textContent = ''; message(text); };
    if (!xcol) return fail(opts.x ? `No column "${opts.x}" in the table.` : 'Choose a column for the lines to run along (x).');
    if (opts.column && !col) return fail(`No column "${opts.column}" in the table.`);
    if (opts.value && (!valCol || valCol.type !== 'number')) return fail(`"${opts.value}" isn't a number column, so it can't be summed.`);
    const bucket = UNITS.includes(opts.bucket) ? opts.bucket : 'auto';
    if (!axisCache || axisCache.col !== xcol || axisCache.bucket !== bucket || axisCache.model !== table.model) {
      axisCache = { col: xcol, bucket, model: table.model, axis: buildAxis(xcol, bucket) };
    }
    const axis = axisCache.axis;
    lastUnit = axis.unit || '';
    if (!axis.count) return fail(`"${xcol.label}" has no values to draw along.`);
    if (col && (!identity || identity.col !== col || identity.valCol !== valCol)) identity = buildIdentity(col, valCol);
    if (col) coloured = [col];

    // Sum per series and point. Series k is the k-th coloured category; the last one is "Other" (or the one line)
    const cats = col ? identity.cats : null, named = col ? identity.order : [];
    const S = named.length + 1, B = axis.count;
    const slotOf = cats ? new Int32Array(cats.count).fill(named.length) : null;
    named.forEach((c, k) => { slotOf[c] = k; });
    const sums = new Float64Array(S * B), counts = new Float64Array(S), rep = cats ? new Int32Array(cats.count).fill(-1) : null;
    // The table's filters, except (when the chart is a filter control) those on its own columns: the series
    // column (picked from the legend) and the x column (picked by clicking along the axis)
    const view = table.view, model = table.model, own = col ? view.filters.get(col) : null;
    const ownX = opts.clickToFilter ? view.filters.get(xcol) || null : null;
    const tests = opts.filtered ? [...view.filters].filter(([c]) => !(opts.clickToFilter && (c === col || c === xcol))).map(([, f]) => f.test) : [];
    const hidden = opts.filtered && model.hidden && !view.showHidden ? model.hidden : null;
    const vals = valCol ? valCol.data.values : null;
    const repX = new Int32Array(B).fill(-1);   // a row in each point, to ask the x filter about it
    let rowCount = 0;
    rows: for (let i = 0, n = model.numRows; i < n; i++) {
      if (hidden && hidden[i]) continue;
      for (const t of tests) if (!t(i)) continue rows;
      const b = axis.of(i);
      if (!(b >= 0)) continue;
      const w = vals ? vals[i] : 1;
      if (w !== w) continue;
      let s = 0;
      if (cats) { const c = cats.of(i); s = slotOf[c]; if (rep[c] < 0) rep[c] = i; }
      if (repX[b] < 0) repX[b] = i;
      sums[s * B + b] += w;
      counts[s]++;
      rowCount++;
    }
    const passesOwn = c => !own || !opts.clickToFilter || (rep[c] >= 0 && own.test(rep[c]));
    const litX = b => !ownX || (repX[b] >= 0 && ownX.test(repX[b]));   // a point the x filter keeps
    const series = [];
    for (let k = 0; k < S; k++) {
      if (!counts[k] || (!col && k > 0)) continue;
      const values = sums.subarray(k * B, (k + 1) * B), value = values.reduce((a, v) => a + v, 0);
      if (!col) { series.push({ cat: -1, name: valCol ? valCol.label : 'rows', color: SLOTS[0], values, value }); continue; }
      if (k < named.length) { series.push({ cat: named[k], name: cats.name(named[k]), color: identity.colorFor(named[k]), values, value, dim: !passesOwn(named[k]) }); continue; }
      const others = [];
      for (let c = 0; c < cats.count; c++) if (slotOf[c] === named.length && rep[c] >= 0) others.push(c);
      series.push({ cat: -1, name: `Other (${others.length})`, color: OTHER, other: true, cats: others, values, value, dim: !others.some(passesOwn) });
    }
    const total = series.reduce((a, s) => a + s.value, 0);
    for (const s of series) s.share = total ? s.value / total : 0;
    drawn = series;

    const fmtValue = v => (valCol
      ? (valCol.formatValue ? valCol.formatValue(v) : v.toLocaleString(undefined, { maximumFractionDigits: valCol.decimals }))
      : v.toLocaleString());
    const filteredNote = opts.filtered && (tests.length || hidden) ? ' · following the table\'s filters' : '';
    subEl.textContent = `${rowCount.toLocaleString()} rows${valCol ? ` · ${fmtValue(total)} total` : ''}${axis.unit ? ` · by ${axis.unit}` : ''}${filteredNote}`;
    if ((own && opts.clickToFilter && col) || ownX) {   // what the table shows of this chart
      let lit = 0;
      for (const s of series) if (!s.dim) for (let b = 0; b < B; b++) if (litX(b)) lit += s.values[b];
      const points = ownX ? [...Array(B).keys()].filter(b => litX(b) && repX[b] >= 0).length : 0;
      subEl.textContent += ` · ${fmtValue(lit)} (${pct(total ? lit / total : 0)}) selected`
        + (ownX ? ` in ${points} ${axis.what}${points === 1 ? '' : 's'}` : '');
    }
    if (!series.length) return message(rowCount ? 'Nothing to show.' : 'No rows match the table\'s filters.');

    // Clicking along the axis filters the table's x column to that point; Ctrl/⌘ adds or removes points;
    // clicking the only selected point again clears it.
    // `part`: what else the click picks: undefined (a line's point: the category filter is left alone),
    // null (a column's empty space: every category), or a series (a column's part: that category too)
    const pickedPoints = () => (ownX ? [...Array(B).keys()].filter(b => repX[b] >= 0 && litX(b)) : []);
    const catNow = () => (own ? own.text : '');
    const catFor = part => (part && col ? clickText(part) : '');   // '' = every category
    const isOnly = (k, part) => {   // this click would pick exactly what is picked already
      const picked = pickedPoints();
      return picked.length === 1 && picked[0] === k && (part === undefined || catFor(part) === catNow());
    };
    const clickPoint = (k, e, part) => {
      if (!opts.clickToFilter || !axis.filterText || axis.filterText(k) == null) return;
      if (part && col && catFor(part) == null) return;   // a category the filter can't express
      let set;
      if (e.ctrlKey || e.metaKey) {
        set = new Set(pickedPoints());
        if (set.has(k) && (part === undefined || catFor(part) === catNow())) set.delete(k); else set.add(k);
      } else set = isOnly(k, part) ? new Set() : new Set([k]);
      const texts = [...set].sort((a, b) => a - b).map(b => axis.filterText(b));
      if (texts.some(x => x == null)) return;
      // Both filters in one step, so the table and charts redraw once
      const filters = { ...table.getState().filters, [xcol.key]: texts.join(' | ') };
      if (part !== undefined && col) filters[col.key] = set.size ? catFor(part) : '';
      for (const key of Object.keys(filters)) if (!filters[key]) delete filters[key];
      table.setState({ filters });
    };
    const pointHint = (k, part) => {
      if (!opts.clickToFilter || !axis.filterText || axis.filterText(k) == null) return '';
      if (isOnly(k, part)) return 'Click to show every row again';
      const what = `this ${axis.what}`;
      if (part && col && series.length > 1) return `Click to show only ${part.name} in ${what} · the empty space above picks the whole ${axis.what}`;
      return `Click to show only ${what} · Ctrl+click to add it`;
    };

    // Legend (two or more lines): names, totals, shares; hover picks a line out, click filters the table
    let legend = null, focusLine = () => {};
    const svg = svgEl('svg', { class: 'tarang-chart-lines', role: 'img', 'aria-label': titleEl.textContent });
    if (series.length > 1) {
      legend = htmlEl('div', 'tarang-chart-legend');
      series.forEach((s, k) => {
        const b = htmlEl('button', 'tarang-chart-row' + (s.dim ? ' tarang-dim' : ''));
        b.type = 'button';
        b.title = clickTitle(s);
        const key = htmlEl('span', isColumn() ? 'tarang-chart-key' : 'tarang-chart-key tarang-chart-key-line');   // the key looks like the mark
        key.style.background = s.color;
        b.append(key, htmlEl('span', 'tarang-chart-name', s.name), htmlEl('span', 'tarang-chart-num', fmtValue(s.value)), htmlEl('span', 'tarang-chart-pct', pct(s.share)));
        b.addEventListener('pointerenter', () => focusLine(k));
        b.addEventListener('pointerleave', () => focusLine(-1));
        b.addEventListener('focus', () => focusLine(k));
        b.addEventListener('blur', () => focusLine(-1));
        b.addEventListener('click', () => pick(s));
        legend.appendChild(b);
      });
    }
    body.replaceChildren(svg, ...(legend ? [legend] : []));
    const narrow = !!legend && body.clientWidth < 520;
    body.classList.toggle('tarang-chart-narrow', narrow);
    const W = Math.max(160, Math.floor(legend && !narrow ? body.clientWidth - legend.offsetWidth - 20 : body.clientWidth));
    const H = Math.max(110, Math.floor(narrow ? body.clientHeight - legend.offsetHeight - 12 : body.clientHeight));
    svg.setAttribute('width', W); svg.setAttribute('height', H); svg.setAttribute('viewBox', `0 0 ${W} ${H}`);

    // How the series sit. Columns: stacked, side by side, or stacked to 100%. Lines: overlapping (each from 0),
    // stacked areas (each on the ones below), or stacked to 100%
    const columns = isColumn(), multi = series.length > 1;
    const mode = columns ? (opts.stack === 'group' || opts.stack === 'percent' ? opts.stack : 'stack')
      : (opts.lines === 'stack' || opts.lines === 'percent' ? opts.lines : 'overlap');
    const percent = multi && mode === 'percent', stacked = multi && (mode === 'stack' || percent);
    // What is drawn: the values, or (100%) each one's share of its point's total, as 0–100
    const plotted = series.map(s => (percent ? new Float64Array(B) : s.values));
    if (percent) {
      for (let k = 0; k < B; k++) {
        let sum = 0;
        for (const s of series) sum += Math.abs(s.values[k]);
        if (sum) series.forEach((s, j) => { plotted[j][k] = (s.values[k] / sum) * 100; });
      }
    }
    // Stacked: each part's bottom (`from`) and top (`to`), in series order: positives up from 0, negatives down
    const from = stacked ? series.map(() => new Float64Array(B)) : null;
    const to = stacked ? series.map(() => new Float64Array(B)) : null;
    const yOf = (j, k) => (stacked ? to[j][k] : plotted[j][k]);   // where series j's line (or column top) is at point k

    // Scales: one y axis from the lowest to the highest point (stacked: the totals), always including 0
    let lo = 0, hi = 0;
    if (stacked) {
      for (let k = 0; k < B; k++) {
        let up = 0, down = 0;
        series.forEach((s, j) => {
          const v = plotted[j][k];
          if (v > 0) { from[j][k] = up; to[j][k] = up += v; } else { from[j][k] = down; to[j][k] = down += v; }
        });
        if (up > hi) hi = up;
        if (down < lo) lo = down;
      }
      if (percent) { hi = Math.min(hi, 100); lo = Math.max(lo, -100); }   // rounding can leave 100.0000001
    } else for (const p of plotted) for (const v of p) { if (v < lo) lo = v; if (v > hi) hi = v; }
    const ticks = niceTicks(lo, hi, Math.max(2, Math.min(6, Math.floor(H / 45))));
    const y0 = ticks[0], y1 = ticks[ticks.length - 1];
    const tickText = v => (percent ? `${v.toLocaleString(undefined, { maximumFractionDigits: 1 })}%`
      : Math.abs(v) >= 10000 ? compact.format(v) : valCol && valCol.formatValue ? valCol.formatValue(v) : v.toLocaleString(undefined, { maximumFractionDigits: 2 }));

    // A tooltip row: the colour, the value, its share of the point (100%), and the name
    const tipRow = (j, k, hot) => {
      const s = series[j], row = htmlEl('div', 'tarang-chart-tip-value' + (s.dim ? ' tarang-dim' : '') + (hot ? ' tarang-hot' : ''));
      const key = htmlEl('span', 'tarang-chart-tip-key');
      key.style.background = s.color;
      const share = plotted[j][k];
      row.append(key, htmlEl('b', null, fmtValue(s.values[k])),
        ...(percent ? [htmlEl('span', 'tarang-chart-pct', ` ${share < 0 ? '−' : ''}${pct(Math.abs(share) / 100)}`)] : []),
        ...(multi ? [htmlEl('span', 'tarang-chart-pct', ` ${s.name}`)] : []));
      return row;
    };
    const tipTotal = k => htmlEl('div', 'tarang-chart-tip-total', `total ${fmtValue(series.reduce((a, s) => a + s.values[k], 0))}`);
    const pad = { l: 12 + Math.max(...ticks.map(v => tickText(v).length)) * 6.6, r: 14, t: 8, b: 24 };
    const pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
    const p0 = axis.pos(0), p1 = axis.pos(B - 1);
    // Lines place points by their position (dates and numbers to scale); columns sit in equal bands
    const band = pw / B;
    const X = columns ? k => pad.l + (k + 0.5) * band : k => pad.l + (B === 1 ? pw / 2 : ((axis.pos(k) - p0) / (p1 - p0)) * pw);
    const Y = v => pad.t + (1 - (v - y0) / (y1 - y0)) * ph;

    // Hairline grid and labels; the zero line a step stronger
    for (const v of ticks) {
      const y = Math.round(Y(v)) + 0.5;
      svg.appendChild(svgEl('line', { x1: pad.l, x2: W - pad.r, y1: y, y2: y, class: v === 0 ? 'tarang-chart-zero' : 'tarang-chart-grid' }));
      const t = svgEl('text', { x: pad.l - 8, y, class: 'tarang-chart-axis', 'text-anchor': 'end', 'dominant-baseline': 'central' });
      t.textContent = tickText(v);
      svg.appendChild(t);
    }
    const every = Math.max(1, Math.ceil(B / Math.max(1, Math.floor(pw / 90))));
    for (let k = 0; k < B; k += every) {
      const t = svgEl('text', { x: X(k), y: H - 6, class: 'tarang-chart-axis', 'text-anchor': columns || B === 1 ? 'middle' : k === 0 ? 'start' : k + every >= B ? 'end' : 'middle' });
      t.textContent = axis.tick(k);
      svg.appendChild(t);
    }

    const base = Y(Math.min(y1, Math.max(y0, 0)));
    if (columns) return drawColumns();

    // Points the table's x filter keeps: a highlighted band behind each (half way to its neighbours)
    if (ownX) {
      for (let k = 0; k < B; k++) {
        if (!(repX[k] >= 0 && litX(k))) continue;
        const left = k ? (X(k - 1) + X(k)) / 2 : X(k) - (B > 1 ? (X(1) - X(0)) / 2 : 12);
        const right = k < B - 1 ? (X(k) + X(k + 1)) / 2 : X(k) + (B > 1 ? (X(k) - X(k - 1)) / 2 : 12);
        svg.appendChild(svgEl('rect', { class: 'tarang-chart-picked', x: Math.max(pad.l, left), y: pad.t, width: Math.max(2, Math.min(W - pad.r, right) - Math.max(pad.l, left)), height: ph }));
      }
    }

    // The lines (dimmed ones underneath); one line gets a light wash beneath it.
    // Stacked: each series is a filled band from the ones below it up to its own line
    const lineEls = [];
    const draw = [...series.keys()].sort((a, b) => (series[b].dim ? 1 : 0) - (series[a].dim ? 1 : 0));
    for (const k of draw) {
      const s = series[k];
      let d = '';
      for (let j = 0; j < B; j++) d += `${j ? 'L' : 'M'}${X(j).toFixed(1)} ${Y(yOf(k, j)).toFixed(1)}`;
      const g = svgEl('g', s.dim ? { opacity: 0.25 } : {});
      if (stacked) {
        let back = '';   // along the band's bottom edge, right to left
        for (let j = B - 1; j >= 0; j--) back += `L${X(j).toFixed(1)} ${Y(from[k][j]).toFixed(1)}`;
        g.appendChild(svgEl('path', { d: `${d}${back}Z`, fill: s.color, 'fill-opacity': 0.55 }));
      } else if (series.length === 1) g.appendChild(svgEl('path', { d: `${d}L${X(B - 1).toFixed(1)} ${base}L${X(0).toFixed(1)} ${base}Z`, fill: s.color, 'fill-opacity': 0.1 }));
      g.appendChild(svgEl('path', { d, fill: 'none', stroke: s.color, 'stroke-width': stacked ? 1.5 : 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
      if (B === 1) g.appendChild(svgEl('circle', { cx: X(0), cy: Y(yOf(k, 0)), r: 4, fill: s.color }));
      svg.appendChild(g);
      lineEls[k] = g;
    }
    focusLine = k => lineEls.forEach((g, j) => g.setAttribute('opacity', k < 0 ? (series[j].dim ? 0.25 : 1) : j === k ? 1 : 0.15));

    // Hover: a guide snaps to the nearest point; the tooltip lists every line there
    const guide = svgEl('line', { class: 'tarang-chart-guide', y1: pad.t, y2: pad.t + ph, visibility: 'hidden' });
    const dots = series.map(s => svgEl('circle', { r: 4, fill: s.color, stroke: SURFACE, 'stroke-width': 2, visibility: 'hidden' }));
    const hit = svgEl('rect', { x: pad.l - 6, y: pad.t, width: pw + 12, height: ph, fill: 'transparent', class: opts.clickToFilter ? 'tarang-chart-pickable' : '' });
    svg.append(guide, ...dots, hit);
    const nearest = e => {
      const px = e.clientX - svg.getBoundingClientRect().left;
      // binary search for the first point at or right of the pointer, then take whichever neighbour is closer
      let a = 0, z = B - 1;
      while (a < z) { const m = Math.floor((a + z) / 2); if (X(m) < px) a = m + 1; else z = m; }
      return a > 0 && Math.abs(X(a - 1) - px) < Math.abs(X(a) - px) ? a - 1 : a;
    };
    hit.addEventListener('click', e => clickPoint(nearest(e), e));
    hit.addEventListener('pointermove', e => {
      const k = nearest(e);
      const gx = Math.round(X(k)) + 0.5;
      guide.setAttribute('x1', gx); guide.setAttribute('x2', gx); guide.setAttribute('visibility', 'visible');
      series.forEach((s, j) => { dots[j].setAttribute('cx', X(k)); dots[j].setAttribute('cy', Y(yOf(j, k))); dots[j].setAttribute('visibility', s.dim ? 'hidden' : 'visible'); });
      tip.replaceChildren(htmlEl('div', 'tarang-chart-tip-name', axis.label(k)));
      // Stacked: top to bottom, as drawn; otherwise biggest first
      const order = stacked ? [...series.keys()].reverse() : [...series.keys()].sort((p, q) => series[q].values[k] - series[p].values[k]);
      for (const j of order) tip.appendChild(tipRow(j, k));
      if (stacked) tip.appendChild(tipTotal(k));
      if (pointHint(k)) tip.appendChild(htmlEl('div', 'tarang-chart-tip-hint', pointHint(k)));
      placeTip(e);
    });
    hit.addEventListener('pointerleave', () => {
      tip.hidden = true;
      guide.setAttribute('visibility', 'hidden');
      dots.forEach(d => d.setAttribute('visibility', 'hidden'));
    });

    // Columns: stacked (positives up from 0, negatives down) or side by side; at most 24px wide, the outer
    // end rounded, a hairline of background between stacked parts
    function drawColumns() {
      const groups = series.map(s => { const g = svgEl('g', s.dim ? { opacity: 0.25 } : {}); return g; });
      const lane = stacked || series.length === 1 ? Math.min(24, Math.max(1, band * 0.7))
        : Math.min(24, Math.max(1, (band * 0.8) / series.length - (band > 8 ? 1 : 0)));
      const gap = lane >= 6 ? 1 : 0;
      const hl = svgEl('rect', { class: 'tarang-chart-band', y: pad.t, height: ph, width: band, visibility: 'hidden' });
      svg.appendChild(hl);
      const boxes = Array.from({ length: B }, () => []);
      for (let k = 0; k < B; k++) {
        // the outermost part in each direction gets the rounded end
        let topJ = -1, botJ = -1;
        if (stacked) series.forEach((s, j) => { if (s.values[k] > 0) topJ = j; else if (s.values[k] < 0) botJ = j; });
        series.forEach((s, j) => {
          const v = s.values[k];
          if (!v) return;
          let x, yA, yB;
          if (stacked) {
            x = X(k) - lane / 2;
            yA = Y(from[j][k]); yB = Y(to[j][k]);
          } else {
            const n = series.length, slot = (lane + (n > 1 && band > 8 ? 1 : 0));
            x = X(k) - (slot * n) / 2 + slot * j;
            yA = Y(0); yB = Y(v);
          }
          const top = Math.min(yA, yB), h = Math.abs(yB - yA);
          const outer = !stacked || j === (v > 0 ? topJ : botJ);
          const d = barPath(x, top, lane, h, outer ? (v > 0 ? 'top' : 'bottom') : null);
          boxes[k].push({ j, x, top, h, d });   // for finding the part under the pointer
          groups[j].appendChild(svgEl('path', {
            d,
            fill: s.color, stroke: stacked ? SURFACE : 'none', 'stroke-width': stacked ? gap * 2 : 0,   // 2px between parts
            ...(litX(k) ? {} : { opacity: 0.3 }),   // a period the table's x filter leaves out
          }));
        });
      }
      svg.append(...groups);
      focusLine = k => groups.forEach((g, j) => g.setAttribute('opacity', k < 0 ? (series[j].dim ? 0.25 : 1) : j === k ? 1 : 0.15));

      // Hover: the column's band lights up; the tooltip lists every part (and the total, when stacked)
      // The hovered part gets an outline; the hit area sits on top, so it finds the part itself
      const outline = svgEl('path', { class: 'tarang-chart-part-hot', visibility: 'hidden' });
      const hit = svgEl('rect', { x: pad.l, y: pad.t, width: pw, height: ph, fill: 'transparent', class: opts.clickToFilter ? 'tarang-chart-pickable' : '' });
      svg.append(outline, hit);
      const bandAt = e => Math.max(0, Math.min(B - 1, Math.floor((e.clientX - svg.getBoundingClientRect().left - pad.l) / band)));
      const partAt = (e, k) => {   // the part under the pointer (thin parts get a few px of slack), or null
        const r = svg.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
        const box = boxes[k].find(b => px >= b.x - 1 && px <= b.x + lane + 1 && py >= b.top - Math.max(1, (3 - b.h) / 2) && py <= b.top + Math.max(b.h, 3) + 1);
        return box || null;
      };
      hit.addEventListener('click', e => {
        const k = bandAt(e), box = partAt(e, k);
        clickPoint(k, e, box ? series[box.j] : null);   // a part: that category in that period; empty space: the whole period
      });
      hit.addEventListener('pointerleave', () => outline.setAttribute('visibility', 'hidden'));
      hit.addEventListener('pointermove', e => {
        const k = bandAt(e), box = partAt(e, k);
        hl.setAttribute('x', pad.l + k * band); hl.setAttribute('visibility', 'visible');
        if (box && series.length > 1) { outline.setAttribute('d', box.d); outline.setAttribute('visibility', 'visible'); }
        else outline.setAttribute('visibility', 'hidden');
        tip.replaceChildren(htmlEl('div', 'tarang-chart-tip-name', axis.label(k)));
        const parts = [...series.keys()].filter(j => series[j].values[k]).sort((p, q) => series[q].values[k] - series[p].values[k]);
        for (const j of parts) tip.appendChild(tipRow(j, k, box && box.j === j && multi));
        if (!parts.length) tip.appendChild(htmlEl('div', 'tarang-chart-tip-value', fmtValue(0)));
        if (stacked && parts.length > 1) tip.appendChild(tipTotal(k));
        const hint = pointHint(k, box ? series[box.j] : null);
        if (hint) tip.appendChild(htmlEl('div', 'tarang-chart-tip-hint', hint));
        placeTip(e);
      });
      hit.addEventListener('pointerleave', () => { tip.hidden = true; hl.setAttribute('visibility', 'hidden'); });
    }
  }

  // ----- flow (Sankey): one column of nodes per stage, rows flowing between neighbouring stages -----
  let stageCache = null;   // each stage's colours / "Other" folding, like a pie of that column
  const stageIdentity = (col, valCol) => {
    const n = sliceCount();
    if (!stageCache || stageCache.model !== table.model || stageCache.valCol !== valCol || stageCache.n !== n) {
      stageCache = { model: table.model, valCol, n, ids: new Map() };
    }
    if (!stageCache.ids.has(col)) stageCache.ids.set(col, buildIdentity(col, valCol));
    return stageCache.ids.get(col);
  };
  const sankeyColorKey = () => {
    const stages = opts.stages || [];
    const c = columnOf(opts.colorBy);
    return c && stages.some(k => columnOf(k) === c) ? c.key : (columnOf(stages[0]) || {}).key || '';
  };

  function renderSankey() {
    const model = table.model;
    // Stages: the columns given (each once); with the menu and too few, start from columns with few values
    let keys = [];
    for (const k of opts.stages || []) { const c = columnOf(k); if (c && !keys.some(x => columnOf(x) === c)) keys.push(c.key); }
    if (pickers && keys.length < 2) {
      const fit = model.allColumns.filter(c => sliceable(c) && c.type === 'text' && c.data.dict.length <= 40 && axisKind(c) !== 'date');
      const start = columnOf(opts.column);
      for (const c of [...(start ? [start] : []), ...fit]) { if (keys.length >= 3) break; if (!keys.includes(c.key)) keys.push(c.key); }
    }
    if (pickers && keys.join('\u0001') !== (opts.stages || []).join('\u0001')) opts = { ...opts, stages: keys };
    const cols = keys.map(columnOf), S = cols.length;
    const valCol = opts.value ? columnOf(opts.value) : null;
    if (pickers) pickers.sync(null, valCol, null);
    titleEl.textContent = opts.title || (S ? cols.map(c => c.label).join(' → ') : 'Flow');
    const fail = text => { subEl.textContent = ''; message(text); };
    if (S < 2) return fail('Choose two or more columns for the flow to run through (stages).');
    if (opts.value && (!valCol || valCol.type !== 'number')) return fail(`"${opts.value}" isn't a number column, so it can't be summed.`);

    // Nodes: per stage, its coloured categories then "Other"
    const ids = cols.map(c => stageIdentity(c, valCol));
    const nodeOf = ids.map(id => {
      const m = new Int32Array(id.cats.count).fill(id.order.length);
      id.order.forEach((c, k) => { m[c] = k; });
      return m;
    });
    const M = Math.max(...ids.map(id => id.order.length + 1));
    const cs = Math.max(0, keys.indexOf(sankeyColorKey()));   // the stage that colours the flows
    const NC = ids[cs].order.length + 1;
    const colorOf = c => (c < ids[cs].order.length ? ids[cs].colorFor(ids[cs].order[c]) : OTHER);   // c: a node of the colour stage
    coloured = [cols[cs]];

    // The table's filters, except (as a filter control) those on the stages: those decide what is lit
    const view = table.view, stageSet = new Set(cols);
    const ownTests = opts.clickToFilter ? [...view.filters].filter(([c]) => stageSet.has(c)).map(([, f]) => f.test) : [];
    const tests = opts.filtered ? [...view.filters].filter(([c]) => !(opts.clickToFilter && stageSet.has(c))).map(([, f]) => f.test) : [];
    const hidden = opts.filtered && model.hidden && !view.showHidden ? model.hidden : null;
    const vals = valCol ? valCol.data.values : null;
    const nodeV = new Float64Array(S * M), nodeLit = new Float64Array(S * M);
    const linkV = new Float64Array((S - 1) * M * M * NC), linkLit = new Float64Array(linkV.length);
    const ns = new Int32Array(S), seen = ids.map(id => new Uint8Array(id.cats.count));   // categories with rows
    // With routes: each route's total, keyed by its nodes as digits in base M (stage 0 lowest)
    const routes = opts.routes ? new Map() : null;
    let rowCount = 0, negatives = 0, total = 0, litTotal = 0;
    rows: for (let i = 0, n = model.numRows; i < n; i++) {
      if (hidden && hidden[i]) continue;
      for (const t of tests) if (!t(i)) continue rows;
      const w = vals ? vals[i] : 1;
      if (!(w > 0)) { if (w < 0) negatives++; continue; }
      let lit = true;
      for (const t of ownTests) if (!t(i)) { lit = false; break; }
      for (let s = 0; s < S; s++) { const cat = ids[s].cats.of(i); ns[s] = nodeOf[s][cat]; seen[s][cat] = 1; }
      const c = ns[cs];
      for (let s = 0; s < S; s++) { nodeV[s * M + ns[s]] += w; if (lit) nodeLit[s * M + ns[s]] += w; }
      for (let s = 0; s < S - 1; s++) {
        const at = ((s * M + ns[s]) * M + ns[s + 1]) * NC + c;
        linkV[at] += w;
        if (lit) linkLit[at] += w;
      }
      if (routes) {
        let code = 0;
        for (let s = S - 1; s >= 0; s--) code = code * M + ns[s];
        const r = routes.get(code);
        if (r) { r.v += w; if (lit) r.lit += w; } else routes.set(code, { v: w, lit: lit ? w : 0 });
      }
      rowCount++; total += w; if (lit) litTotal += w;
    }

    const fmtValue = v => (valCol
      ? (valCol.formatValue ? valCol.formatValue(v) : v.toLocaleString(undefined, { maximumFractionDigits: valCol.decimals }))
      : v.toLocaleString());
    const filteredNote = opts.filtered && (tests.length || hidden) ? ' · following the table\'s filters' : '';
    subEl.textContent = `${rowCount.toLocaleString()} rows${valCol ? ` · ${fmtValue(total)} total` : ''}${filteredNote}`
      + (ownTests.length ? ` · ${fmtValue(litTotal)} (${pct(total ? litTotal / total : 0)}) selected` : '')
      + (negatives ? ` · ${negatives.toLocaleString()} negative values left out` : '');
    if (!total) return message(rowCount ? 'Nothing to show: every value is zero or empty.' : 'No rows match the table\'s filters.');
    const anyOwn = ownTests.length > 0;

    // The colour stage's nodes stand in for the legend (and for chart.slices)
    drawn = [];
    for (let k = 0; k < NC; k++) {
      const v = nodeV[cs * M + k];
      if (v > 0) drawn.push({ name: nodeName(cs, k), value: v, share: v / total, color: colorOf(k), other: k === ids[cs].order.length, dim: anyOwn && !nodeLit[cs * M + k] });
    }
    function nodeName(s, k) {
      const id = ids[s];
      if (k < id.order.length) return id.cats.name(id.order[k]);
      let n = 0;
      for (let c = 0; c < id.cats.count; c++) if (nodeOf[s][c] === id.order.length && seen[s][c]) n++;
      return `Other (${n})`;
    }

    // Layout: stages evenly across, nodes stacked in each (centred), one scale for all
    const svg = svgEl('svg', { class: 'tarang-chart-sankey', role: 'img', 'aria-label': titleEl.textContent });
    body.replaceChildren(svg);
    body.classList.remove('tarang-chart-narrow');
    const W = Math.max(200, Math.floor(body.clientWidth)), H = Math.max(140, Math.floor(body.clientHeight));
    svg.setAttribute('width', W); svg.setAttribute('height', H); svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    const nodeW = 12, gapY = 8, pad = { l: 4, r: 4, t: 20, b: 4 };
    const ph = H - pad.t - pad.b;
    const present = s => [...Array(M).keys()].filter(k => nodeV[s * M + k] > 0);
    const scale = Math.min(...cols.map((_, s) => (ph - gapY * (present(s).length - 1)) / total));
    const xs = cols.map((_, s) => pad.l + (s * (W - pad.l - pad.r - nodeW)) / (S - 1));
    const nodeY = new Float64Array(S * M);
    cols.forEach((_, s) => {
      const list = present(s), height = total * scale + gapY * (list.length - 1);
      let y = pad.t + (ph - height) / 2;
      for (const k of list) { nodeY[s * M + k] = y; y += nodeV[s * M + k] * scale + gapY; }
    });

    // Stage names above
    cols.forEach((c, s) => {
      const t = svgEl('text', { x: s === 0 ? xs[s] : s === S - 1 ? xs[s] + nodeW : xs[s] + nodeW / 2, y: 11, class: 'tarang-chart-stage', 'text-anchor': s === 0 ? 'start' : s === S - 1 ? 'end' : 'middle' });
      t.textContent = c.label;
      svg.appendChild(t);
    });

    const links = [];
    let routeList = null;
    if (routes) {
      // Routes: each route keeps one place in every node, the same on both sides, so it runs straight through.
      // A node stacks its routes by where they came from (the stage before first, then further back), then by
      // where they go: what arrives together leaves together, then fans out
      routeList = [...routes].map(([code, r]) => {
        const path = new Int32Array(S);
        for (let s = 0; s < S; s++) { path[s] = code % M; code = Math.floor(code / M); }
        return { path, v: r.v, lit: anyOwn ? r.lit : r.v, at: new Float64Array(S) };
      });
      for (let s = 0; s < S; s++) {
        const by = [];
        for (let j = s - 1; j >= 0; j--) by.push(j);
        for (let j = s + 1; j < S; j++) by.push(j);
        const cur = Float64Array.from(nodeY);
        const sorted = [...routeList].sort((p, q) => {
          if (p.path[s] !== q.path[s]) return p.path[s] - q.path[s];
          for (const j of by) if (p.path[j] !== q.path[j]) return p.path[j] - q.path[j];
          return 0;
        });
        for (const r of sorted) { const i = s * M + r.path[s]; r.at[s] = cur[i]; cur[i] += r.v * scale; }
      }
      // The selected part of a route runs along its top (a route is all selected or not, unless an "Other"
      // node is picked by a filter that matches only some of it)
      for (const r of routeList) {
        for (let s = 0; s < S - 1; s++) {
          const l = { s, a: r.path[s], b: r.path[s + 1], c: r.path[cs], v: r.v, lit: r.lit, route: r, parts: [] };
          const on = r.lit * scale;
          if (r.v > r.lit) l.parts.push({ y0: r.at[s] + on, y1: r.at[s + 1] + on, h: (r.v - r.lit) * scale, dim: true });
          if (r.lit > 0) l.parts.push({ y0: r.at[s], y1: r.at[s + 1], h: on, dim: false });
          links.push(l);
        }
      }
    } else {
      // Flows: each link leaves its source in target order and arrives in source order, so bands don't cross
      // inside a node; split by the colour stage's category
      for (let s = 0; s < S - 1; s++) {
        for (let a = 0; a < M; a++) for (let b = 0; b < M; b++) for (let c = 0; c < NC; c++) {
          const at = ((s * M + a) * M + b) * NC + c;
          if (linkV[at] > 0) links.push({ s, a, b, c, v: linkV[at], lit: anyOwn ? linkLit[at] : linkV[at], parts: [] });
        }
      }
      // With a selection each link splits into its selected and unselected parts, and every node stacks the
      // selected parts at its top, so what the selection brings in and sends on line up through the node
      const outOn = Float64Array.from(nodeY), inOn = Float64Array.from(nodeY);
      const outOff = nodeY.map((y, i) => y + (anyOwn ? nodeLit[i] : nodeV[i]) * scale), inOff = Float64Array.from(outOff);
      const on = new Map(), off = new Map();
      for (const l of [...links].sort((p, q) => p.s - q.s || p.a - q.a || p.b - q.b || p.c - q.c)) {
        const i = l.s * M + l.a;
        on.set(l, { y0: outOn[i], h: l.lit * scale, dim: false }); outOn[i] += l.lit * scale;
        off.set(l, { y0: outOff[i], h: (l.v - l.lit) * scale, dim: true }); outOff[i] += (l.v - l.lit) * scale;
      }
      for (const l of [...links].sort((p, q) => p.s - q.s || p.b - q.b || p.a - q.a || p.c - q.c)) {
        const i = (l.s + 1) * M + l.b;
        on.get(l).y1 = inOn[i]; inOn[i] += l.lit * scale;
        off.get(l).y1 = inOff[i]; inOff[i] += (l.v - l.lit) * scale;
        if (l.v > l.lit) l.parts.push(off.get(l));
        if (l.lit > 0) l.parts.push(on.get(l));
      }
    }
    const band = (x0, y0, x1, y1, w) => {
      const xm = (x0 + x1) / 2, f = n => n.toFixed(1);
      return `M${f(x0)} ${f(y0)}C${f(xm)} ${f(y0)} ${f(xm)} ${f(y1)} ${f(x1)} ${f(y1)}L${f(x1)} ${f(y1 + w)}C${f(xm)} ${f(y1 + w)} ${f(xm)} ${f(y0 + w)} ${f(x0)} ${f(y0 + w)}Z`;
    };
    // Drawn: the part outside the selection fades to grey, so only the selection keeps its colour. Parts that
    // touch at both ends and look the same are drawn as one band (no seams, and far fewer paths with routes)
    const draws = [];
    for (const l of links) {
      for (const p of l.parts) {
        p.w = Math.max(0.5, p.h);
        draws.push({ s: l.s, a: l.a, b: l.b, fill: p.dim ? NEUTRAL : colorOf(l.c), dim: p.dim, y0: p.y0, y1: p.y1, h: p.h });
      }
      const x0 = xs[l.s] + nodeW, x1 = xs[l.s + 1];
      l.d = l.parts.map(p => band(x0, p.y0, x1, p.y1, p.w)).join('');
    }
    draws.sort((p, q) => p.s - q.s || p.y0 - q.y0);
    const merged = [];
    for (const d of draws) {
      const m = merged[merged.length - 1];
      if (m && m.s === d.s && m.a === d.a && m.b === d.b && m.fill === d.fill
        && Math.abs(m.y0 + m.h - d.y0) < 0.01 && Math.abs(m.y1 + m.h - d.y1) < 0.01) m.h += d.h;
      else merged.push({ ...d });
    }
    const flowLayer = svgEl('g');
    svg.appendChild(flowLayer);
    for (const m of merged) {
      flowLayer.appendChild(svgEl('path', { d: band(xs[m.s] + nodeW, m.y0, xs[m.s + 1], m.y1, Math.max(0.5, m.h)), fill: m.fill,
        class: m.dim ? 'tarang-chart-flow tarang-chart-flow-dim' : 'tarang-chart-flow' }));
    }

    // Nodes (coloured in the colour stage, neutral elsewhere), with names and values beside them
    const nodes = [];
    cols.forEach((c, s) => {
      for (const k of present(s)) {
        const v = nodeV[s * M + k], lit = anyOwn ? nodeLit[s * M + k] : v, y = nodeY[s * M + k], h = Math.max(1, v * scale);
        const fill = s === cs ? colorOf(k) : NEUTRAL;
        svg.appendChild(svgEl('rect', { x: xs[s], y, width: nodeW, height: h, fill, rx: 2, ...(lit < v ? { opacity: 0.3 } : {}) }));
        // The selected part sits where the selected flows attach: the node's top, or with routes, each lit
        // route's own place (touching ones joined)
        if (lit > 0 && lit < v) {
          const spans = routeList
            ? routeList.filter(r => r.path[s] === k && r.lit > 0).map(r => [r.at[s], r.lit * scale]).sort((p, q) => p[0] - q[0])
            : [[y, lit * scale]];
          const joined = [];
          for (const [a, len] of spans) {
            const last = joined[joined.length - 1];
            if (last && Math.abs(last[0] + last[1] - a) < 0.01) last[1] += len; else joined.push([a, len]);
          }
          for (const [a, len] of joined) svg.appendChild(svgEl('rect', { x: xs[s], y: a, width: nodeW, height: Math.max(1, len), fill, rx: 2 }));
        }
        nodes.push({ s, k, v, lit, y, h, x: xs[s] });
        if (h >= 11) {
          const right = s < S - 1;
          const t = svgEl('text', { x: right ? xs[s] + nodeW + 6 : xs[s] - 6, y: y + h / 2, class: 'tarang-chart-node-label' + (lit < v && !lit ? ' tarang-dim' : ''), 'text-anchor': right ? 'start' : 'end', 'dominant-baseline': 'central' });
          t.textContent = `${nodeName(s, k)} `;
          const num = svgEl('tspan', { class: 'tarang-chart-node-value' });
          num.textContent = fmtValue(v);
          t.appendChild(num);
          svg.appendChild(t);
        }
      }
    });

    // Hover and click: nodes first (they sit on top), then flows
    const outline = svgEl('path', { class: 'tarang-chart-part-hot', visibility: 'hidden' });
    const hit = svgEl('rect', { x: 0, y: 0, width: W, height: H, fill: 'transparent', class: opts.clickToFilter ? 'tarang-chart-pickable' : '' });
    svg.append(outline, hit);
    const find = e => {
      const r = svg.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
      const node = nodes.find(n => px >= n.x - 3 && px <= n.x + nodeW + 3 && py >= n.y - 2 && py <= n.y + Math.max(n.h, 4) + 2);
      if (node) return { node };
      // Which gap between stages px is in, and how far down its curves are there: a band's x runs
      // 1.5t − 1.5t² + t³ of the way across and its y 3t² − 2t³; find t for this x
      const s = xs.findIndex((x, i) => i < S - 1 && px >= x + nodeW && px <= xs[i + 1]);
      if (s < 0) return null;
      const u = (px - xs[s] - nodeW) / (xs[s + 1] - xs[s] - nodeW);
      let lo = 0, hi = 1;
      for (let it = 0; it < 24; it++) { const t = (lo + hi) / 2; if (1.5 * t - 1.5 * t * t + t * t * t < u) lo = t; else hi = t; }
      const t = (lo + hi) / 2, ey = 3 * t * t - 2 * t * t * t;
      for (let j = links.length - 1; j >= 0; j--) {   // the band's edges at this x, along its curve
        const l = links[j];
        if (l.s !== s) continue;
        for (const p of l.parts) {
          const top = p.y0 + (p.y1 - p.y0) * ey;
          if (py >= top - 1 && py <= top + Math.max(1, p.w) + 1) return { link: l };
        }
      }
      return null;
    };
    // Filters a node or link selects: the stage's value (or for "Other", every named value left out)
    const nodeFilter = (s, k) => {
      const id = ids[s];
      if (k < id.order.length) return id.cats.filterText(id.order[k]);
      if (cols[s].type !== 'text') return null;
      const parts = id.order.map(c => id.cats.filterText(c));
      return parts.some(p => p == null) ? null : parts.map(p => '!' + p).join(' | ');
    };
    const wanted = hitAt => (hitAt.node ? { [cols[hitAt.node.s].key]: nodeFilter(hitAt.node.s, hitAt.node.k) }
      : hitAt.link.route ? Object.fromEntries(cols.map((c, s) => [c.key, nodeFilter(s, hitAt.link.route.path[s])]))   // the whole route
      : { [cols[hitAt.link.s].key]: nodeFilter(hitAt.link.s, hitAt.link.a), [cols[hitAt.link.s + 1].key]: nodeFilter(hitAt.link.s + 1, hitAt.link.b) });
    const isPicked = want => {   // the stage filters are exactly these already
      const now = table.getState().filters;
      return keys.every(k => (now[k] || '') === (want[k] || ''));
    };
    hit.addEventListener('click', e => {
      const at = find(e);
      if (!at || !opts.clickToFilter) return;
      const want = wanted(at);
      if (Object.values(want).some(v => v == null)) return;
      const filters = { ...table.getState().filters };
      const clear = isPicked(want);
      for (const k of keys) delete filters[k];   // a click replaces the whole flow selection
      if (!clear) Object.assign(filters, want);
      table.setState({ filters });
    });
    hit.addEventListener('pointermove', e => {
      const at = find(e);
      if (!at) { tip.hidden = true; outline.setAttribute('visibility', 'hidden'); return; }
      tip.replaceChildren();
      if (at.node) {
        const { s, k, v } = at.node;
        outline.setAttribute('d', `M${at.node.x} ${at.node.y}h${nodeW}v${at.node.h}h${-nodeW}Z`);
        const row = htmlEl('div', 'tarang-chart-tip-value');
        row.append(htmlEl('b', null, fmtValue(v)), htmlEl('span', 'tarang-chart-pct', ` ${pct(v / total)}`));
        tip.append(row, htmlEl('div', 'tarang-chart-tip-name', `${cols[s].label}: ${nodeName(s, k)}`));
      } else {
        const l = at.link, r = l.route;
        // a route is outlined all the way along
        outline.setAttribute('d', r ? links.filter(x => x.route === r).map(x => x.d).join('') : l.d);
        const row = htmlEl('div', 'tarang-chart-tip-value'), key = htmlEl('span', 'tarang-chart-tip-key');
        key.style.background = colorOf(l.c);
        row.append(key, htmlEl('b', null, fmtValue(l.v)), htmlEl('span', 'tarang-chart-pct', ` ${pct(l.v / total)}`));
        tip.append(row, htmlEl('div', 'tarang-chart-tip-name', r ? Array.from(r.path, (k, s) => nodeName(s, k)).join(' → ') : `${nodeName(l.s, l.a)} → ${nodeName(l.s + 1, l.b)}`));
        if (!r && cs !== l.s && cs !== l.s + 1) tip.appendChild(htmlEl('div', 'tarang-chart-tip-name', `${cols[cs].label}: ${nodeName(cs, l.c)}`));
      }
      outline.setAttribute('visibility', 'visible');
      if (opts.clickToFilter) {
        const want = wanted(at);
        if (!Object.values(want).some(v => v == null)) {
          tip.appendChild(htmlEl('div', 'tarang-chart-tip-hint', isPicked(want) ? 'Click to show every row again'
            : at.node ? `Click to show only ${nodeName(at.node.s, at.node.k)}` : at.link.route ? 'Click to show only this route' : 'Click to show only this flow'));
        }
      }
      placeTip(e);
    });
    hit.addEventListener('pointerleave', () => { tip.hidden = true; outline.setAttribute('visibility', 'hidden'); });
  }

  // ----- treemap: rectangles sized by the value, drilling down through `stages` -----
  // One level shows at a time: the categories of the stage you're at, each with the next stage's split inside
  // it. Clicking one drills in (All › North › Gadget). With clickToFilter the path *is* the table's filters
  // (=North on region, …), so the other charts follow it and clearing a filter elsewhere climbs back up; without,
  // the chart keeps the path itself. At the last stage a click filters to that category, like a pie slice.
  let tmPath = [], tmPathKey = '';   // the path when clickToFilter is off: a category code per stage
  const TM_MAX_PARENTS = 40, TM_MAX_KIDS = 12, TM_HEAD = 18, TM_GAP = 2;
  function renderTreemap() {
    const model = table.model;
    // Stages, as for the flow chart (with the menu and too few: columns with few values)
    let keys = [];
    for (const k of opts.stages || []) { const c = columnOf(k); if (c && !keys.some(x => columnOf(x) === c)) keys.push(c.key); }
    if (pickers && keys.length < 1) {
      const fit = model.allColumns.filter(c => sliceable(c) && c.type === 'text' && c.data.dict.length <= 40 && axisKind(c) !== 'date');
      const start = columnOf(opts.column);
      for (const c of [...(start ? [start] : []), ...fit]) { if (keys.length >= 3) break; if (!keys.includes(c.key)) keys.push(c.key); }
    }
    if (pickers && keys.join('\u0001') !== (opts.stages || []).join('\u0001')) opts = { ...opts, stages: keys };
    if (keys.join('\u0001') !== tmPathKey) { tmPath = []; tmPathKey = keys.join('\u0001'); }
    const cols = keys.map(columnOf), S = cols.length;
    const valCol = opts.value ? columnOf(opts.value) : null;
    if (pickers) pickers.sync(null, valCol, null);
    titleEl.textContent = opts.title || (S ? cols.map(c => c.label).join(' › ') : 'Treemap');
    const fail = text => { subEl.textContent = ''; message(text); };
    if (!S) return fail('Choose the columns to drill down through (stages).');
    if (opts.value && (!valCol || valCol.type !== 'number')) return fail(`"${opts.value}" isn't a number column, so it can't be summed.`);
    const ids = cols.map(c => stageIdentity(c, valCol));
    const view = table.view;

    // The path: with clickToFilter, read from the filters (an exact "=value" on each stage in turn, not the last)
    let path;
    if (opts.clickToFilter) {
      path = [];
      for (let s = 0; s < S - 1; s++) {
        const f = view.filters.get(cols[s]);
        if (!f) break;
        let hit = -1;
        for (let c = 0; c < ids[s].cats.count; c++) if (ids[s].cats.filterText(c) === f.text) { hit = c; break; }
        if (hit < 0) break;
        path.push(hit);
      }
    } else path = tmPath.slice(0, S - 1);
    const d = path.length;   // the stage shown
    const here = ids[d].cats, below = d + 1 < S ? ids[d + 1].cats : null;
    // Rows: the table's filters (the path's among them), except filters on the stages from here down, which
    // only light / dim (as other charts treat a filter on their own column)
    const lower = new Set(cols.slice(d));
    const ownTests = opts.clickToFilter ? [...view.filters].filter(([c]) => lower.has(c)).map(([, f]) => f.test) : [];
    const tests = opts.filtered ? [...view.filters].filter(([c]) => !(opts.clickToFilter && lower.has(c))).map(([, f]) => f.test) : [];
    if (!opts.clickToFilter) path.forEach((cat, s) => tests.push(i => ids[s].cats.of(i) === cat));
    const hidden = opts.filtered && model.hidden && !view.showHidden ? model.hidden : null;
    const vals = valCol ? valCol.data.values : null;
    const pv = new Float64Array(here.count), pLit = new Float64Array(here.count);
    const kids = new Map();   // parent * below.count + child -> [value, lit]
    let rowCount = 0, negatives = 0, total = 0, litTotal = 0;
    rows: for (let i = 0, n = model.numRows; i < n; i++) {
      if (hidden && hidden[i]) continue;
      for (const t of tests) if (!t(i)) continue rows;
      const w = vals ? vals[i] : 1;
      if (!(w > 0)) { if (w < 0) negatives++; continue; }
      let lit = true;
      for (const t of ownTests) if (!t(i)) { lit = false; break; }
      const a = here.of(i);
      pv[a] += w; if (lit) pLit[a] += w;
      if (below) {
        const k = a * below.count + below.of(i);
        const e = kids.get(k);
        if (e) { e[0] += w; if (lit) e[1] += w; } else kids.set(k, [w, lit ? w : 0]);
      }
      rowCount++; total += w; if (lit) litTotal += w;
    }
    const fmtValue = v => (valCol
      ? (valCol.formatValue ? valCol.formatValue(v) : v.toLocaleString(undefined, { maximumFractionDigits: valCol.decimals }))
      : v.toLocaleString());
    const filteredNote = opts.filtered && (tests.length || hidden) ? ' · following the table\'s filters' : '';
    subEl.textContent = `${rowCount.toLocaleString()} rows${valCol ? ` · ${fmtValue(total)} total` : ''}${filteredNote}`
      + (ownTests.length ? ` · ${fmtValue(litTotal)} (${pct(total ? litTotal / total : 0)}) selected` : '')
      + (negatives ? ` · ${negatives.toLocaleString()} negative values left out` : '');

    // Breadcrumb: All › North › Gadget (each step climbs back to there), then the rectangles
    body.replaceChildren();
    body.classList.remove('tarang-chart-narrow');
    body.classList.add('tarang-chart-tm-body');   // a column: the breadcrumb over the rectangles
    const crumb = htmlEl('div', 'tarang-chart-crumb');
    const step = (label, depth) => {
      const b = htmlEl(depth < d ? 'button' : 'span', depth < d ? 'tarang-chart-crumb-step' : 'tarang-chart-crumb-here', label);
      if (depth < d) { b.type = 'button'; b.title = 'Back up to here'; b.addEventListener('click', () => climb(depth)); }
      crumb.appendChild(b);
    };
    step('All', 0);
    path.forEach((cat, s) => { crumb.appendChild(htmlEl('span', 'tarang-chart-crumb-sep', '›')); step(ids[s].cats.name(cat), s + 1); });
    crumb.appendChild(htmlEl('span', 'tarang-chart-crumb-sep', '·'));
    crumb.appendChild(htmlEl('span', 'tarang-chart-crumb-level', `by ${cols[d].label}${below ? `, split by ${cols[d + 1].label}` : ''}`));
    body.appendChild(crumb);
    if (!total) { const m = htmlEl('div', 'tarang-chart-empty', rowCount ? 'Nothing to show: every value is zero or empty.' : 'No rows match the table\'s filters.'); body.appendChild(m); drawn = []; return; }

    const box = htmlEl('div', 'tarang-chart-tm');
    body.appendChild(box);
    const W = Math.max(120, Math.floor(box.clientWidth || body.clientWidth)), H = Math.max(100, Math.floor(box.clientHeight || body.clientHeight - 26));
    const svg = svgEl('svg', { class: 'tarang-chart-treemap', width: W, height: H, viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': titleEl.textContent });
    box.appendChild(svg);

    // The parents (biggest first; past TM_MAX_PARENTS folded into "Other"), each with its biggest children
    const id = ids[d];
    const colorOf = c => id.colorFor(c);
    coloured = [cols[d]];
    let parents = [];
    for (let c = 0; c < here.count; c++) if (pv[c] > 0) parents.push({ cat: c, v: pv[c], lit: pLit[c] });
    parents.sort((a, b) => b.v - a.v);
    if (parents.length > TM_MAX_PARENTS) {
      const rest = parents.slice(TM_MAX_PARENTS - 1);
      parents = parents.slice(0, TM_MAX_PARENTS - 1);
      parents.push({ cat: -1, other: rest.length, v: rest.reduce((s, p) => s + p.v, 0), lit: rest.reduce((s, p) => s + p.lit, 0) });
    }
    for (const p of parents) {
      p.name = p.cat < 0 ? `Other (${p.other})` : here.name(p.cat);
      p.color = p.cat < 0 ? OTHER : colorOf(p.cat);
      p.kids = [];
      if (!below || p.cat < 0) continue;
      for (let c = 0; c < below.count; c++) {
        const e = kids.get(p.cat * below.count + c);
        if (e && e[0] > 0) p.kids.push({ cat: c, v: e[0], lit: e[1], name: below.name(c) });
      }
      p.kids.sort((a, b) => b.v - a.v);
      if (p.kids.length > TM_MAX_KIDS) {
        const rest = p.kids.slice(TM_MAX_KIDS - 1);
        p.kids = p.kids.slice(0, TM_MAX_KIDS - 1);
        p.kids.push({ cat: -1, other: rest.length, v: rest.reduce((s, k) => s + k.v, 0), lit: rest.reduce((s, k) => s + k.lit, 0), name: `Other (${rest.length})` });
      }
    }
    squarify(parents, 0, 0, W, H);
    const anyOwn = ownTests.length > 0;
    const fit = (text, w) => { const max = Math.floor((w - 8) / 6.6); return max < 2 ? '' : text.length <= max ? text : text.slice(0, max - 1) + '…'; };
    const label = (x, y, text, cls) => { const t = svgEl('text', { x, y, class: cls }); t.textContent = text; svg.appendChild(t); return t; };
    drawn = parents.map(p => ({ name: p.name, value: p.v, share: p.v / total, color: p.color, other: p.cat < 0 }));
    for (const p of parents) {
      const { x, y, w, h } = p.rect;
      const dim = anyOwn && !(p.lit > 0);
      const g = svgEl('g', { class: 'tarang-chart-tm-parent' + (dim ? ' tarang-dim' : '') });
      svg.appendChild(g);
      g.appendChild(svgEl('rect', { x: x + TM_GAP / 2, y: y + TM_GAP / 2, width: Math.max(0, w - TM_GAP), height: Math.max(0, h - TM_GAP), fill: p.color, 'fill-opacity': p.kids.length ? 0.28 : 0.85, rx: 3 }));
      const head = p.kids.length && h > TM_HEAD * 2 && w > 40;
      if (head || !p.kids.length) {
        const t = fit(p.name, w);
        if (t && h >= 16) label(x + 6, y + 13, t, 'tarang-chart-tm-name');
        const vt = fit(fmtValue(p.v), w);
        if (!p.kids.length && vt && h >= 32) label(x + 6, y + 27, vt, 'tarang-chart-tm-value');
      }
      if (p.kids.length) {
        const top = head ? TM_HEAD : TM_GAP;
        squarify(p.kids, x + TM_GAP + 1, y + top, Math.max(0, w - 2 * TM_GAP - 2), Math.max(0, h - top - TM_GAP - 1));
        for (const k of p.kids) {
          const r = k.rect;
          if (r.w < 1 || r.h < 1) continue;
          const kdim = anyOwn && !(k.lit > 0);
          g.appendChild(svgEl('rect', { x: r.x + 0.5, y: r.y + 0.5, width: Math.max(0, r.w - 1), height: Math.max(0, r.h - 1), fill: k.cat < 0 ? OTHER : p.color,
            'fill-opacity': kdim ? 0.25 : 0.85 }));
          const t = fit(k.name, r.w);
          if (t && r.h >= 16) label(r.x + 5, r.y + 13, t, 'tarang-chart-tm-kid');
        }
      }
      p.box = { x, y, w, h };
    }

    // Hover / click
    const hit = svgEl('rect', { x: 0, y: 0, width: W, height: H, fill: 'transparent', class: 'tarang-chart-pickable' });
    const outline = svgEl('rect', { class: 'tarang-chart-part-hot', visibility: 'hidden', fill: 'none' });
    svg.append(outline, hit);
    const find = e => {
      const r = svg.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
      const p = parents.find(q => q.box && px >= q.box.x && px < q.box.x + q.box.w && py >= q.box.y && py < q.box.y + q.box.h);
      if (!p) return null;
      const k = p.kids.find(q => q.rect && px >= q.rect.x && px < q.rect.x + q.rect.w && py >= q.rect.y && py < q.rect.y + q.rect.h);
      return { p, k };
    };
    const canDrill = p => d < S - 1 && p.cat >= 0 && here.filterText(p.cat) != null;
    hit.addEventListener('pointermove', e => {
      const at = find(e);
      if (!at) { tip.hidden = true; outline.setAttribute('visibility', 'hidden'); return; }
      const { p, k } = at, b = k ? k.rect : p.box;
      Object.entries({ x: b.x + 1, y: b.y + 1, width: Math.max(0, b.w - 2), height: Math.max(0, b.h - 2) }).forEach(([a, v]) => outline.setAttribute(a, v));
      outline.setAttribute('visibility', 'visible');
      tip.replaceChildren();
      const row = htmlEl('div', 'tarang-chart-tip-value'), sw = htmlEl('span', 'tarang-chart-tip-key');
      sw.style.background = p.color;
      const it = k || p;
      row.append(sw, htmlEl('b', null, fmtValue(it.v)), htmlEl('span', 'tarang-chart-pct', ` ${pct(it.v / total)}`));
      tip.append(row, htmlEl('div', 'tarang-chart-tip-name', `${cols[d].label}: ${p.name}`));
      if (k) tip.appendChild(htmlEl('div', 'tarang-chart-tip-name', `${cols[d + 1].label}: ${k.name} · ${pct(k.v / p.v)} of ${p.name}`));
      const hint = canDrill(p) ? `Click to drill into ${p.name}` : d === S - 1 && p.cat >= 0 && opts.clickToFilter ? `Click to show only ${p.name}` : '';
      if (hint) tip.appendChild(htmlEl('div', 'tarang-chart-tip-hint', hint + (d > 0 ? ' · right-click to go up' : '')));
      placeTip(e);
    });
    hit.addEventListener('pointerleave', () => { tip.hidden = true; outline.setAttribute('visibility', 'hidden'); });
    hit.addEventListener('click', e => {
      const at = find(e);
      if (!at) return;
      const { p } = at;
      if (canDrill(p)) return drill(d, p.cat);
      // the last stage: a filter control, like a pie slice (click again to clear)
      if (d === S - 1 && p.cat >= 0 && opts.clickToFilter) {
        const ft = here.filterText(p.cat);
        if (ft == null) return;
        const f = { ...table.getState().filters };
        if (f[cols[d].key] === ft) delete f[cols[d].key]; else f[cols[d].key] = ft;
        table.setState({ filters: f });
      }
    });
    hit.addEventListener('contextmenu', e => { if (d > 0) { e.preventDefault(); climb(d - 1); } });

    // Drill into category `cat` of stage `s`; climb back to depth `depth` (0: All)
    function drill(s, cat) {
      if (!opts.clickToFilter) { tmPath = [...path.slice(0, s), cat]; render(); return; }
      const f = { ...table.getState().filters };
      for (let k = s; k < S; k++) delete f[cols[k].key];   // what was picked further down no longer applies
      f[cols[s].key] = here.filterText(cat);
      table.setState({ filters: f });
    }
    function climb(depth) {
      if (!opts.clickToFilter) { tmPath = path.slice(0, depth); render(); return; }
      const f = { ...table.getState().filters };
      for (let k = depth; k < S; k++) delete f[cols[k].key];
      table.setState({ filters: f });
    }
  }

  // Draws the chart, then tells the table (linkColors) which column it colours, for the strips in its cells
  function render() {
    coloured = [];
    drawChart();
    if (table.linkColors) table.linkColors(linkToken, opts.linkColors && table.model ? coloured.filter(c => c && c.type === 'text').map(c => c.key) : []);
  }
  function drawChart() {
    tip.hidden = true;
    hot = -1;
    body.classList.remove('tarang-chart-tm-body');   // the treemap sets it again
    if (!table.model) return;
    if (isSankey()) return renderSankey();
    if (isTreemap()) return renderTreemap();
    if (isSeries()) return renderLine();
    // With pickers and no column chosen yet, start from the first text column
    if (pickers && !columnOf(opts.column)) {
      const all = table.model.allColumns.filter(sliceable);
      const first = all.find(c => c.type === 'text') || all[0];
      if (first) opts = { ...opts, column: first.key };
    }
    const col = columnOf(opts.column);
    const valCol = opts.value ? columnOf(opts.value) : null;
    if (pickers) pickers.sync(col, valCol);
    titleEl.textContent = opts.title || (col ? `${col.label}${valCol ? ` · ${valCol.label}` : ''}` : 'Chart');
    if (!col) { subEl.textContent = ''; return message(opts.column ? `No column "${opts.column}" in the table.` : 'Choose a column to chart.'); }
    if (opts.value && (!valCol || valCol.type !== 'number')) {
      subEl.textContent = '';
      return message(`"${opts.value}" isn't a number column, so it can't be summed.`);
    }
    if (!identity || identity.col !== col || identity.valCol !== valCol) identity = buildIdentity(col, valCol);
    coloured = [col];
    const { cats } = identity;

    // The rows to count: the table's filters (except this column's own, when the pie is the filter control)
    const view = table.view, model = table.model;
    const own = view.filters.get(col);
    const tests = opts.filtered
      ? [...view.filters].filter(([c]) => !(opts.clickToFilter && c === col)).map(([, f]) => f.test) : [];
    const hidden = opts.filtered && model.hidden && !view.showHidden ? model.hidden : null;
    const t = tally(cats, valCol, tests, hidden);
    const passesOwn = c => !own || !opts.clickToFilter || (t.rep[c] >= 0 && own.test(t.rep[c]));

    // Slices in colour order (stable while filters change), then "Other"
    const slices = [];
    for (const c of identity.order) {
      if (t.sums[c] > 0) slices.push({ cat: c, name: cats.name(c), value: t.sums[c], color: identity.colorFor(c), dim: !passesOwn(c) });
    }
    let otherSum = 0, otherCats = [], otherLit = false;
    for (let c = 0; c < cats.count; c++) {
      if (identity.colorOf.has(c) || !(t.sums[c] > 0)) continue;
      otherSum += t.sums[c]; otherCats.push(c);
      if (passesOwn(c)) otherLit = true;
    }
    if (otherSum > 0) slices.push({ cat: -1, name: `Other (${otherCats.length})`, value: otherSum, color: OTHER, other: true, cats: otherCats, dim: !otherLit });
    const total = slices.reduce((s, x) => s + x.value, 0);
    for (const s of slices) s.share = total ? s.value / total : 0;
    drawn = slices;

    const fmtValue = v => (valCol
      ? (valCol.formatValue ? valCol.formatValue(v) : v.toLocaleString(undefined, { maximumFractionDigits: valCol.decimals }))
      : v.toLocaleString());
    const filteredNote = opts.filtered && (tests.length || hidden) ? ' · following the table\'s filters' : '';
    subEl.textContent = valCol
      ? `${fmtValue(total)} total over ${t.rows.toLocaleString()} rows${filteredNote}${t.negatives ? ` · ${t.negatives.toLocaleString()} negative values left out` : ''}`
      : `${t.rows.toLocaleString()} rows${filteredNote}`;
    if (own && opts.clickToFilter) {   // the pie is acting as this column's filter: say how much is picked
      const lit = slices.reduce((sum, s) => sum + (s.dim ? 0 : s.value), 0);
      subEl.textContent += ` · ${fmtValue(lit)} (${pct(total ? lit / total : 0)}) selected`;
    }
    if (!slices.length) return message(t.rows ? 'Nothing to show: every value is zero or empty.' : 'No rows match the table\'s filters.');

    // ----- bars: one row per category, biggest first ("Other" last); each row is its own label and button -----
    if (isBar()) {
      body.classList.remove('tarang-chart-narrow');
      const sorted = slices.slice().sort((a, b) => (a.other ? 1 : 0) - (b.other ? 1 : 0) || b.value - a.value);
      const max = sorted.reduce((m, s) => Math.max(m, s.value), 0);
      const list = htmlEl('div', 'tarang-chart-bars');
      for (const s of sorted) {
        const b = htmlEl('button', 'tarang-chart-bar-row' + (s.dim ? ' tarang-dim' : ''));
        b.type = 'button';
        b.title = clickTitle(s);
        const track = htmlEl('span', 'tarang-chart-bar-track'), bar = htmlEl('span', 'tarang-chart-bar');
        bar.style.width = `${max ? (s.value / max) * 100 : 0}%`;
        bar.style.background = s.color;
        track.appendChild(bar);
        b.append(htmlEl('span', 'tarang-chart-bar-name', s.name), track, htmlEl('span', 'tarang-chart-num', fmtValue(s.value)), htmlEl('span', 'tarang-chart-pct', pct(s.share)));
        b.addEventListener('pointermove', e => showTip(s, e));
        b.addEventListener('pointerleave', () => { tip.hidden = true; });
        b.addEventListener('click', () => pick(s));
        list.appendChild(b);
      }
      body.replaceChildren(list);
      return;
    }

    // ----- legend (also the keyboard / screen-reader way in) -----
    const legend = htmlEl('div', 'tarang-chart-legend');
    const rows = slices.map((s, k) => {
      const b = htmlEl('button', 'tarang-chart-row' + (s.dim ? ' tarang-dim' : ''));
      b.type = 'button';
      const key = htmlEl('span', 'tarang-chart-key');
      key.style.background = s.color;
      b.append(key, htmlEl('span', 'tarang-chart-name', s.name), htmlEl('span', 'tarang-chart-num', fmtValue(s.value)), htmlEl('span', 'tarang-chart-pct', pct(s.share)));
      b.title = clickTitle(s);
      b.addEventListener('pointerenter', () => setHot(k));
      b.addEventListener('pointerleave', () => setHot(-1));
      b.addEventListener('focus', () => setHot(k));
      b.addEventListener('blur', () => setHot(-1));
      b.addEventListener('click', () => pick(s));
      legend.appendChild(b);
      return b;
    });

    // ----- the pie: sized to what the legend leaves -----
    const svg = svgEl('svg', { class: 'tarang-chart-pie', role: 'img', 'aria-label': `${titleEl.textContent}: ${slices.map(s => `${s.name} ${pct(s.share)}`).join(', ')}` });
    body.replaceChildren(svg, legend);
    const narrow = body.clientWidth < 380;
    body.classList.toggle('tarang-chart-narrow', narrow);
    const room = narrow ? Math.min(body.clientWidth, body.clientHeight - legend.offsetHeight - 12)
      : Math.min(body.clientHeight, body.clientWidth - legend.offsetWidth - 20);
    const size = Math.max(90, Math.floor(room));
    svg.setAttribute('width', size); svg.setAttribute('height', size);
    svg.setAttribute('viewBox', `0 0 ${size} ${size}`);
    const cx = size / 2, cy = size / 2, r = size / 2 - 6, inner = opts.donut ? r * 0.6 : 0;

    const paths = [];
    let a0 = -Math.PI / 2;
    slices.forEach((s, k) => {
      const a1 = a0 + s.share * Math.PI * 2, mid = (a0 + a1) / 2;
      const p = svgEl('path', { d: arcPath(cx, cy, r, inner, a0, a1, s.share), fill: s.color, 'fill-rule': 'evenodd', stroke: SURFACE, 'stroke-width': 2, 'stroke-linejoin': 'round' });
      if (s.dim) p.setAttribute('opacity', 0.3);
      s.mid = mid;
      p.addEventListener('pointermove', e => { setHot(k); showTip(s, e); });
      p.addEventListener('pointerleave', () => { setHot(-1); tip.hidden = true; });
      p.addEventListener('click', () => pick(s));
      svg.appendChild(p);
      paths.push(p);
      // The percentage on big enough slices (white on every slot colour; legend has every value anyway)
      if (s.share >= LABEL_MIN_SHARE && !s.dim) {
        const lr = inner ? (r + inner) / 2 : r * 0.64;
        const text = svgEl('text', { x: cx + Math.cos(mid) * lr, y: cy + Math.sin(mid) * lr, class: 'tarang-chart-label', 'text-anchor': 'middle', 'dominant-baseline': 'central' });
        text.textContent = pct(s.share);
        svg.appendChild(text);
      }
      a0 = a1;
    });
    if (opts.donut) {
      const t1 = svgEl('text', { x: cx, y: cy - 8, class: 'tarang-chart-centre', 'text-anchor': 'middle', 'dominant-baseline': 'central' });
      t1.textContent = fmtValue(total);
      const t2 = svgEl('text', { x: cx, y: cy + 12, class: 'tarang-chart-centre-sub', 'text-anchor': 'middle', 'dominant-baseline': 'central' });
      t2.textContent = valCol ? 'total' : 'rows';
      svg.append(t1, t2);
    }

    // Hover / focus: the slice moves out a little, its legend row lights up
    function setHot(k) {
      if (hot === k) return;
      if (hot >= 0) { paths[hot].removeAttribute('transform'); rows[hot].classList.remove('tarang-hot'); }
      hot = k;
      if (k < 0) return;
      const m = slices[k].mid, d = slices.length > 1 ? 5 : 0;
      paths[k].setAttribute('transform', `translate(${(Math.cos(m) * d).toFixed(2)} ${(Math.sin(m) * d).toFixed(2)})`);
      rows[k].classList.add('tarang-hot');
    }
    function showTip(s, e) {
      tip.replaceChildren();
      const v = htmlEl('div', 'tarang-chart-tip-value');
      const key = htmlEl('span', 'tarang-chart-tip-key');
      key.style.background = s.color;
      v.append(key, htmlEl('b', null, fmtValue(s.value)), htmlEl('span', 'tarang-chart-pct', ` ${pct(s.share)}`));
      tip.append(v, htmlEl('div', 'tarang-chart-tip-name', s.name));
      if (opts.clickToFilter && clickText(s) != null) tip.append(htmlEl('div', 'tarang-chart-tip-hint', clickTitle(s)));
      tip.hidden = false;
      const box = root.getBoundingClientRect();
      let x = e.clientX - box.left + 14, y = e.clientY - box.top + 14;
      if (x + tip.offsetWidth > box.width - 4) x = e.clientX - box.left - tip.offsetWidth - 14;
      if (y + tip.offsetHeight > box.height - 4) y = e.clientY - box.top - tip.offsetHeight - 14;
      tip.style.left = `${Math.max(4, x)}px`; tip.style.top = `${Math.max(4, y)}px`;
    }
  }

  // The filter a slice sets: its value, or for "Other" every named category left out (text columns only)
  function clickText(s) {
    const { cats, col, order } = identity;
    if (!s.other) return cats.filterText(s.cat);
    if (col.type !== 'text') return null;
    const parts = order.map(c => cats.filterText(c));
    return parts.some(p => p == null) ? null : parts.map(p => '!' + p).join(' | ');   // "!=a | !=b": neither
  }
  function current() {
    const own = identity && table.view.filters.get(identity.col);
    return own ? own.text : '';
  }
  function clickTitle(s) {
    const text = clickText(s);
    if (!opts.clickToFilter || text == null) return '';
    return current() === text ? 'Click to show every row again' : 'Click to show only these rows';
  }
  function pick(s) {
    if (!opts.clickToFilter) return;
    const text = clickText(s);
    if (text == null) return;
    table.setFilter(identity.col.key, current() === text ? '' : text);
  }

  // Redraw when the table's data, filters or size change (at most once per frame)
  let pending = 0;
  const schedule = () => { if (!pending) pending = requestAnimationFrame(() => { pending = 0; render(); }); };
  const off = table.onChange(({ type }) => {
    if (type === 'load') identity = null;
    if (['load', 'filter', 'state', 'columns'].includes(type) || (type === 'colors' && opts.linkColors)) schedule();
  });
  const resize = new ResizeObserver(schedule);
  resize.observe(body);
  render();

  return {
    update: render,
    setOptions(changes) { opts = { ...opts, ...changes }; identity = null; render(); },
    get options() { return { ...opts }; },   // the current options, including what the pickers chose
    get slices() { return drawn.map(s => ({ name: s.name, value: s.value, share: s.share, color: s.color, other: !!s.other, dimmed: !!s.dim })); },
    destroy() {
      off(); resize.disconnect(); cancelAnimationFrame(pending); if (pickers) pickers.close(); root.remove();
      if (table.linkColors) table.linkColors(linkToken, []);   // its strips leave the table too
    },
  };
}

// One slice: a wedge from angle a0 to a1 (radians), or a ring segment when inner > 0
function arcPath(cx, cy, r, inner, a0, a1, share) {
  const pt = (rad, a) => `${(cx + Math.cos(a) * rad).toFixed(2)} ${(cy + Math.sin(a) * rad).toFixed(2)}`;
  if (share >= 0.9999) {   // the whole circle: two half arcs
    const ring = `M ${pt(r, 0)} A ${r} ${r} 0 1 1 ${pt(r, Math.PI)} A ${r} ${r} 0 1 1 ${pt(r, 0)} Z`;
    return inner ? `${ring} M ${pt(inner, 0)} A ${inner} ${inner} 0 1 0 ${pt(inner, Math.PI)} A ${inner} ${inner} 0 1 0 ${pt(inner, 0)} Z` : ring;
  }
  const large = a1 - a0 > Math.PI ? 1 : 0;
  if (!inner) return `M ${cx} ${cy} L ${pt(r, a0)} A ${r} ${r} 0 ${large} 1 ${pt(r, a1)} Z`;
  return `M ${pt(r, a0)} A ${r} ${r} 0 ${large} 1 ${pt(r, a1)} L ${pt(inner, a1)} A ${inner} ${inner} 0 ${large} 0 ${pt(inner, a0)} Z`;
}

window.TarangChart = { chart: pie, pie };   // the same function: `chart` reads better for bars and lines
})();
