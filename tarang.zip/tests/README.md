# Tests

Checks for everything in `tarang/` (tarang-table, tarang-diff, tarang-chart, tarang-tree and their demo
pages) and `openlayers-mvp/` (region-map, the map + table link, the demo pages).

## Running them

From the command line (headless Edge or Chrome):

```powershell
.\tests\run.ps1                    # every suite, each in a fresh browser; exit code 1 if anything fails
.\tests\run.ps1 -Only tree,map     # some groups: table, chart, tree, map (or words from a suite's name)
.\tests\run.ps1 -Page tests\tree-filters.test.html        # one page
.\tests\run.ps1 -Page "tarang\tree.html?test"     # one demo page
.\tests\run.ps1 -ShowInfo          # also the timings and notes (e.g. 1M rows sorted in …)
```

In a browser: open `tests/index.html`. It runs the suites one after another and lists the results; any suite
can also be opened on its own (its results show in the corner). With many suites in one browser the map
pages can slow down (they hold WebGL contexts, and the big suites build a million rows), so if one times out
there, run it with `?only=map` or from the command line, where each suite gets its own browser.

The map suites load OpenLayers from a CDN, so they need the network.

## What's where

| File | What it checks |
|---|---|
| `table.test.html` | tarang-table: CSV reading, filters, sorting, groups, totals, state, the address, selection, events, CSV out, 1M rows |
| `diff.test.html` | tarang-diff: same / changed / added / removed, tolerances, renames, deltas, errors |
| `example.test.js` | `tarang/example.html?test`: the orders table and all its charts (pie, bars, lines, columns, flow, treemap) |
| `chart-treemap.test.html` | the treemap: layout, drilling, the breadcrumb, filters |
| `tree-*.test.html` | tarang-tree: the model, search, expanding, sorting, missing values, filters, multi-select, columns, the header box, systems, the short format, pins and comments, diff captures, leaf to root |
| `tree-page.test.js` | `tarang/tree.html?test`: the Frames table, its tabs and charts, jumps, the address, tag frames, shared colours |
| `map-*.test.html` | region-map: dropped CSVs, column mapping, flat region lists |
| `map-page.test.js` | `openlayers-mvp/index.html?test`: the map and its table, both ways |
| `map-two.test.js` | `openlayers-mvp/two-maps.html?test`: two independent maps |

## Writing one

A test page loads `harness.js` and calls `TT.run`:

```html
<script src="harness.js"></script>
<script src="../tarang/tarang-tree.js"></script>
<script>
TT.run('Tree: something', async t => {
  const tree = TarangTree.create(el, { data });
  t.check('a name', got, want);       // compared as JSON
  t.ok('drawn', canvas.width > 0);
  t.info('took ' + ms + ' ms');       // a note, never a failure
  await t.wait(100); await t.frame(); await t.until(() => ready);
});
</script>
```

Errors the page throws count as failures. Add the page to `SUITES` in `index.html`. A demo page runs its checks
when opened with `?test`: see the one-line hook at the bottom of `example.html`, `tree.html` or `index.html`.
