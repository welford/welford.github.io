/* tall-table.js: a reusable, virtualised table for tall CSV data (hundreds of thousands of rows).
 *
 *   const table = await TallTable.create(containerElement, {
 *     renderer: 'canvas',             // 'canvas' (default; no dependencies), or one you register with TallTable.registerRenderer
 *     source: { url: 'data.csv' },    // { csv: text } | { url } | { file } | { sample: { rows, cols, seed } } | () => text
 *                                     //   | { data }: columns parsed already (what TallTable.parseCsv returns)
 *     transform: { columns, rowFilter, onCellClick },   // what to show and what clicks do (see below)
 *     title: 'My data',               // panel heading
 *     panel: true,                    // show the side panel
 *     fileLoading: true,              // "Load CSV…" button + dropping a CSV file onto the table; false for neither,
 *                                     //   or { button: true, drop: false } to choose
 *     rowNumbers: true,               // false: a slim strip instead of the row-number column
 *     headers: true,                  // false: no column header row in the table (edit from outside instead)
 *     totals: false,                  // 'top' | 'bottom': a frozen totals row over the rows currently shown
 *     groupBy: 'status',              // group rows by a column (also transform.groupBy); groups start collapsed
 *     urlState: 'orders',             // off by default: keep sort, filters and grouping in the page URL
 *                                     //   (?orders.sort=-price&orders.filter.status==shipped&orders.group=region)
 *                                     //   and restore them when the page is opened with those parameters
 *     headerControls: { sort: true, filter: true, align: true, columns: true, resize: true },
 *                                     // switch individual header gestures off to leave them to an outside UI
 *   });
 *   table.load(source, { transform })  table.setTransform(t)  table.setRenderer(name)  table.destroy()
 *   table.setPanel(bool)  table.setRowNumbers(bool)  table.setHeatmap(bool)  table.setShowHidden(bool)
 *   table.downloadCsv({ rows: 'view' | 'all' | 'selected', columns: 'all' | 'shown', filename })   table.toCsv({ … }) -> text
 *   table.selectedRows   table.selectRows([dataRow, …])   table.clearRowSelection()   table.copySelection()
 *   table.scrollToRow(dataRow) -> Promise<bool>   bring a row into view (opening its group); false if filters hide it
 *   table.hoveredRow               the data row under the pointer, or -1 (onChange 'hover' when it changes)
 *   table.model  table.view  table.renderer  table.panelVisible
 *   table.redraw()                  repaint, after something your render / draw callbacks read has changed
 *   table.setTotals('top' | 'bottom' | false)   table.setTotal(key, 'sum' | 'avg' | … | fn | null | 'default')
 *   table.setGroupBy(key | null)   table.groupBy   table.groups -> [{ name, count, open }]
 *   table.setGroupOpen(name, bool)   table.setAllGroupsOpen(bool)
 *   table.getState() -> { sort: { key, dir } | null, filters: { key: text }, groupBy: key | null }
 *   table.setState(state) -> [skipped]   applies the parts given (e.g. saved in localStorage); parts that don't
 *                                        fit the data (unknown column, unreadable filter) are skipped and listed
 *
 * Header UI outside the table (each column has a stable `key`; labels work too):
 *   table.columns  -> [{ key, label, type, source, computed, visible, sort, filter, align, width, total, totalValue }]
 *   table.onChange(({ type }) => …)   fires on any change made in the table, by the API or by an editor
 *                                     ('load', 'filter', 'sort', 'group', 'state', 'columns', 'selection', 'hover', …)
 *   table.setFilter(key, text) -> error | null   table.clearFilters()   table.setSort(key, 1 | -1 | 0)
 *   table.setColumnVisible(key, bool)   table.moveColumnTo(key, index)   table.setAlign(key, 'left' | 'center' | 'right')
 *   table.setWidth(key, px | null)   table.suggestValues(key, query)   table.resetColumns()
 *   table.setHeaders(bool)   table.setHeaderControls({ sort, filter, align, columns, resize })   table.openOptionsMenu(x, y)
 *   TallTable.columnEditor(table, element, { parts: ['visible', 'order', 'sort', 'filter', 'align', 'width'] })
 *     a ready-made HTML column list (show / hide, reorder, sort, filter with suggestions, align, width)
 *   TallTable.headerBar(table, element, { optionsButton: true, hidden: false })
 *     the minimal version: one button per column ([order_id ▾] [date ▾] …) that opens the column's popup
 *   table.openColumnMenu(key, x, y)   opens a column's filter / sort / align popup from your own UI
 *
 * Clicking a column header cycles its sort (▲ → ▼ → off); double-clicking, Ctrl/⌘+clicking or right-clicking
 * opens its filter, sort & align box (text columns list their values, closest matches first, to click on;
 * "|" means either / or, e.g. "=North | =South" or "<10 | >100", and a suggestion's + adds another value).
 * Drag a header sideways to move the column; drag its right edge to resize it (double-click the edge to refit it).
 * Click a row number to select the whole row; Shift+click or drag down the row numbers for a range,
 * Ctrl/⌘+click to add or remove rows, Esc to clear. Selected rows can be downloaded as CSV.
 * Ctrl/⌘+C copies the selected rows as CSV (header + shown columns), or else the selected cell's value.
 * The top-left corner cell ("☰ Options", or just ☰ without row numbers) opens a menu with these view
 * options (panel, row numbers, heatmap, totals row, hidden rows, renderer) and the column chooser (left- or right-click).
 * The totals row (off by default) sums number columns over the rows shown, so it follows filters; click a
 * total to choose sum / average / min / max / count / distinct / none for that column.
 * Grouping (the column box's "Group by this", or groupBy): one header line per distinct value with the
 * group's subtotals (the same kind of total as the totals row); click it to open / close the group.
 * Groups are in name order; sorted by a number column, groups go by their subtotal for it and the rows
 * inside each group by their value. Filters apply before grouping.
 *
 * Transform (every part optional; without one, every column and row is shown):
 *   columns: [
 *     'signal_01',                                        // a source column by header name
 *     { source: 'count_03', label: 'Count' },             // rename
 *     { label: 'diff', compute: r => r.a - r.b, decimals: 2 },   // computed column (number or text)
 *     { source: 'call_08', onClick: cell => … },          // click handler for this column only
 *     { source: 'status', render: cell => ({ text, color, background, bold, italic, strike, button }) },
 *                                                         // style each cell yourself (or return just a string);
 *                                                         //   `button: 'Label'` (or { label, color, background })
 *                                                         //   draws a button: onClick then gets cell.button = 'Label'
 *     { label: 'actions', render: ({ row }) => ({ button: row.done ? 'Undo' : 'Done' }), onClick },
 *                                                         // no source / compute: a column just for the callbacks
 *     { source: 'level', draw: (ctx, { x, y, w, h }, cell) => … },   // draw the cell on the canvas yourself
 *     { source: 'bytes', format: v => formatBytes(v) },  // how values read everywhere they are shown (cells,
 *                                                         //   totals, group headers, hover); sorting, filters and
 *                                                         //   CSV keep the value
 *     { source: 'size', renderGroup: g => … },            // this column's cell on group header lines: gets
 *                                                         //   { name, value, count, open, subtotal, subtotalText, rows }
 *                                                         //   and returns text | { text, color, background, bold, italic }
 *     { source: 'signal_02', heat: false },               // no heatmap colouring
 *     { source: 'signal_05', heat: { center: 0 } },       // heatmap options: see "Heatmap colouring" below
 *     { source: 'base_04', align: 'center' },             // 'left' | 'center' | 'right' (default: numbers right, text left)
 *     { source: 'name', width: 200 },                     // starting width in px (default: fitted to the content)
 *     { source: 'notes', visible: false },                // in the column chooser, but hidden at first
 *     { source: 'rating', total: 'avg' },                 // totals row: 'sum' (numbers' default) | 'avg' | 'min' |
 *                                                         //   'max' | 'count' | 'distinct' | false |
 *                                                         //   ({ values, rows }) => number | string
 *   ],
 *   total: 'count',                 // default total for every column (each column can override)
 *   heat: { clip: [5, 95] },        // default heat options for every column (each column can override)
 *   align: { text: 'center' },      // default alignment: one value for all columns, or { number, text }
 *   rowFilter: (r, i) => boolean,   // rows returning false start hidden; the panel can show them again
 *   onCellClick: cell => …,         // for every column without its own onClick
 * `r` reads the current source row by header name (numbers, strings, null for empty); it is reused, don't keep it.
 * render / draw get { column, value, display, rowIndex, row }; they run for each cell on screen at every repaint,
 * so keep them quick. Sorting, filtering, totals and CSV use the column's value, not what render shows.
 * Click handlers get { column, columnIndex, source, value, display, rowIndex, row, shown, button } where `row` is the
 * whole source row as a plain object. Return a string (shown as HTML) or an object (shown as JSON) to display
 * it under "Click result".
 *
 * Data flow: CSV text -> parseCsv() -> source columns -> buildModel(transform) -> display columns
 *            -> view (filters, hidden rows, sort) -> the renderer draws only the visible slice.
 */
(function () {
'use strict';


const fmt = n => n.toLocaleString();
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const ms = t => (t < 1000 ? `${Math.round(t)} ms` : `${(t / 1000).toFixed(2)} s`);
// Let the browser paint (e.g. a "Loading…" overlay) before heavy work. requestAnimationFrame does not fire
// in background tabs, so a timeout guarantees we continue anyway.
const nextFrame = () => new Promise(r => { requestAnimationFrame(() => setTimeout(r, 0)); setTimeout(r, 100); });

// ===========================================================================
// Sample data, produced as CSV text
// ===========================================================================
function mulberry32(a) {
  return () => {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function csvEscape(s) {
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

// Mixed columns repeating: signal (2-dp float), signal, count (int), base_/call_ (text categories).
// The text is written as bytes into one buffer and decoded once: building a 50 MB string from millions
// of small strings (concatenation + join) was ~70% of the time.
function generateCsv(numRows = 300_000, numCols = 40, seed = 12345) {
  const rand = mulberry32(seed);
  const CAT_SETS = [{ prefix: 'base_', cats: ['A', 'C', 'G', 'T', 'N'] }, { prefix: 'call_', cats: ['pass', 'low', 'fail', 'n/a'] }];
  const KINDS = ['float', 'float', 'int', 'cat'];
  const cols = [];
  for (let c = 0; c < numCols; c++) {
    const kind = KINDS[c % KINDS.length];
    const n = String(c + 1).padStart(2, '0');
    if (kind === 'cat') {
      const set = CAT_SETS[(c >> 2) % CAT_SETS.length];
      const v = new Uint8Array(numRows);
      let k = 0;
      for (let y = 0; y < numRows; y++) { if (rand() < 0.08) k = (rand() * set.cats.length) | 0; v[y] = k; }
      cols.push({ name: set.prefix + n, kind, v, bytes: set.cats.map(s => new TextEncoder().encode(csvEscape(s))) });
    } else {
      const v = new Float32Array(numRows);
      const period = 500 + rand() * 5000, phase = rand() * Math.PI * 2;
      let walk = 0;
      for (let y = 0; y < numRows; y++) {
        walk = (walk + (rand() - 0.5) * 0.2) * 0.995;
        let x = Math.sin((y / period) * 2 * Math.PI + phase) + walk + (rand() - 0.5) * 0.3;
        if (kind === 'int') x = Math.max(0, Math.round((x + 2) * 50));
        v[y] = x;
      }
      cols.push({ name: (kind === 'int' ? 'count_' : 'signal_') + n, kind, v });
    }
  }

  const header = new TextEncoder().encode(cols.map(c => csvEscape(c.name)).join(',') + '\n');
  let buf = new Uint8Array(header.length + numRows * (numCols * 7 + 1));
  buf.set(header);
  let pos = header.length;
  const digits = new Uint8Array(20);
  const writeUint = n => {   // non-negative integer
    let k = 0;
    do { digits[k++] = 48 + (n % 10); n = Math.floor(n / 10); } while (n > 0);
    while (k) buf[pos++] = digits[--k];
  };
  for (let y = 0; y < numRows; y++) {
    if (pos + numCols * 24 > buf.length) {   // grow if the estimate was short
      const bigger = new Uint8Array(buf.length * 2);
      bigger.set(buf);
      buf = bigger;
    }
    for (let c = 0; c < cols.length; c++) {
      if (c) buf[pos++] = 44;   // ,
      const col = cols[c];
      if (col.kind === 'cat') {
        const b = col.bytes[col.v[y]];
        for (let i = 0; i < b.length; i++) buf[pos++] = b[i];
      } else if (col.kind === 'int') {
        writeUint(col.v[y]);
      } else {                  // 2 decimals, same text as toFixed(2)
        let n = Math.round(col.v[y] * 100);
        if (n < 0) { buf[pos++] = 45; n = -n; }
        const whole = Math.floor(n / 100), frac = n - whole * 100;
        writeUint(whole);
        buf[pos++] = 46;        // .
        buf[pos++] = 48 + Math.floor(frac / 10);
        buf[pos++] = 48 + (frac % 10);
      }
    }
    buf[pos++] = 10;            // \n
  }
  return new TextDecoder().decode(buf.subarray(0, pos));
}

// ===========================================================================
// CSV parsing into typed columns
// ===========================================================================
const POW10 = Array.from({ length: 16 }, (_, k) => 10 ** k);

// Each column starts as numeric (Float64Array, NaN = missing). The first non-numeric value demotes it
// to text, stored as dictionary codes (Uint32Array) into a list of distinct strings ('' is code 0).
function parseCsv(text) {
  const t0 = performance.now();
  const len = text.length;
  let est = 1;
  for (let p = text.indexOf('\n'); p !== -1; p = text.indexOf('\n', p + 1)) est++;

  const headers = [];
  let cols = null;
  let row = -1, col = 0, i = 0;

  function newCol(name) {
    const nums = new Float64Array(est);
    nums.fill(NaN);
    return { name, type: 'number', nums, codes: null, dict: null, dictArr: null, decimals: 0, decHist: new Uint32Array(16) };
  }
  function demote(st, upTo) {
    st.type = 'text';
    st.codes = new Uint32Array(est);
    st.dict = new Map([['', 0]]);
    st.dictArr = [''];
    for (let r = 0; r < upTo; r++) {
      const n = st.nums[r];
      const s = n === n ? (st.decimals ? n.toFixed(st.decimals) : String(n)) : '';
      let code = st.dict.get(s);
      if (code === undefined) { code = st.dictArr.length; st.dict.set(s, code); st.dictArr.push(s); }
      st.codes[r] = code;
    }
    st.nums = null;
  }
  function store(st, r, s) {
    if (st.type === 'number') {
      if (s === '') return;
      const n = +s;
      if (n === n && n !== Infinity && n !== -Infinity) {
        st.nums[r] = n;
        const d = s.indexOf('.');
        const dd = d >= 0 && s.indexOf('e') < 0 && s.indexOf('E') < 0 ? Math.min(15, s.length - d - 1) : 0;
        st.decHist[dd]++;
        if (dd > st.decimals) st.decimals = Math.min(6, dd);
        return;
      }
      demote(st, r);
    }
    let code = st.dict.get(s);
    if (code === undefined) { code = st.dictArr.length; st.dict.set(s, code); st.dictArr.push(s); }
    st.codes[r] = code;
  }
  // Header names made unique and non-empty
  function headerColumns() {
    const seen = new Map();
    return headers.map((h, k) => {
      let name = h || `col_${k + 1}`;
      const dup = seen.get(name) || 0;
      seen.set(name, dup + 1);
      if (dup) name = `${name}_${dup + 1}`;
      return newCol(name);
    });
  }

  while (i < len) {
    // Skip blank lines
    if (col === 0) {
      const c0 = text.charCodeAt(i);
      if (c0 === 10 || c0 === 13) { i++; continue; }
    }
    let field = null;
    const st = row >= 0 && col < cols.length ? cols[col] : null;
    if (st && st.type === 'number') {
      // Fast path: a plain decimal number read straight from the character codes, no substring.
      // mantissa / 10^decimals is exactly what parseFloat gives for up to 15 significant digits.
      let j = i, neg = false, mant = 0, digits = 0, dec = -1, c = text.charCodeAt(j);
      if (c === 45) { neg = true; c = text.charCodeAt(++j); }
      for (; j < len; c = text.charCodeAt(++j)) {
        if (c >= 48 && c <= 57) { mant = mant * 10 + (c - 48); digits++; if (dec >= 0) dec++; }
        else if (c === 46 && dec < 0) dec = 0;
        else break;
      }
      if (digits > 0 && digits <= 15 && (j >= len || c === 44 || c === 10 || c === 13)) {
        const v = dec > 0 ? mant / POW10[dec] : mant;
        st.nums[row] = neg ? -v : v;
        st.decHist[dec > 0 ? dec : 0]++;
        if (dec > st.decimals) st.decimals = Math.min(6, dec);
        i = j;
        field = undefined;   // stored already
      }
    }
    if (field === undefined) {
      // handled by the fast path
    } else if (text.charCodeAt(i) === 34) {           // quoted field, "" is an escaped quote
      let start = i + 1, out = '';
      for (;;) {
        const q = text.indexOf('"', start);
        if (q < 0) { out += text.slice(start); i = len; break; }
        if (text.charCodeAt(q + 1) === 34) { out += text.slice(start, q + 1); start = q + 2; continue; }
        out += text.slice(start, q); i = q + 1; break;
      }
      field = out;
      while (i < len) { const c = text.charCodeAt(i); if (c === 44 || c === 10 || c === 13) break; i++; }
    } else {
      let j = i;
      while (j < len) { const c = text.charCodeAt(j); if (c === 44 || c === 10 || c === 13) break; j++; }
      field = text.slice(i, j);
      i = j;
    }

    if (field === undefined) { /* fast path stored it */ }
    else if (row < 0) headers.push(field.trim());
    else if (col < cols.length) store(cols[col], row, field);

    const c = text.charCodeAt(i);
    if (c === 44) { col++; i++; if (i >= len) { row++; } continue; }
    if (c === 13) i++;
    if (text.charCodeAt(i) === 10) i++;
    if (row < 0) cols = headerColumns();
    row++;
    col = 0;
  }
  if (!cols && headers.length) { cols = headerColumns(); row = 0; }
  if (!cols) throw new Error('The CSV is empty.');

  const rowCount = Math.max(0, row);
  const columns = cols.map(st => (st.type === 'number'
    ? (s => numberData(st.name, st.nums.subarray(0, rowCount), s.decimals, s.trim))(decimalsStyle(st.decHist, st.decimals))
    : textData(st.name, st.codes.subarray(0, rowCount), st.dictArr)));
  return { columns, rowCount, ms: performance.now() - t0 };
}

// How to display a number column, from the decimal places seen in the file:
//   every value written with the same number of decimals (e.g. 1.00, 0.54)  -> that fixed format
//   a mix (7.6, 189.726, 5.86999988555908)                                   -> up to 6 decimals, trailing zeros dropped
function decimalsStyle(hist, maxDecimals) {
  let kinds = 0;
  for (const n of hist) if (n) kinds++;
  return { decimals: maxDecimals, trim: kinds > 1 && maxDecimals > 0 };
}

function numberData(name, values, decimals, trim = false) {
  let min = Infinity, max = -Infinity, sum = 0, n = 0;
  for (let i = 0; i < values.length; i++) {
    const v = values[i];
    if (v === v) { if (v < min) min = v; if (v > max) max = v; sum += v; n++; }
  }
  return { name, type: 'number', values, decimals, trim, min, max, mean: n ? sum / n : NaN, count: n };
}

function textData(name, codes, dict) {
  return { name, type: 'text', codes, dict };
}

const rawValue = (d, i) => (d.type === 'number' ? (d.values[i] === d.values[i] ? d.values[i] : null) : d.dict[d.codes[i]]);

// ===========================================================================
// Transform: source columns -> display columns, initially hidden rows, click callbacks
// ===========================================================================
// ---------------------------------------------------------------------------
// Heatmap colouring
// ---------------------------------------------------------------------------
// Per column (or for the whole table via transform.heat), `heat` can be:
//   true / omitted   defaults: numbers on a sequential ramp over the 2nd–98th percentile; text with
//                    up to 12 distinct values gets palette colours (in alphabetical order); otherwise none
//   false            no colour
//   { clip: [lo, hi] }       numbers: percentile range of the scale (default [2, 98]); clip: false = min–max
//   { domain: [min, max] }   numbers: fixed range (overrides clip)
//   { center: 0 }            numbers: diverging scale around this value (blue below, red above)
//   { colors: [...] }        numbers: your own ramp, CSS colours evenly spaced (or [position 0–1, colour] pairs)
//   { colors: { value: colour }, others }   text: colour per value; `others` for the rest (null = none)
//   (value, rowIndex) => colour | null      any column: full control
// Values outside the range take the end colours; the text colour is picked from the background brightness.
const DEFAULT_CLIP = [2, 98];
const SEQUENTIAL = [[0, '#212e54'], [0.35, '#246e8c'], [0.7, '#46aa78'], [1, '#ebdc5a']];
const DIVERGING = ['#3b7dd8', '#262b35', '#d8553b'];
const CAT_COLORS = ['#3f6fa8', '#b8892d', '#b0464b', '#3f8f5a', '#7a5ca8', '#2f8f8f', '#a85c8a', '#8a7a3f', '#5c6f8a', '#8f4f2f', '#4f8f2f', '#6a6a6a'];

// Any CSS colour -> [r, g, b], using the browser's own parser
let colorCtx = null;
const rgbCache = new Map();
function parseColor(c) {
  if (rgbCache.has(c)) return rgbCache.get(c);
  colorCtx ||= document.createElement('canvas').getContext('2d');
  colorCtx.fillStyle = '#000';
  colorCtx.fillStyle = c;
  const s = colorCtx.fillStyle;
  const rgb = s[0] === '#'
    ? [parseInt(s.slice(1, 3), 16), parseInt(s.slice(3, 5), 16), parseInt(s.slice(5, 7), 16)]
    : s.match(/[\d.]+/g).slice(0, 3).map(Number);
  rgbCache.set(c, rgb);
  return rgb;
}
const textOn = rgb => (0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2] > 150 ? '#111' : '#eef');
const pairCache = new Map();
function colorPair(c) {   // [background, readable text colour]
  let p = pairCache.get(c);
  if (!p) { p = [c, textOn(parseColor(c))]; pairCache.set(c, p); }
  return p;
}

// 256 [background, text] pairs interpolated along colour stops
function rampLut(stops) {
  const pts = stops.map((s, k) => (Array.isArray(s) ? [s[0], parseColor(s[1])] : [k / Math.max(1, stops.length - 1), parseColor(s)]));
  return Array.from({ length: 256 }, (_, i) => {
    const t = i / 255;
    let k = 1; while (k < pts.length - 1 && t > pts[k][0]) k++;
    const [t0, c0] = pts[k - 1], [t1, c1] = pts[Math.min(k, pts.length - 1)];
    const f = t1 > t0 ? Math.min(1, Math.max(0, (t - t0) / (t1 - t0))) : 0;
    const rgb = c0.map((c, j) => Math.round(c + (c1[j] - c) * f));
    return [`rgb(${rgb.join(',')})`, textOn(rgb)];
  });
}
const lutCache = new Map();
const lutFor = stops => { const key = JSON.stringify(stops); if (!lutCache.has(key)) lutCache.set(key, rampLut(stops)); return lutCache.get(key); };

// Approximate percentiles from an even sample (exact enough for a colour scale, and fast)
function percentiles(values, [pLo, pHi]) {
  const n = values.length, step = Math.max(1, Math.floor(n / 20000)), sample = [];
  for (let i = 0; i < n; i += step) if (values[i] === values[i]) sample.push(values[i]);
  if (!sample.length) return [0, 1];
  const s = Float64Array.from(sample).sort();
  const at = p => s[Math.min(s.length - 1, Math.max(0, Math.round((p / 100) * (s.length - 1))))];
  return [at(pLo), at(pHi)];
}

// Build colors(i) -> [bg, fg] | null and a short description of the scale, for one column
function makeHeat(col, h) {
  const data = col.data;
  if (typeof h === 'function') {
    return { colors: i => { const c = h(col.raw(i), i); return c ? colorPair(c) : null; }, describe: 'custom function' };
  }
  const o = h === true || h == null ? {} : h;
  if (data.type === 'number') {
    const vals = data.values;
    let lo, hi, how;
    if (o.domain) { [lo, hi] = o.domain; how = 'fixed range'; }
    else {
      const clip = o.clip === undefined ? DEFAULT_CLIP : o.clip;
      const nth = n => n + (n % 10 === 1 && n % 100 !== 11 ? 'st' : n % 10 === 2 && n % 100 !== 12 ? 'nd' : n % 10 === 3 && n % 100 !== 13 ? 'rd' : 'th');
      if (clip) { [lo, hi] = percentiles(vals, clip); how = `${nth(clip[0])}–${nth(clip[1])} percentile`; }
      else { lo = data.min; hi = data.max; how = 'min–max'; }
    }
    let lut = lutFor(o.colors || SEQUENTIAL);
    if (o.center != null) {   // symmetric around the centre so equal distances get equal intensity
      const r = Math.max(Math.abs(lo - o.center), Math.abs(hi - o.center)) || 1;
      lo = o.center - r; hi = o.center + r;
      lut = lutFor(o.colors || DIVERGING);
      how += `, centred on ${o.center}`;
    }
    const span = hi - lo || 1;
    const f = v => (col.formatValue ? col.formatValue(v) : col.decimals ? v.toFixed(col.decimals) : String(Math.round(v * 100) / 100));
    return {
      colors: i => {
        const v = vals[i];
        if (v !== v) return null;
        const t = (v - lo) / span;
        return lut[t <= 0 ? 0 : t >= 1 ? 255 : Math.round(t * 255)];
      },
      describe: `${f(lo)} … ${f(hi)} (${how})`,
    };
  }
  // Text: explicit colours per value, then `others`, then the default palette (≤ 12 distinct values)
  const dict = data.dict, codes = data.codes;
  const sorted = dict.slice(1).sort();
  const usePalette = dict.length - 1 <= CAT_COLORS.length;
  const byCode = dict.map(s => {
    if (s === '') return null;
    if (o.colors && Object.prototype.hasOwnProperty.call(o.colors, s)) return o.colors[s] ? colorPair(o.colors[s]) : null;
    if ('others' in o) return o.others ? colorPair(o.others) : null;
    return usePalette ? colorPair(CAT_COLORS[sorted.indexOf(s)]) : null;
  });
  const any = byCode.some(Boolean);
  return {
    colors: i => byCode[codes[i]],
    describe: !any ? 'none (too many distinct values)' : o.colors ? 'colours from config' : 'palette by value',
  };
}

// A reusable object whose properties read the current row; used for transform callbacks
function makeRowView(src) {
  const rv = { $i: 0 };
  for (const d of src.columns) {
    Object.defineProperty(rv, d.name, { enumerable: true, get() { return rawValue(d, this.$i); } });
  }
  return rv;
}

const ALIGNS = ['left', 'center', 'right'];
// Aggregates the totals row can show, per column type
const TOTALS = { number: ['sum', 'avg', 'min', 'max', 'count', 'distinct'], text: ['count', 'distinct'] };
const TOTAL_LABELS = { sum: 'Sum', avg: 'Average', min: 'Min', max: 'Max', count: 'Count', distinct: 'Distinct' };

// A column's total over the rows in `view`: { value, text, describe }. Counts skip empty cells.
// A function total gets { values, rows, column } (raw values and data rows, in view order) and returns
// a number (formatted like the column) or a string.
function columnTotal(col, view) {
  const mode = col.total, n = view.count();
  if (!mode) return { value: null, text: '', describe: 'no total' };
  const d = col.decimals;
  // Numbers like the column: its `format`, else grouped digits at its decimals
  const num = (x, decimals = d) => (x === null || x !== x ? ''
    : col.formatValue ? col.formatValue(x)
    : x.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }));
  const over = `${fmt(n)} row${n === 1 ? '' : 's'}`;
  if (typeof mode === 'function') {
    const rows = new Array(n), values = new Array(n);
    for (let p = 0; p < n; p++) { rows[p] = view.at(p); values[p] = col.raw(rows[p]); }
    let value;
    try { value = mode({ values, rows, column: col.label }); } catch (err) { return { value: null, text: '⚠', describe: `total error: ${err.message}` }; }
    return { value, text: typeof value === 'number' ? num(value) : value == null ? '' : String(value), describe: `custom total of ${over}` };
  }
  let value = 0;
  if (col.type === 'number') {
    const vals = col.data.values;
    let sum = 0, cnt = 0, min = Infinity, max = -Infinity;
    const seen = mode === 'distinct' ? new Set() : null;
    for (let p = 0; p < n; p++) {
      const v = vals[view.at(p)];
      if (v !== v) continue;
      sum += v; cnt++;
      if (v < min) min = v;
      if (v > max) max = v;
      if (seen) seen.add(v);
    }
    value = { sum, avg: cnt ? sum / cnt : NaN, min: cnt ? min : NaN, max: cnt ? max : NaN, count: cnt, distinct: seen && seen.size }[mode];
  } else {
    const codes = col.data.codes, dict = col.data.dict;
    const seen = new Uint8Array(dict.length);
    for (let p = 0; p < n; p++) { const c = codes[view.at(p)]; if (dict[c] !== '') { value += mode === 'count' || !seen[c]; seen[c] = 1; } }
  }
  const counting = mode === 'count' || mode === 'distinct';
  const text = counting ? fmt(value) : num(value, mode === 'avg' ? Math.max(d, 2) : d);
  return { value: value === value ? value : null, text, describe: `${TOTAL_LABELS[mode].toLowerCase()} of ${over}` };
}

// defaults: the transform, whose `heat` and `align` apply to every column that doesn't set its own
function displayColumn(spec, data, defaults = {}) {
  const heatSpec = spec.heat === undefined ? (defaults.heat === undefined ? true : defaults.heat) : spec.heat;
  // align: per column, else transform.align ('center' or { number: 'right', text: 'left' }), else numbers right / text left
  const tableAlign = typeof defaults.align === 'string' ? defaults.align : defaults.align && defaults.align[data.type];
  const align = [spec.align, tableAlign, data.type === 'number' ? 'right' : 'left'].find(a => ALIGNS.includes(a));
  // total (for the totals row): per column, else transform.total, else sum for numbers / nothing for text
  const totalSpec = spec.total !== undefined ? spec.total : defaults.total !== undefined ? defaults.total : data.type === 'number' ? 'sum' : null;
  const total = typeof totalSpec === 'function' || TOTALS[data.type].includes(totalSpec) ? totalSpec : null;
  const col = {
    label: spec.label || data.name,
    sourceName: spec.compute ? null : data.name,
    computed: !!spec.compute,
    type: data.type,
    data,
    decimals: data.type === 'number' ? (spec.decimals ?? data.decimals) : 0,
    align,
    defaultAlign: align,
    startsVisible: spec.visible !== false,       // false: listed in the column chooser, but hidden at first
    width: spec.width > 0 ? spec.width : null,   // px; null = fitted to the content (drag a header edge to change)
    defaultWidth: spec.width > 0 ? spec.width : null,
    fitRows: Array.isArray(spec.fitRows) ? spec.fitRows : null,   // extra rows to measure when fitting the width
    heat: heatSpec !== false,
    onClick: typeof spec.onClick === 'function' ? spec.onClick : null,
    render: typeof spec.render === 'function' ? spec.render : null,   // cell => text | { text, color, background, bold, italic, button }
    draw: typeof spec.draw === 'function' ? spec.draw : null,         // (ctx, box, cell) => draw the cell yourself
    total,               // 'sum' | 'avg' | 'min' | 'max' | 'count' | 'distinct' | function | null
    defaultTotal: total,
    renderGroup: typeof spec.renderGroup === 'function' ? spec.renderGroup : null,   // this column's cell on group header lines
  };
  // format: value => text for display (cells, totals, group headers, hover); sorting, filtering and CSV keep the value
  const userFormat = typeof spec.format === 'function' ? spec.format : null;
  col.formatValue = userFormat ? v => {
    try { const s = userFormat(v); return s == null ? '' : String(s); }
    catch (err) {
      if (!col._formatErr) { col._formatErr = true; console.error(`[tall-table] format for "${col.label}":`, err); }
      return String(v);
    }
  } : null;
  if (data.type === 'number') {
    const vals = data.values, d = col.decimals;
    col.raw = i => (vals[i] === vals[i] ? vals[i] : null);
    // A `decimals` setting in the config means a fixed format; otherwise mixed-precision columns drop trailing zeros
    const trim = spec.decimals == null && data.trim;
    col.plain = i => {   // the value as written in CSV exports
      const v = vals[i];
      if (v !== v) return '';
      if (d <= 0) return String(v);
      const s = v.toFixed(d);
      return trim ? s.replace(/\.?0+$/, '') : s;
    };
    col.display = col.formatValue ? i => (vals[i] === vals[i] ? col.formatValue(vals[i]) : '') : col.plain;
  } else {
    const codes = data.codes, dict = data.dict;
    col.raw = i => dict[codes[i]];
    col.plain = i => dict[codes[i]];
    if (col.formatValue) {   // formatted once per distinct value
      let shown = null;
      col.display = i => (shown || (shown = dict.map(s => (s === '' ? '' : col.formatValue(s)))))[codes[i]];
    } else col.display = col.plain;
  }
  // The colour scale (percentiles etc.) is built the first time it is needed, then replaces these
  const build = () => {
    const h = col.heat ? makeHeat(col, heatSpec) : { colors: () => null, describe: 'off' };
    col.colors = h.colors;
    col.heatInfo = h.describe;
    return h;
  };
  col.colors = i => build().colors(i);
  Object.defineProperty(col, 'heatDescription', { get: () => col.heatInfo || build().describe });
  return col;
}

function computedData(name, spec, src, rv) {
  const n = src.rowCount, out = new Array(n);
  let numeric = true;
  for (let i = 0; i < n; i++) {
    rv.$i = i;
    const v = spec.compute(rv, i);
    out[i] = v;
    if (v != null && typeof v !== 'number') numeric = false;
  }
  if (numeric) {
    const vals = new Float64Array(n);
    let decimals = 0;
    for (let i = 0; i < n; i++) {
      const v = out[i];
      vals[i] = v == null || !isFinite(v) ? NaN : v;
      if (!decimals && vals[i] === vals[i] && !Number.isInteger(vals[i])) decimals = 2;
    }
    return numberData(name, vals, decimals);
  }
  const dict = [''], index = new Map([['', 0]]), codes = new Uint32Array(n);
  for (let i = 0; i < n; i++) {
    const s = out[i] == null ? '' : String(out[i]);
    let c = index.get(s);
    if (c === undefined) { c = dict.length; index.set(s, c); dict.push(s); }
    codes[i] = c;
  }
  return textData(name, codes, dict);
}

function buildModel(src, transform) {
  const t0 = performance.now();
  transform = transform || {};
  const byName = new Map(src.columns.map(d => [d.name, d]));
  const rv = makeRowView(src);

  // Every column the user can show: the transform's columns first (initially visible), then any source
  // columns it did not use (initially hidden; visible when there is no column list at all)
  const configured = (transform.columns || []).map((raw, k) => {
    let spec = typeof raw === 'string' ? { source: raw } : raw;
    // A column with only render / draw (e.g. buttons) has no data of its own: an empty, uncoloured text column
    if (!spec.source && !spec.compute && (spec.render || spec.draw)) spec = { heat: false, ...spec, compute: () => '' };
    if (spec.compute) return displayColumn(spec, computedData(spec.label || `computed_${k + 1}`, spec, src, rv), transform);
    const data = byName.get(spec.source);
    if (!data) throw new Error(`Transform refers to unknown column "${spec.source}". Available: ${[...byName.keys()].slice(0, 12).join(', ')}${byName.size > 12 ? ', …' : ''}`);
    return displayColumn(spec, data, transform);
  });
  const used = new Set(configured.map(c => c.sourceName).filter(Boolean));
  const rest = src.columns.filter(d => !used.has(d.name)).map(d => displayColumn({ source: d.name }, d, transform));
  const hasList = !!transform.columns;
  configured.forEach(c => { c.defaultVisible = c.startsVisible; });
  rest.forEach(c => { c.defaultVisible = !hasList; });
  const allColumns = [...configured, ...rest];
  allColumns.forEach(c => { c.visible = c.defaultVisible; });
  // A stable key per column for the API: the source name (or label for computed columns), made unique
  const seenKeys = new Map();
  allColumns.forEach(c => {
    const base = c.sourceName || c.label, n = (seenKeys.get(base) || 0) + 1;
    seenKeys.set(base, n);
    c.key = n > 1 ? `${base}#${n}` : base;
  });
  const defaultOrder = allColumns.slice();
  const columns = allColumns.filter(c => c.visible);

  let hidden = null, hiddenCount = 0;
  if (typeof transform.rowFilter === 'function') {
    hidden = new Uint8Array(src.rowCount);
    for (let i = 0; i < src.rowCount; i++) {
      rv.$i = i;
      if (!transform.rowFilter(rv, i)) { hidden[i] = 1; hiddenCount++; }
    }
    if (!hiddenCount) hidden = null;
  }

  return {
    src,
    columns,        // the displayed columns, in order (renderers index into this)
    allColumns,     // every available column, in the user's chosen order; .visible marks displayed ones
    defaultOrder,   // the order and .defaultVisible flags from the transform, for "Reset"
    hidden, hiddenCount,
    numRows: src.rowCount,
    onCellClick: typeof transform.onCellClick === 'function' ? transform.onCellClick : null,
    // A fresh plain object with every source column for row i (numbers as numbers, missing as null)
    rowObject(i) {
      const o = {};
      for (const d of src.columns) o[d.name] = rawValue(d, i);
      return o;
    },
    ms: performance.now() - t0,
  };
}

// ===========================================================================
// Filters, sorting and the visible-row view
// ===========================================================================
// Numbers: one or more comparisons, all must hold: "=1", ">=20", ">10<20", "!=0"; a bare number means "=".
//          Values compare at the decimals shown, so "=0.18" matches what you see.
// Text:    "pa" contains, "=pass" exact, "!fail" does not contain, "!=n/a" not exactly. Case-insensitive.
// Either:  "|" separates alternatives: "=North | =South", "<10 | >100". For text, the plain / "=" terms are
//          alternatives (any may match) while "!" / "!=" terms all apply ("!=a | !=b" = neither a nor b).
const FILTER_HELP = {
  number: '<span class="tt-mono">=1</span> · <span class="tt-mono">&gt;=20</span> · <span class="tt-mono">&gt;10&lt;20</span> · <span class="tt-mono">!=0</span> · <span class="tt-mono">&lt;-0.5</span><br>Either: <span class="tt-mono">&lt;10 | &gt;100</span>',
  text: '<span class="tt-mono">pa</span> contains · <span class="tt-mono">=pass</span> exact<br><span class="tt-mono">!fail</span> not containing · <span class="tt-mono">!=n/a</span> not exact<br>Either: <span class="tt-mono">=North | =South</span>',
};

function parseFilter(col, text) {
  const parts = text.split('|').map(t => t.trim()).filter(Boolean);
  if (!parts.length) return null;
  const src = parts.join(' | ');   // tidy form, shown in the filter chip
  if (col.type === 'text') {
    const wanted = [], excluded = [];
    for (let s of parts) {
      let neg = false, exact = false;
      if (s.startsWith('!=')) { neg = exact = true; s = s.slice(2); }
      else if (s.startsWith('!')) { neg = true; s = s.slice(1); }
      else if (s.startsWith('==')) { exact = true; s = s.slice(2); }
      else if (s.startsWith('=')) { exact = true; s = s.slice(1); }
      (neg ? excluded : wanted).push({ exact, s: s.trim().toLowerCase() });
    }
    const hits = (v, t) => (t.exact ? v === t.s : v.includes(t.s));
    // Precompute the answer per distinct value, so testing a row is one array lookup
    const ok = col.data.dict.map(raw => {
      const v = raw.toLowerCase();
      return (!wanted.length || wanted.some(t => hits(v, t))) && !excluded.some(t => hits(v, t));
    });
    const codes = col.data.codes;
    return { text: src, test: i => ok[codes[i]] };
  }
  const tok = /^\s*(>=|<=|!=|==|=|>|<)?\s*(-?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?)\s*(?:,|&|and\b)?/i;
  const cmp = { '=': (a, b) => a === b, '!=': (a, b) => a !== b, '>': (a, b) => a > b,
    '>=': (a, b) => a >= b, '<': (a, b) => a < b, '<=': (a, b) => a <= b };
  // Each "|" group is a set of comparisons that must all hold; a row passes if any group does
  const groups = parts.map(part => {
    const checks = [];
    let rest = part;
    while (rest.trim()) {
      const m = tok.exec(rest);
      if (!m) throw new Error(`Can't read "${rest.trim()}". Try e.g. >10<20, or <10 | >100`);
      const op = m[1] === '==' ? '=' : (m[1] || '='), n = parseFloat(m[2]);
      checks.push(v => cmp[op](v, n));
      rest = rest.slice(m[0].length);
    }
    return checks;
  });
  const vals = col.data.values, p = 10 ** col.decimals;
  const round = col.decimals > 0 ? v => Math.round(v * p) / p : v => v;
  return { text: src, test: i => {
    const v = vals[i];
    if (v !== v) return false;
    const r = round(v);
    groups: for (const checks of groups) {
      for (const c of checks) if (!c(r)) continue groups;
      return true;
    }
    return false;
  } };
}

// ---------------------------------------------------------------------------
// Suggestions for text filters
// ---------------------------------------------------------------------------
// Works on a text column's distinct values (not its rows), so it is cheap even for millions of rows.
// Ranking: exact → starts with → a word starts with → contains → letters in order → near-miss typo.
// Typo matching (edit distance) only runs for columns with ≤ 20,000 distinct values.
const FUZZY_MAX_DISTINCT = 20_000;

// Typo distance (insert / delete / replace / swap two neighbouring letters each count 1),
// or max + 1 as soon as it is known to be larger than max
function editDistanceWithin(a, b, max) {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let prev2 = null, prev = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i];
    let best = i;
    for (let j = 1; j <= b.length; j++) {
      let d = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      if (prev2 && i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d = Math.min(d, prev2[j - 2] + 1);
      cur[j] = d;
      if (d < best) best = d;
    }
    if (best > max) return max + 1;
    prev2 = prev;
    prev = cur;
  }
  return prev[b.length];
}

function suggestValues(col, query, limit = 8) {
  const data = col.data, dict = data.dict;
  if (!col._valueCounts) {   // rows per distinct value, counted once per column
    const counts = new Uint32Array(dict.length);
    for (const c of data.codes) counts[c]++;
    col._valueCounts = counts;
    col._lower = dict.map(s => s.toLowerCase());
  }
  const counts = col._valueCounts, lower = col._lower;
  const q = query.trim().toLowerCase();
  const out = [];
  if (!q) {   // nothing typed: the most common values
    for (let c = 1; c < dict.length; c++) if (counts[c]) out.push({ code: c, score: 0 });
  } else {
    const fuzzy = dict.length <= FUZZY_MAX_DISTINCT;
    const typoAllowance = s => Math.max(1, Math.floor(s.length / 4));
    const words = q.split(/[\s\-_/.,()]+/).filter(Boolean);
    const multi = words.length > 1;
    if (multi && !col._tokens) col._tokens = lower.map(s => s.split(/[^\p{L}\p{N}]+/u).filter(Boolean));
    // Letters of w in order within v, close together: returns the tightest span, or Infinity
    const compactSpan = (w, v) => {
      let best = Infinity;
      for (let start = v.indexOf(w[0]); start >= 0 && start < v.length; start = v.indexOf(w[0], start + 1)) {
        let k = 1, i = start + 1;
        for (; i < v.length && k < w.length; i++) if (v[i] === w[k]) k++;
        if (k === w.length && i - start < best) best = i - start;
      }
      return best <= w.length * 2 + 1 ? best : Infinity;
    };
    for (let c = 1; c < dict.length; c++) {
      if (!counts[c]) continue;
      const v = lower[c];
      let score = -1;
      if (v === q) score = 0;
      else if (v.startsWith(q)) score = 1;
      else {
        const at = v.indexOf(q);
        if (at > 0) score = /[\s\-_/.,(]/.test(v[at - 1]) ? 2 : 3;
        else if (q.length >= 2) {
          const span = compactSpan(q, v);
          if (span < Infinity) score = 4 + (span - q.length) / 100;   // tighter = better
          else if (multi) {
            // Every typed word found in the value: as text, letters close together, or a typo of one of its words
            const toks = col._tokens[c];
            let typos = 0, ok = true;
            for (const w of words) {
              if (v.includes(w) || compactSpan(w, v) < Infinity) continue;
              const allow = typoAllowance(w);
              if (fuzzy && w.length >= 3 && toks.some(t => editDistanceWithin(w, t, allow) <= allow || editDistanceWithin(w, t.slice(0, w.length), allow) <= allow)) { typos++; continue; }
              ok = false; break;
            }
            if (ok) score = 6 + typos / 10;
          } else if (fuzzy && q.length >= 3) {   // a typo of the whole value, or of its beginning
            const allow = typoAllowance(q);
            const d = Math.min(editDistanceWithin(q, v, allow), editDistanceWithin(q, v.slice(0, q.length), allow));
            if (d <= allow) score = 5 + d;
          }
        }
      }
      if (score >= 0) out.push({ code: c, score });
    }
  }
  out.sort((a, b) => a.score - b.score || counts[b.code] - counts[a.code]);
  return out.slice(0, limit).map(s => ({ value: dict[s.code], count: counts[s.code] }));
}

// Which data rows are visible, in which order: filters AND (transform-hidden rows unless showHidden),
// in data order or sorted by one column
function createView(model) {
  const n = model.numRows;
  let posOf = null;       // Int32Array: data row -> view position (-1 = not visible); null when rows is null
  let sortCache = null;   // { col, dir, order }: every data row in sorted order, reused while only filters change
  const view = {
    filters: new Map(),   // column object -> { text, test(rowIndex) }; survives hiding/reordering columns
    sort: null,           // { col, dir: 1 | -1 } or null
    showHidden: false,
    rows: null,           // Uint32Array of visible data rows in display order, or null = all rows in data order
    ms: 0,
    sortMs: 0,
    count: () => (view.rows ? view.rows.length : n),
    at: i => (view.rows ? view.rows[i] : i),
    indexOf(row) {        // view position of a data row, or -1 if not visible
      if (row < 0 || row >= n) return -1;
      return posOf ? posOf[row] : row;
    },
    lowerBound(row) {     // view position of `row`, or of the next visible data row after it (count() if none)
      if (!posOf) return Math.min(Math.max(0, row), n);
      for (let r = Math.max(0, row); r < n; r++) if (posOf[r] >= 0) return posOf[r];
      return view.count();
    },
    isHiddenRow: row => !!(model.hidden && model.hidden[row]),

    // Grouping (one level): { col, open: Set of group names }, or null. Groups start collapsed.
    // With a group, view.rows holds the rows group by group (all of them, open or not) and the
    // renderer draws "lines": a header per group, followed by its rows when it is open.
    group: null,
    groups: [],           // [{ name, value, start, end, open, totals: Map }]: view.rows[start..end) are the group's rows
    lineCount: () => (lines ? lines.length : view.count()),
    lineAt: p => (lines ? (lines[p] >= 0 ? lines[p] : -1) : view.at(p)),   // data row, or -1 for a group header
    groupAtLine: p => (lines && lines[p] < 0 ? view.groups[-lines[p] - 1] : null),
    lineOf(row) {         // line of a data row, or -1 (not shown, or in a collapsed group)
      if (!lines) return view.indexOf(row);
      return row >= 0 && row < n ? lineOfRow[row] : -1;
    },
    headerLineOf: g => groupLine[view.groups.indexOf(g)],
    // Line to scroll to for `row`: its own line, else its group's header, else the nearest
    lineLowerBound(row) {
      if (!lines) return view.lowerBound(row);
      const p = view.lowerBound(row);
      if (p >= view.count()) return Math.max(0, lines.length - 1);
      const g = groupOfPos(p), r = view.at(p);
      return g.open ? lineOfRow[r] : groupLine[view.groups.indexOf(g)];
    },
    setGroupOpen(g, open) { g.open = open; if (open) view.group.open.add(g.name); else view.group.open.delete(g.name); buildLines(); },
    setAllGroupsOpen(open) {
      for (const g of view.groups) { g.open = open; if (open) view.group.open.add(g.name); }
      if (!open) view.group.open.clear();
      buildLines();
    },

    apply() {
      const t0 = performance.now();
      const tests = [...view.filters.values()].map(f => f.test);
      const hidden = model.hidden && !view.showHidden ? model.hidden : null;
      const order = view.sort ? sortedOrder(view.sort.col, view.sort.dir) : null;
      if (!tests.length && !hidden && !order && !view.group) { view.rows = null; posOf = null; }
      else {
        const out = new Uint32Array(n);
        let k = 0;
        rows: for (let j = 0; j < n; j++) {
          const i = order ? order[j] : j;
          if (hidden && hidden[i]) continue;
          for (const t of tests) if (!t(i)) continue rows;
          out[k++] = i;
        }
        view.rows = view.group ? groupRows(out.subarray(0, k)) : out.slice(0, k);
        posOf = new Int32Array(n).fill(-1);
        for (let p = 0; p < k; p++) posOf[view.rows[p]] = p;
      }
      if (view.group) buildLines();
      else { view.groups = []; lines = null; lineOfRow = null; groupLine = null; }
      view.ms = performance.now() - t0;
    },
  };

  // ----- grouping -----
  let lines = null;       // Int32Array: data row (>= 0), or -(group index + 1) for a group's header line
  let lineOfRow = null;   // Int32Array: data row -> line (-1 = not shown)
  let groupLine = null;   // Int32Array: group index -> its header line

  // Splits the filtered rows (already in sort order) into groups by the group column's displayed value,
  // orders the groups, and returns the rows group by group. Inside a group, rows keep the sort order.
  function groupRows(rows) {
    const gcol = view.group.col, byName = new Map(), groups = [];
    const name = gcol.type === 'text' ? (() => { const d = gcol.data.dict, c = gcol.data.codes; return i => d[c[i]]; })() : gcol.display;
    const which = new Uint32Array(rows.length);
    for (let p = 0; p < rows.length; p++) {
      const s = name(rows[p]);
      let g = byName.get(s);
      if (g === undefined) { g = groups.length; byName.set(s, g); groups.push({ name: s, value: gcol.raw(rows[p]), size: 0 }); }
      groups[g].size++;
      which[p] = g;
    }
    // Group order: by subtotal when sorted by a number column (other than the group column), else by name
    const s = view.sort, collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
    const byNameOrder = (a, b) => (a.name === '') - (b.name === '') || collator.compare(a.name, b.name);
    let start = 0;
    for (const g of groups) { g.start = start; g.end = start; start += g.size; }
    const grouped = new Uint32Array(rows.length);
    for (let p = 0; p < rows.length; p++) { const g = groups[which[p]]; grouped[g.end++] = rows[p]; }
    if (s && s.col.type === 'number' && s.col !== gcol) {
      for (const g of groups) g.key = subtotalForSort(s.col, grouped, g);
      groups.sort((a, b) => {
        const va = a.key, vb = b.key;
        if (va !== va) return vb !== vb ? byNameOrder(a, b) : 1;   // groups without a value last
        if (vb !== vb) return -1;
        return (va - vb) * s.dir || byNameOrder(a, b);
      });
    } else {
      // Sorting by the group column itself orders the groups; number groups go by value (their names may be formatted)
      const dir = s && s.col === gcol ? s.dir : 1;
      groups.sort(gcol.type === 'number'
        ? (a, b) => ((a.value === null) - (b.value === null)) || ((a.value - b.value) * dir) || byNameOrder(a, b)
        : (a, b) => ((a.name === '') - (b.name === '')) || collator.compare(a.name, b.name) * dir);
    }
    // Lay the rows out in the final group order
    const out = new Uint32Array(rows.length);
    let k = 0;
    view.groups = groups.map(g => {
      const g2 = { name: g.name, value: g.value, start: k, end: k + g.size, open: view.group.open.has(g.name), totals: new Map() };
      out.set(grouped.subarray(g.start, g.end), k);
      k += g.size;
      return g2;
    });
    return out;
  }
  // A group's value for ordering groups: the sort column's total (as chosen for the totals row), else its sum
  function subtotalForSort(col, rows, g) {
    const sub = { count: () => g.end - g.start, at: p => rows[g.start + p] };
    const mode = TOTALS.number.includes(col.total) ? col.total : 'sum';
    const t = columnTotal(mode === col.total ? col : { ...col, total: mode }, sub);
    return typeof t.value === 'number' ? t.value : NaN;
  }
  function groupOfPos(p) {   // the group holding view position p (binary search over the starts)
    const gs = view.groups;
    let lo = 0, hi = gs.length - 1;
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (gs[mid].start <= p) lo = mid; else hi = mid - 1; }
    return gs[lo];
  }
  function buildLines() {
    const gs = view.groups;
    let total = gs.length;
    for (const g of gs) if (g.open) total += g.end - g.start;
    lines = new Int32Array(total);
    groupLine = new Int32Array(gs.length);
    if (!lineOfRow || lineOfRow.length !== n) lineOfRow = new Int32Array(n);
    lineOfRow.fill(-1);
    let l = 0;
    gs.forEach((g, gi) => {
      groupLine[gi] = l;
      lines[l++] = -(gi + 1);
      if (g.open) for (let p = g.start; p < g.end; p++) { const r = view.rows[p]; lineOfRow[r] = l; lines[l++] = r; }
    });
  }

  // Numbers numerically, text in natural order ("a2" < "a10"); empty cells last; ties keep data order
  function sortedOrder(col, dir) {
    if (sortCache && sortCache.col === col && sortCache.dir === dir) return sortCache.order;
    const t0 = performance.now();
    const order = new Uint32Array(n);
    for (let i = 0; i < n; i++) order[i] = i;
    if (col.type === 'number') {
      const vals = col.data.values;
      order.sort((a, b) => {
        const va = vals[a], vb = vals[b];
        if (va !== va) return vb !== vb ? a - b : 1;
        if (vb !== vb) return -1;
        return (va - vb) * dir || a - b;
      });
    } else {
      const dict = col.data.dict, codes = col.data.codes;
      const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
      const byText = dict.map((s, c) => c).filter(c => dict[c] !== '').sort((a, b) => collator.compare(dict[a], dict[b]));
      const EMPTY = dict.length;
      const rank = new Uint32Array(dict.length).fill(EMPTY);
      byText.forEach((c, r) => { rank[c] = r; });
      order.sort((a, b) => {
        const ra = rank[codes[a]], rb = rank[codes[b]];
        if (ra === EMPTY) return rb === EMPTY ? a - b : 1;
        if (rb === EMPTY) return -1;
        return (ra - rb) * dir || a - b;
      });
    }
    sortCache = { col, dir, order };
    view.sortMs = performance.now() - t0;
    return order;
  }

  view.apply();
  return view;
}

// ===========================================================================
// Renderers
// ===========================================================================
// A renderer draws ctl.view inside `grid` and reports pointer actions back through ctl:
//   ctl.setHover(x, row), ctl.select(x, row), ctl.headerClick(x, left, top) (sorts, or opens the filter box
//   on a double click), ctl.openFilter(x, left, top), ctl.openColumns(left, top), ctl.moveColumn(from, to),
//   ctl.rowClick(row, { shift, toggle }), ctl.rowDragTo(row) (row selection from the row numbers),
//   ctl.closePopovers()        (x = index into ctl.model.columns, row = data row index)
// factory(grid, ctl, options) returns (or resolves to) an object with:
//   modelChanged()        a new model was loaded: reset column layout etc.
//   columnsChanged()      ctl.model.columns changed: re-layout, keep the vertical position
//   rowsChanged(keepRow)  visible rows changed: resize the scroll range, keep data row `keepRow` near the top
//   linesChanged()        optional: groups were opened / closed (keep the scroll position)
//   scrollToIndex(i)      scroll so line i is at the top
// Rows are laid out as view "lines" (view.lineCount(), lineAt(p) -> data row or -1, groupAtLine(p), lineOf(row)):
// without grouping these are just the view positions. A group header line reports clicks with
// ctl.toggleGroup(group) and draws ctl.groupTotalText(col, group) per column (the group's name in view.group.col).
//   topRow()              data row currently at the top of the viewport
//   redraw()              repaint after hover / selection / heatmap changes
//   resized()             optional: the grid changed size (e.g. the side panel was toggled)
//   headersChanged()      optional: ctl.headers changed (show / hide the column header row)
//   totalsChanged()       optional: ctl.totals changed ('top' | 'bottom' | null); draw ctl.totalText(col) there
//                         and report clicks on it with ctl.openTotal(x, left, top)
//   destroy()             remove everything it added
//   description           optional HTML for the panel footer
const RENDERERS = {};
function registerRenderer(name, factory) { RENDERERS[name] = factory; }

// ---------------------------------------------------------------------------
// Canvas renderer: no library; only the visible cells are drawn to one <canvas> per frame
// ---------------------------------------------------------------------------
registerRenderer('canvas', (grid, ctl) => {
  const ROW_H = 22, HEAD_FULL = 24;
  let HEAD_H = ctl.headers ? HEAD_FULL : 0;   // 0 when the page hides the header row (headers: false)
  const rowHeadW = () => (ctl.rowNumbers ? 90 : 24);   // row-number column, or a slim strip that still holds the ☰ menu
  const C = {
    bg: '#11151c', cellBg: '#151a22', headBg: '#1c212b', grid: 'rgba(255,255,255,0.05)', text: '#e6e8ec',
    muted: '#8b93a3', hover: 'rgba(255,255,255,0.10)', accent: '#ffd54a',
    rowSel: 'rgba(255,213,74,0.16)', rowSelHead: 'rgba(255,213,74,0.22)',
    totBg: '#202634', totLine: 'rgba(255,213,74,0.35)', btnBg: '#2d3546', btnLine: '#4a5570', groupBg: '#1d2330',
  };
  const FONT = '12px system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
  const HEAD_FONT = '500 ' + FONT;
  // Browsers cap element size (~33.5M px Chromium, ~17.9M px Firefox), so the scrollable height is
  // capped and scrollTop is mapped proportionally onto the true content height.
  const MAX_SCROLL_PX = /firefox/i.test(navigator.userAgent) ? 8_000_000 : 16_000_000;

  grid.insertAdjacentHTML('afterbegin',
    '<div class="tt-scroller" tabindex="0"><div class="tt-spacer"></div></div><canvas class="tt-canvas"></canvas>');
  const scroller = grid.querySelector('.tt-scroller');
  const spacer = grid.querySelector('.tt-spacer');
  const canvas = grid.querySelector('.tt-canvas');
  const ctx = canvas.getContext('2d', { alpha: false });

  let viewW = 0, viewH = 0;      // canvas size in CSS px (scroller client area)
  let vy = 0;                    // virtual y offset into the rows, in px
  let colLeft = [0];             // colLeft[c] = x of column c within the data area; colLeft[n] = total width
  let cornerHover = false, drawQueued = false;

  // Column widths from the header and a sample of values
  // A column's own width (dragged, or `width` in the config) wins; otherwise a fitted width, measured once
  let sample = null, sampleModel = null;
  function fittedWidth(col) {
    if (col._fitW) return col._fitW;
    const { model } = ctl;
    if (sampleModel !== model) {
      const n = model.numRows;
      sample = [];
      for (let i = 0; i < Math.min(n, 200); i++) sample.push(i);
      for (let k = 1; k <= 200 && n > 200; k++) sample.push(Math.floor((k / 201) * n));
      sampleModel = model;
    }
    ctx.font = HEAD_FONT;
    let w = ctx.measureText(col.label).width + 34;   // room for the filter marker and sort arrow
    ctx.font = FONT;
    for (const i of col.fitRows ? sample.concat(col.fitRows) : sample) {
      if (!col.render) { w = Math.max(w, ctx.measureText(col.display(i)).width + 14); continue; }
      const look = ctl.cellLook(col, i);   // rendered text, plus room for any button
      ctx.font = look.font + FONT;
      let cw = look.text ? ctx.measureText(look.text).width + 14 : 0;
      ctx.font = FONT;
      if (look.button) cw += ctx.measureText(look.button.label).width + 24;
      w = Math.max(w, cw);
    }
    col._fitW = Math.round(Math.min(260, Math.max(56, w)));
    return col._fitW;
  }
  // While grouped, the group column also fits its group names (and subtotal) on the header lines,
  // and so does any column with a renderGroup callback
  const showsGroupTotal = col => col.total === 'count' || col.total === 'sum' || typeof col.total === 'function';
  function groupColumnWidth(col) {
    const v = ctl.view;
    if (!v || !v.group || (v.group.col !== col && !col.renderGroup)) return 0;
    ctx.font = HEAD_FONT;
    let w = 0;
    for (const g of v.groups.slice(0, 500)) {
      let gw;
      if (col.renderGroup) {
        const look = ctl.groupLook(col, g);
        ctx.font = look.font + (look.font.includes('600') ? FONT : HEAD_FONT);
        gw = ctx.measureText(look.text).width + 14;
        ctx.font = HEAD_FONT;
      } else {
        gw = ctx.measureText(g.name || '(blank)').width + 14;
        if (showsGroupTotal(col)) gw += ctx.measureText(ctl.groupTotalText(col, g)).width + 14;
      }
      w = Math.max(w, gw);
    }
    ctx.font = FONT;
    return Math.min(320, Math.ceil(w));
  }
  function layoutColumns() {
    colLeft = [0];
    for (const col of ctl.model.columns) {
      colLeft.push(colLeft[colLeft.length - 1] + Math.round(col.width || Math.max(fittedWidth(col), groupColumnWidth(col))));
    }
  }
  const numCols = () => colLeft.length - 1;
  const colX = c => rowHeadW() + colLeft[c] - scroller.scrollLeft;
  const colW = c => colLeft[c + 1] - colLeft[c];
  function colAtDataX(x) {   // column index containing data-area x, or -1
    if (!numCols() || x < 0 || x >= colLeft[numCols()]) return -1;
    let lo = 0, hi = numCols() - 1;
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (colLeft[mid] <= x) lo = mid; else hi = mid - 1; }
    return lo;
  }

  // Rows are drawn as "lines": data rows, plus a header line per group when the view is grouped
  const contentH = () => (ctl.view ? ctl.view.lineCount() * ROW_H : 0);
  // Frozen bands around the rows: the header (and a top totals row) above, a bottom totals row below
  const topH = () => HEAD_H + (ctl.totals === 'top' ? ROW_H : 0);
  const botH = () => (ctl.totals === 'bottom' ? ROW_H : 0);
  function sizeSpacer() {
    spacer.style.width = (rowHeadW() + colLeft[numCols()]) + 'px';
    spacer.style.height = (topH() + botH() + Math.min(contentH(), MAX_SCROLL_PX)) + 'px';
  }

  // ----- virtual vertical scrolling -----
  const dataViewH = () => Math.max(0, viewH - topH() - botH());
  const maxVY = () => Math.max(0, contentH() - dataViewH());
  const maxScrollTop = () => Math.max(0, scroller.scrollHeight - scroller.clientHeight);
  const toScrollTop = v => (maxVY() ? (v / maxVY()) * maxScrollTop() : 0);
  const fromScrollTop = s => (maxScrollTop() ? (s / maxScrollTop()) * maxVY() : 0);

  function setVY(v) {
    vy = Math.min(maxVY(), Math.max(0, v));
    const st = toScrollTop(vy);
    if (Math.abs(scroller.scrollTop - st) >= 1) scroller.scrollTop = st;
    requestDraw();
  }

  scroller.addEventListener('scroll', () => {
    // A resize changes the scrollTop <-> vy mapping; keep vy and let the ResizeObserver re-sync scrollTop
    if (scroller.clientHeight !== viewH || scroller.clientWidth !== viewW) return;
    // Ignore scroll events caused by setVY (scrollTop already matches vy); otherwise the user dragged the scrollbar
    if (Math.abs(scroller.scrollTop - toScrollTop(vy)) >= 1) vy = fromScrollTop(scroller.scrollTop);
    requestDraw();
  });

  // Wheel drives vy directly so steps are in true pixels even when the scroll range is compressed
  scroller.addEventListener('wheel', e => {
    if (e.ctrlKey) return;
    const k = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? scroller.clientHeight : 1;
    let dx = e.deltaX * k, dy = e.deltaY * k;
    if (e.shiftKey && !dx) { dx = dy; dy = 0; }
    e.preventDefault();
    if (dx) scroller.scrollLeft += dx;
    if (dy) setVY(vy + dy);
  }, { passive: false });

  // Keyboard paging (the scroller is focusable so these work after clicking the grid)
  scroller.addEventListener('keydown', e => {
    const page = Math.max(ROW_H, dataViewH() - ROW_H);
    const steps = { ArrowDown: ROW_H, ArrowUp: -ROW_H, PageDown: page, PageUp: -page };
    if (e.key in steps) setVY(vy + steps[e.key]);
    else if (e.key === 'Home') setVY(0);
    else if (e.key === 'End') setVY(maxVY());
    else return;
    e.preventDefault();
  });

  const ro = new ResizeObserver(() => {
    viewW = scroller.clientWidth; viewH = scroller.clientHeight;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(viewW * dpr); canvas.height = Math.round(viewH * dpr);
    canvas.style.width = viewW + 'px'; canvas.style.height = viewH + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    setVY(vy);
    draw();
  });
  ro.observe(scroller);

  // ----- drawing: only the visible window of cells -----
  function requestDraw() {
    if (drawQueued) return;
    drawQueued = true;
    requestAnimationFrame(() => { drawQueued = false; draw(); });
  }

  function draw() {
    ctx.fillStyle = C.bg;
    ctx.fillRect(0, 0, viewW, viewH);
    const { model, view, hover, sel, heat } = ctl;
    if (!model) return;
    const cols = model.columns;
    const vx = scroller.scrollLeft;
    const c0 = Math.max(0, colAtDataX(vx));
    const cEnd = colAtDataX(vx + viewW - rowHeadW());
    const c1 = cEnd < 0 ? numCols() : cEnd + 1;
    // r0..r1 are lines of the (filtered, sorted, grouped) view; view.lineAt() maps them to data rows (-1: group header)
    const r0 = Math.floor(vy / ROW_H), r1 = Math.min(view.lineCount(), Math.ceil((vy + dataViewH()) / ROW_H));
    const top = topH(), rowY = r => top + r * ROW_H - vy;
    const hy = hover.group ? view.headerLineOf(hover.group) : view.lineOf(hover.y), sy = view.lineOf(sel.y);
    const dimHidden = view.showHidden && model.hidden;

    ctx.font = FONT;
    ctx.textBaseline = 'middle';

    // Cells, clipped per column
    for (let c = c0; c < c1; c++) {
      const col = cols[c], x = colX(c), w = colW(c), useHeat = heat && col.heat;
      ctx.save();
      ctx.beginPath(); ctx.rect(x, top, w, dataViewH()); ctx.clip();
      ctx.textAlign = col.align;
      const tx = col.align === 'right' ? x + w - 7 : col.align === 'center' ? x + w / 2 : x + 7;
      for (let r = r0; r < r1; r++) {
        const y = rowY(r), row = view.lineAt(r);
        if (row < 0) {   // a group's header line: its name in the group column, subtotals in the others
          const g = view.groupAtLine(r);
          ctx.globalAlpha = 1;
          ctx.fillStyle = C.groupBg;
          ctx.fillRect(x, y, w, ROW_H);
          ctx.font = HEAD_FONT;
          if (col.renderGroup) {   // the column's own callback decides this cell
            const look = ctl.groupLook(col, g);
            if (look.background) { ctx.fillStyle = look.background; ctx.fillRect(x, y, w, ROW_H); }
            ctx.font = look.font + (look.font.includes('600') ? FONT : HEAD_FONT);
            ctx.fillStyle = look.color || (col === view.group.col ? C.accent : C.text);
            ctx.fillText(look.text, tx, y + ROW_H / 2);
          } else if (col === view.group.col) {
            // The name on the left, plus the subtotal on the right when it adds something: count, sum or a
            // custom total (distinct is always 1, and avg / min / max equal the name)
            const extra = showsGroupTotal(col) ? ctl.groupTotalText(col, g) : '';
            ctx.fillStyle = C.accent;
            ctx.textAlign = extra ? 'left' : col.align;
            const room = extra ? w - 21 - ctx.measureText(extra).width : Infinity;   // keep a gap before the subtotal
            ctx.fillText(fitText(g.name || '(blank)', room), extra ? x + 7 : tx, y + ROW_H / 2);
            if (extra) {
              ctx.fillStyle = C.text; ctx.textAlign = 'right';
              ctx.fillText(extra, x + w - 7, y + ROW_H / 2);
            }
            ctx.textAlign = col.align;
          } else {
            ctx.fillStyle = C.text;
            ctx.fillText(ctl.groupTotalText(col, g), tx, y + ROW_H / 2);
          }
          ctx.font = FONT;
          continue;
        }
        const colors = useHeat ? col.colors(row) : null;
        ctx.globalAlpha = dimHidden && model.hidden[row] ? 0.4 : 1;
        if (col.render || col.draw) { drawCustomCell(col, row, x, y, w, colors); continue; }
        ctx.fillStyle = colors ? colors[0] : C.cellBg;
        ctx.fillRect(x, y, w, ROW_H);
        ctx.fillStyle = colors ? colors[1] : C.text;
        ctx.fillText(col.display(row), tx, y + ROW_H / 2);
      }
      ctx.restore();
    }

    // Grid lines
    ctx.fillStyle = C.grid;
    for (let c = c0; c <= c1 && c <= numCols(); c++) ctx.fillRect(colX(c) - 1, HEAD_H, 1, viewH);
    for (let r = r0; r <= r1; r++) ctx.fillRect(rowHeadW(), rowY(r) - 1, viewW, 1);

    // Selected rows: a tint across the whole row
    if (ctl.rowSelCount) {
      ctx.fillStyle = C.rowSel;
      for (let r = r0; r < r1; r++) if (ctl.rowSel[view.lineAt(r)]) ctx.fillRect(rowHeadW(), rowY(r), viewW, ROW_H);
    }

    // Hover crosshair and selection
    ctx.fillStyle = C.hover;
    if (hy >= r0 && hy < r1) ctx.fillRect(0, rowY(hy), viewW, ROW_H);
    if (hover.x >= c0 && hover.x < c1) ctx.fillRect(colX(hover.x), 0, colW(hover.x), viewH);
    if (sel.x >= c0 && sel.x < c1 && sy >= r0 && sy < r1) {
      ctx.strokeStyle = C.accent; ctx.lineWidth = 2;
      ctx.strokeRect(colX(sel.x) + 1, rowY(sy) + 1, colW(sel.x) - 2, ROW_H - 2);
    }

    // Column header (frozen top); skipped entirely when the page hides the header row
    if (HEAD_H) {
    ctx.fillStyle = C.headBg;
    ctx.fillRect(rowHeadW(), 0, viewW, HEAD_H);
    ctx.font = HEAD_FONT;
    for (let c = c0; c < c1; c++) {
      const col = cols[c], x = colX(c), w = colW(c), filtered = view.filters.has(col);
      const sorted = view.sort && view.sort.col === col;
      ctx.save();
      ctx.beginPath(); ctx.rect(x, 0, w, HEAD_H); ctx.clip();
      ctx.fillStyle = filtered || sorted || c === sel.x ? C.accent : c === hover.x ? C.text : C.muted;
      // Header text follows the column's alignment; the funnel marker sits at the left edge
      ctx.textAlign = col.align;
      const label = sorted ? `${col.label} ${view.sort.dir > 0 ? '▲' : '▼'}` : col.label;
      const hx = col.align === 'right' ? x + w - 7 : col.align === 'center' ? x + w / 2 + (filtered ? 6 : 0) : x + (filtered ? 20 : 7);
      ctx.fillText(label, hx, HEAD_H / 2);
      if (filtered) {   // funnel marker
        const fx = x + 7, fy = HEAD_H / 2 - 4;
        ctx.beginPath(); ctx.moveTo(fx, fy); ctx.lineTo(fx + 8, fy); ctx.lineTo(fx + 5, fy + 4);
        ctx.lineTo(fx + 5, fy + 8); ctx.lineTo(fx + 3, fy + 8); ctx.lineTo(fx + 3, fy + 4); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    }
    if (hover.x >= c0 && hover.x < c1) { ctx.fillStyle = C.hover; ctx.fillRect(colX(hover.x), 0, colW(hover.x), HEAD_H); }

    // Column being dragged: a ghost following the pointer and a line where it will be dropped
    if (colDrag && colDrag.active) {
      const gx = colX(colDrag.from) + (colDrag.curX - colDrag.startX);
      ctx.globalAlpha = 0.22;
      ctx.fillStyle = C.accent;
      ctx.fillRect(gx, 0, colW(colDrag.from), viewH);
      ctx.globalAlpha = 1;
      ctx.font = HEAD_FONT; ctx.textAlign = 'left'; ctx.fillStyle = C.accent;
      ctx.fillText(cols[colDrag.from].label, gx + 7, HEAD_H / 2);
      ctx.fillRect(colX(dropBoundary(colDrag.curX)) - 1, 0, 3, viewH);
    }
    }

    // Row header (frozen left): data row numbers
    ctx.font = FONT;
    ctx.textAlign = 'right';
    ctx.fillStyle = C.headBg;
    ctx.fillRect(0, HEAD_H, rowHeadW(), viewH);
    for (let r = r0; r < r1; r++) {
      const row = view.lineAt(r);
      if (row < 0) {   // group header: ▸ / ▾ and the number of rows in the group
        const g = view.groupAtLine(r), y = rowY(r);
        ctx.fillStyle = C.groupBg;
        ctx.fillRect(0, y, rowHeadW(), ROW_H);
        if (r === hy) { ctx.fillStyle = C.hover; ctx.fillRect(0, y, rowHeadW(), ROW_H); }
        ctx.fillStyle = C.accent;
        ctx.textAlign = ctl.rowNumbers ? 'left' : 'center';
        ctx.fillText(g.open ? '▾' : '▸', ctl.rowNumbers ? 8 : rowHeadW() / 2, y + ROW_H / 2);
        if (ctl.rowNumbers) {
          ctx.fillStyle = C.muted; ctx.textAlign = 'right';
          ctx.fillText(fmt(g.end - g.start), rowHeadW() - 8, y + ROW_H / 2);
        }
        ctx.textAlign = 'right';
        continue;
      }
      const rowSelected = ctl.isRowSelected(row);
      if (rowSelected) { ctx.fillStyle = C.rowSelHead; ctx.fillRect(0, rowY(r), rowHeadW(), ROW_H); }
      if (r === hy) { ctx.fillStyle = C.hover; ctx.fillRect(0, rowY(r), rowHeadW(), ROW_H); }
      ctx.globalAlpha = dimHidden && model.hidden[row] ? 0.5 : 1;
      ctx.fillStyle = r === sy || rowSelected ? C.accent : r === hy ? C.text : C.muted;
      if (ctl.rowNumbers) ctx.fillText(String(row), rowHeadW() - 8, rowY(r) + ROW_H / 2);
      else if (r === sy || rowSelected) ctx.fillRect(rowHeadW() - 4, rowY(r) + 3, 2, ROW_H - 6);   // marker in the slim strip
    }
    ctx.globalAlpha = 1;
    if (ctl.totals) drawTotals(cols, c0, c1, ctl.totals === 'top' ? HEAD_H : viewH - ROW_H);
    ctx.fillStyle = C.grid;
    ctx.fillRect(rowHeadW() - 1, 0, 1, viewH);
    if (!HEAD_H) return;   // no header row: no corner either (the menu is reachable from the page / API)
    ctx.fillRect(0, HEAD_H - 1, viewW, 1);

    // Corner: opens the options menu (just ☰ when the row numbers are hidden)
    ctx.fillStyle = C.headBg;
    ctx.fillRect(0, 0, rowHeadW() - 1, HEAD_H - 1);
    ctx.font = HEAD_FONT;
    ctx.fillStyle = cornerHover ? C.text : C.muted;
    ctx.textAlign = ctl.rowNumbers ? 'left' : 'center';
    ctx.fillText(ctl.rowNumbers ? '☰ Options' : '☰', ctl.rowNumbers ? 8 : rowHeadW() / 2, HEAD_H / 2);
  }

  // Text shortened with "…" to fit maxW px in the current font
  function fitText(s, maxW) {
    if (ctx.measureText(s).width <= maxW) return s;
    let lo = 0, hi = s.length;
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (ctx.measureText(s.slice(0, mid) + '…').width <= maxW) lo = mid; else hi = mid - 1; }
    return lo ? s.slice(0, lo) + '…' : '';
  }

  // A cell styled by the column's render callback, or drawn by its draw callback (called with the canvas
  // context clipped to the column, and the cell's box in CSS px)
  function drawCustomCell(col, row, x, y, w, colors) {
    const look = col.render ? ctl.cellLook(col, row) : null;
    ctx.fillStyle = (look && look.background) || (colors ? colors[0] : C.cellBg);
    ctx.fillRect(x, y, w, ROW_H);
    if (col.draw) {
      ctx.save();
      try { col.draw(ctx, { x, y, w, h: ROW_H }, ctl.cellInfo(col, row)); }
      catch (err) { if (!col._drawErr) { col._drawErr = true; console.error(`[tall-table] draw for "${col.label}":`, err); } }
      ctx.restore();
      ctx.font = FONT; ctx.textBaseline = 'middle'; ctx.textAlign = col.align;
      return;
    }
    const btn = look.button ? buttonBox(col, look, x, y, w) : null;
    if (look.text) {
      ctx.font = look.font + FONT;
      ctx.fillStyle = look.color || (look.background || !colors ? C.text : colors[1]);
      const align = btn ? 'left' : col.align;   // with a button too, the text goes left and the button right
      ctx.textAlign = align;
      const tx = align === 'right' ? x + w - 7 : align === 'center' ? x + w / 2 : x + 7;
      ctx.fillText(look.text, tx, y + ROW_H / 2);
      if (look.strike) {   // a line through the text
        const tw = ctx.measureText(look.text).width, sx = align === 'right' ? tx - tw : align === 'center' ? tx - tw / 2 : tx;
        ctx.fillRect(sx, Math.round(y + ROW_H / 2), tw, 1);
      }
    }
    if (btn) {
      ctx.font = FONT;
      ctx.fillStyle = look.button.background || C.btnBg;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(btn.x, btn.y, btn.w, btn.h, 4); else ctx.rect(btn.x, btn.y, btn.w, btn.h);
      ctx.fill();
      ctx.strokeStyle = C.btnLine; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = look.button.color || C.text;
      ctx.textAlign = 'center';
      ctx.fillText(look.button.label, btn.x + btn.w / 2, y + ROW_H / 2);
    }
    ctx.font = FONT; ctx.textAlign = col.align;
  }
  // Where a render callback's button sits in its cell: after any text, else placed by the column's alignment
  function buttonBox(col, look, x, y, w) {
    ctx.font = FONT;
    const bw = Math.max(16, Math.min(w - 8, ctx.measureText(look.button.label).width + 16));
    const bx = look.text || col.align === 'right' ? x + w - 4 - bw : col.align === 'center' ? x + (w - bw) / 2 : x + 4;
    return { x: bx, y: y + 3, w: bw, h: ROW_H - 6 };
  }
  // The label of the render button under the pointer, or null
  function buttonAt(e, c) {
    if (c.x < 0 || c.y < 0) return null;
    const col = ctl.model.columns[c.x];
    if (!col.render) return null;
    const look = ctl.cellLook(col, c.y);
    if (!look.button) return null;
    const rect = scroller.getBoundingClientRect();
    const b = buttonBox(col, look, colX(c.x), topH() + ctl.view.lineOf(c.y) * ROW_H - vy, colW(c.x));
    const px = e.clientX - rect.left, py = e.clientY - rect.top;
    return px >= b.x && px < b.x + b.w && py >= b.y && py < b.y + b.h ? look.button.label : null;
  }

  // The totals row: frozen at y, one cell per column, over the rows currently shown
  function drawTotals(cols, c0, c1, y) {
    ctx.fillStyle = C.totBg;
    ctx.fillRect(0, y, viewW, ROW_H);
    ctx.font = HEAD_FONT;
    for (let c = c0; c < c1; c++) {
      const col = cols[c], x = colX(c), w = colW(c);
      ctx.save();
      ctx.beginPath(); ctx.rect(x, y, w, ROW_H); ctx.clip();
      ctx.textAlign = col.align;
      ctx.fillStyle = C.text;
      const tx = col.align === 'right' ? x + w - 7 : col.align === 'center' ? x + w / 2 : x + 7;
      ctx.fillText(ctl.totalText(col), tx, y + ROW_H / 2);
      ctx.restore();
      ctx.fillStyle = C.grid;
      ctx.fillRect(x + w - 1, y, 1, ROW_H);
    }
    if (ctl.hover.totals && ctl.hover.x >= c0 && ctl.hover.x < c1) {
      ctx.fillStyle = C.hover; ctx.fillRect(colX(ctl.hover.x), y, colW(ctl.hover.x), ROW_H);
    }
    // Its row-header cell, and a line between it and the rows
    ctx.fillStyle = C.totBg;
    ctx.fillRect(0, y, rowHeadW() - 1, ROW_H);
    ctx.fillStyle = C.muted;
    ctx.textAlign = ctl.rowNumbers ? 'right' : 'center';
    ctx.fillText(ctl.rowNumbers ? 'Σ Totals' : 'Σ', ctl.rowNumbers ? rowHeadW() - 8 : rowHeadW() / 2, y + ROW_H / 2);
    ctx.fillStyle = C.totLine;
    ctx.fillRect(0, ctl.totals === 'top' ? y + ROW_H - 1 : y, viewW, 1);
  }

  // ----- pointer interaction -----
  function cellAt(e) {
    const rect = scroller.getBoundingClientRect();
    const px = e.clientX - rect.left, py = e.clientY - rect.top;
    if (!ctl.model || px < 0 || py < 0 || px >= viewW || py >= viewH) return { x: -1, y: -1 };
    if (py < HEAD_H && px < rowHeadW()) return { x: -1, y: -1, corner: true, left: rect.left, bottom: rect.top + HEAD_H };
    const x = px < rowHeadW() ? -1 : colAtDataX(px - rowHeadW() + scroller.scrollLeft);
    if (py < HEAD_H) return { x, y: -1, header: x >= 0, left: rect.left + (x >= 0 ? colX(x) : 0), bottom: rect.top + HEAD_H };
    if (py < topH() || py >= viewH - botH()) {   // the totals row
      const y = ctl.totals === 'top' ? HEAD_H : viewH - ROW_H;
      return { x, y: -1, totals: x >= 0, left: rect.left + (x >= 0 ? colX(x) : 0), bottom: rect.top + y + ROW_H };
    }
    const v = Math.floor((py - topH() + vy) / ROW_H);   // line in the view
    if (v >= ctl.view.lineCount()) return { x, y: -1, rowHeader: px < rowHeadW() };
    const g = ctl.view.groupAtLine(v);
    if (g) return { x, y: -1, group: g };   // a group's header line
    return { x, y: ctl.view.lineAt(v), rowHeader: px < rowHeadW() };
  }

  // ----- row selection: click / drag on the row numbers -----
  let rowDrag = false;
  // Data row at a viewport y (clamped to the rows on screen), scrolling when the pointer is above / below them
  function rowAtClientY(clientY) {
    const rect = scroller.getBoundingClientRect(), py = clientY - rect.top;
    const top = topH(), bottom = viewH - botH();
    if (py < top) setVY(vy - ROW_H);
    else if (py > bottom) setVY(vy + ROW_H);
    const n = ctl.view.lineCount();
    const v = Math.floor((Math.min(Math.max(py, top), bottom - 1) - top + vy) / ROW_H);
    return n ? ctl.view.lineAt(Math.min(n - 1, Math.max(0, v))) : -1;   // -1 on a group header
  }
  const onRowDragMove = e => {
    if (!rowDrag) return;
    const row = rowAtClientY(e.clientY);
    if (row >= 0) ctl.rowDragTo(row);
  };
  const onRowDragEnd = () => { rowDrag = false; };
  window.addEventListener('mousemove', onRowDragMove);
  window.addEventListener('mouseup', onRowDragEnd);

  // ----- column resizing: drag a header's right edge; double-click the edge to go back to the fitted width -----
  const EDGE_PX = 5;
  function edgeAt(e) {   // index of the column whose right edge is under the pointer (header row only), or -1
    if (!ctl.model || !ctl.headerControls.resize) return -1;
    const rect = scroller.getBoundingClientRect();
    const px = e.clientX - rect.left, py = e.clientY - rect.top;
    if (py < 0 || py >= HEAD_H || px < rowHeadW() + EDGE_PX) return -1;
    const dx = px - rowHeadW() + scroller.scrollLeft;
    for (let c = Math.max(0, colAtDataX(dx) - 1), n = numCols(); c < n && colLeft[c] <= dx + EDGE_PX; c++) {
      if (Math.abs(colLeft[c + 1] - dx) <= EDGE_PX) return c;
    }
    return -1;
  }
  let resizing = null;            // { col, startX, startW }
  let swallowClick = false;       // the click that ends a resize must not sort the column
  let lastEdgeDown = { c: -1, t: 0 };
  scroller.addEventListener('mousedown', e => {
    if (e.button !== 0) return;
    const c = edgeAt(e);
    if (c < 0) {
      swallowClick = false;   // e.g. a resize that ended outside the table left it set
      // Pressing on a header body may become a drag that moves the column (starts after a few px of movement)
      const hit = cellAt(e);
      if (hit.header && ctl.headerControls.columns) colDrag = { from: hit.x, startX: e.clientX, curX: e.clientX, active: false };
      else if (hit.rowHeader && hit.y >= 0) {   // row numbers: select rows (dragging extends the range)
        e.preventDefault();
        scroller.focus({ preventScroll: true });   // so Esc reaches the table
        ctl.closePopovers();
        ctl.rowClick(hit.y, { shift: e.shiftKey, toggle: e.ctrlKey || e.metaKey });
        rowDrag = !e.shiftKey;
        swallowClick = true;
      }
      return;
    }
    e.preventDefault();
    swallowClick = true;
    const col = ctl.model.columns[c];
    const now = performance.now();
    if (lastEdgeDown.c === c && now - lastEdgeDown.t < 350) {   // double-click on the edge: fitted width
      col.width = null;
      ctl.notify('width');
      lastEdgeDown = { c: -1, t: 0 };
      layoutColumns(); sizeSpacer(); requestDraw();
      return;
    }
    lastEdgeDown = { c, t: now };
    resizing = { col, startX: e.clientX, startW: colW(c) };
    document.body.style.cursor = 'col-resize';
  });
  const onResizeMove = e => {
    if (!resizing) return;
    resizing.col.width = Math.round(Math.min(2000, Math.max(30, resizing.startW + e.clientX - resizing.startX)));
    layoutColumns(); sizeSpacer(); requestDraw();
  };
  const onResizeEnd = () => {
    if (!resizing) return;
    resizing = null;
    ctl.notify('width');
    document.body.style.cursor = '';
  };
  window.addEventListener('mousemove', onResizeMove);
  window.addEventListener('mouseup', onResizeEnd);

  // ----- column reordering: drag a header sideways and drop it -----
  let colDrag = null;   // { from, startX, curX, active }
  // Column boundary (0..n) nearest the pointer: the dragged column is inserted there
  function dropBoundary(clientX) {
    const rect = scroller.getBoundingClientRect();
    const dx = clientX - rect.left - rowHeadW() + scroller.scrollLeft;
    const c = colAtDataX(dx);
    if (c < 0) return dx < 0 ? 0 : numCols();
    return dx < (colLeft[c] + colLeft[c + 1]) / 2 ? c : c + 1;
  }
  const onDragMove = e => {
    if (!colDrag) return;
    if (!colDrag.active) {
      if (Math.abs(e.clientX - colDrag.startX) < 5) return;
      colDrag.active = true;
      swallowClick = true;   // a drag must not also sort the column
      document.body.style.cursor = 'grabbing';
      ctl.setHover(-1, -1);
    }
    colDrag.curX = e.clientX;
    // Auto-scroll near the left / right edge so a column can travel far
    const rect = scroller.getBoundingClientRect();
    if (e.clientX > rect.right - 40) scroller.scrollLeft += 20;
    else if (e.clientX < rect.left + rowHeadW() + 40) scroller.scrollLeft -= 20;
    requestDraw();
  };
  const onDragEnd = e => {
    if (!colDrag) return;
    const d = colDrag;
    colDrag = null;
    if (!d.active) return;   // just a click: the click handler sorts as usual
    document.body.style.cursor = '';
    const b = dropBoundary(e.clientX);
    const to = b > d.from ? b - 1 : b;   // index after removing the dragged column
    if (to !== d.from) ctl.moveColumn(d.from, to);
    else requestDraw();
  };
  window.addEventListener('mousemove', onDragMove);
  window.addEventListener('mouseup', onDragEnd);

  scroller.addEventListener('mousemove', e => {
    if (resizing || (colDrag && colDrag.active)) return;
    const c = cellAt(e);
    scroller.style.cursor = edgeAt(e) >= 0 ? 'col-resize'
      : c.header || c.corner || c.totals || c.group || (c.rowHeader && c.y >= 0) || buttonAt(e, c) !== null ? 'pointer' : '';
    if (!!c.corner !== cornerHover) { cornerHover = !!c.corner; requestDraw(); }
    if (ctl.model) ctl.setHover(c.x, c.y, { totals: !!c.totals, group: c.group || null });
  });
  scroller.addEventListener('mouseleave', () => {
    cornerHover = false;
    if (ctl.model) ctl.setHover(-1, -1);
    requestDraw();
  });
  // Right-click: on a column header opens that column's filter / sort / align box; on the corner, the options menu
  scroller.addEventListener('contextmenu', e => {
    const c = cellAt(e);
    if (!c.header && !c.corner && !c.totals) return;   // data cells keep the browser's own menu
    e.preventDefault();
    if (c.corner) ctl.openColumns(e.clientX, e.clientY);
    else if (c.totals) ctl.openTotal(c.x, e.clientX, e.clientY);
    else ctl.openFilter(c.x, e.clientX, e.clientY);
  });
  scroller.addEventListener('click', e => {
    if (swallowClick) { swallowClick = false; return; }   // end of a resize (or a click on an edge)
    const c = cellAt(e);
    if (c.corner) { ctl.openColumns(c.left, c.bottom); return; }
    if (c.header) { ctl.headerClick(c.x, c.left, c.bottom, e.ctrlKey || e.metaKey); return; }
    if (c.totals) { ctl.openTotal(c.x, c.left, c.bottom); return; }
    if (c.group) { ctl.closePopovers(); ctl.toggleGroup(c.group); return; }
    ctl.closePopovers();
    if (c.x < 0 || c.y < 0) return;
    ctl.select(c.x, c.y, { button: buttonAt(e, c) });
  });

  return {
    description: '<b>Canvas renderer</b>: no library; only the visible cells are drawn to one <code>&lt;canvas&gt;</code> per frame, with a capped, proportionally mapped scroll range.',
    modelChanged() { layoutColumns(); scroller.scrollLeft = 0; },
    columnsChanged() { layoutColumns(); sizeSpacer(); requestDraw(); },
    // The header row was switched on or off (headers option)
    headersChanged() { HEAD_H = ctl.headers ? HEAD_FULL : 0; sizeSpacer(); setVY(vy); requestDraw(); },
    // The totals row was switched on / off or moved (ctl.totals)
    totalsChanged() { sizeSpacer(); setVY(vy); requestDraw(); },
    rowsChanged(keepRow) {
      layoutColumns();   // a group column's width follows its groups (fitted widths are cached, so this is cheap)
      sizeSpacer(); setVY(ctl.view.lineLowerBound(keepRow) * ROW_H); requestDraw();
    },
    // Groups opened / closed: the lines changed but nothing above the clicked one moved
    linesChanged() { sizeSpacer(); setVY(vy); requestDraw(); },
    scrollToIndex(i) { setVY(i * ROW_H); },   // i: a line (= view position when not grouped)
    topRow() {
      const v = ctl.view;
      if (!v || !v.lineCount()) return 0;
      const line = Math.min(v.lineCount() - 1, Math.floor(vy / ROW_H)), g = v.groupAtLine(line);
      return g ? v.at(g.start) : v.lineAt(line);   // on a group header: that group's first row
    },
    redraw: requestDraw,
    destroy() {
      ro.disconnect();
      window.removeEventListener('mousemove', onResizeMove);
      window.removeEventListener('mouseup', onResizeEnd);
      window.removeEventListener('mousemove', onDragMove);
      window.removeEventListener('mouseup', onDragEnd);
      window.removeEventListener('mousemove', onRowDragMove);
      window.removeEventListener('mouseup', onRowDragEnd);
      scroller.remove();
      canvas.remove();
    },
  };
});

// ===========================================================================
// The widget: DOM, side panel, popovers, loading
// ===========================================================================
const TEMPLATE = `
<div class="tt-grid" data-tt="grid">
  <div class="tt-empty" data-tt="empty" hidden>No rows match the filters.</div>
  <div class="tt-busy" data-tt="busy" hidden>Loading…</div>
  <div class="tt-toast" data-tt="toast" hidden></div>
</div>
<aside class="tt-panel" data-tt="panel">
  <h1 data-tt="title"></h1>
  <div data-tt="sizeInfo"></div>
  <div class="tt-row" data-tt="loadRow"><button data-tt="loadCsv">Load CSV…</button><span class="tt-hint">or drop a file on the table</span></div>
  <input type="file" data-tt="csvFile" accept=".csv,text/csv,text/plain" hidden>
  <section>
    <h2>Jump to row</h2>
    <form class="tt-row" data-tt="jumpForm">
      <input type="text" data-tt="jumpInput" placeholder="e.g. 123456" inputmode="numeric">
      <button type="submit">Go</button>
    </form>
  </section>
  <section>
    <h2>Filter &amp; sort</h2>
    <div class="tt-hint" data-tt="filterInfo"></div>
    <div class="tt-chips" data-tt="filterChips"></div>
    <label class="tt-row tt-hidden-toggle" data-tt="hiddenToggle" hidden><input type="checkbox" data-tt="showHidden"> <span data-tt="hiddenLabel"></span></label>
  </section>
  <section>
    <h2>Display</h2>
    <label class="tt-row"><input type="checkbox" data-tt="heat" checked> Heatmap colouring</label>
  </section>
  <section>
    <h2>Hover</h2>
    <div class="tt-hint" data-tt="hoverInfo">Move over a cell.</div>
  </section>
  <section>
    <h2>Selection</h2>
    <div class="tt-hint" data-tt="details">Click a cell, or a row number to select rows.</div>
  </section>
  <section data-tt="clickResultSec" hidden>
    <h2>Click result</h2>
    <div class="tt-click-result" data-tt="clickResult"></div>
  </section>
  <section class="tt-hint" data-tt="footer"></section>
</aside>
<div class="tt-pop" data-tt="filterPop" hidden>
  <div class="tt-pop-title" data-tt="fpTitle"></div>
  <div class="tt-row tt-sort" data-tt="fpSort"><span class="tt-hint">Sort</span><button data-sort="1">▲ Ascending</button><button data-sort="-1">▼ Descending</button><button data-sort="0">None</button></div>
  <div class="tt-row tt-sort" data-tt="fpAlign"><span class="tt-hint">Align</span><button data-align="left">Left</button><button data-align="center">Centre</button><button data-align="right">Right</button></div>
  <div class="tt-row tt-sort tt-total" data-tt="fpTotal"></div>
  <div class="tt-row tt-sort" data-tt="fpGroup"></div>
  <input type="text" data-tt="filterInput" autocomplete="off" spellcheck="false">
  <div class="tt-sugg" data-tt="fpSugg" hidden></div>
  <div class="tt-pop-err" data-tt="fpErr"></div>
  <div class="tt-pop-help" data-tt="fpHelp"></div>
  <div class="tt-row tt-end"><button data-tt="fpClear">Clear</button><button data-tt="fpDone">Done</button></div>
</div>
<div class="tt-pop tt-col-pop" data-tt="colPop" hidden>
  <div class="tt-pop-title">View</div>
  <div class="tt-opts">
    <label class="tt-row"><input type="checkbox" data-tt="optPanel"> Side panel</label>
    <label class="tt-row"><input type="checkbox" data-tt="optRowNums"> Row numbers <span class="tt-hint" style="margin-left:auto">menu stays on ☰</span></label>
    <label class="tt-row"><input type="checkbox" data-tt="optHeat"> Heatmap colouring</label>
    <label class="tt-row">Totals row <select data-tt="optTotals"><option value="">Off</option><option value="top">Top</option><option value="bottom">Bottom</option></select></label>
    <label class="tt-row" data-tt="optHiddenRow"><input type="checkbox" data-tt="optHidden"> <span data-tt="optHiddenLabel"></span></label>
    <label class="tt-row" data-tt="optRendererRow">Renderer <select data-tt="optRenderer"></select></label>
  </div>
  <div class="tt-pop-title">Download CSV</div>
  <div class="tt-opts">
    <div class="tt-row tt-dl"><button data-tt="dlAll"></button><button data-tt="dlView"></button><button data-tt="dlSel"></button></div>
    <label class="tt-row"><input type="checkbox" data-tt="dlAllCols" checked> Include hidden columns</label>
  </div>
  <div class="tt-pop-title tt-between">Columns <span data-tt="colCount"></span></div>
  <input type="text" data-tt="colSearch" placeholder="Search columns" autocomplete="off" spellcheck="false">
  <div class="tt-col-list" data-tt="colList"></div>
  <div class="tt-row tt-between"><span><button data-tt="colAll">Show all</button> <button data-tt="colReset">Reset</button></span><button data-tt="colDone">Done</button></div>
</div>`;

function describeSource(source) {
  if (typeof source === 'string') return { get: () => source, label: 'CSV text', phase: 'Reading CSV…' };
  if (typeof source === 'function') return { get: source, label: 'custom source', phase: 'Loading…' };
  source = source || {};
  if (source.csv != null) return { get: () => source.csv, label: source.label || 'CSV text', phase: 'Reading CSV…' };
  // Already-parsed columns ({ columns, rowCount }, the shape parseCsv returns), or a function giving them
  if (source.data) return { get: () => (typeof source.data === 'function' ? source.data() : source.data), label: source.label || 'data', phase: 'Loading…' };
  if (source.file) return { get: () => source.file.text(), label: source.label || source.file.name, phase: `Reading ${source.file.name}…` };
  if (source.url) {
    return {
      get: () => fetch(source.url).then(r => { if (!r.ok) throw new Error(`${r.status} ${r.statusText}`); return r.text(); }),
      label: source.label || source.url.split('/').pop(),
      phase: 'Downloading…',
    };
  }
  const s = { rows: 300_000, cols: 40, seed: 12345, ...(source.sample || {}) };
  return {
    get: () => generateCsv(s.rows, s.cols, s.seed),
    label: source.label || `generated sample (${fmt(s.rows)} × ${s.cols})`,
    phase: `Generating ${fmt(s.rows)} × ${s.cols} sample…`,
  };
}

async function create(container, options = {}) {
  const opts = { renderer: 'canvas', title: 'Table', panel: true, fileLoading: true, ...options };
  const root = document.createElement('div');
  root.className = 'tt-root';
  root.innerHTML = TEMPLATE;
  container.appendChild(root);
  const el = {};
  root.querySelectorAll('[data-tt]').forEach(n => { el[n.dataset.tt] = n; });
  el.title.textContent = opts.title;
  el.panel.hidden = !opts.panel;
  // fileLoading: true | false | { button: bool, drop: bool }
  const fl = opts.fileLoading;
  const allowLoadButton = fl === true || (!!fl && fl.button !== false);
  const allowDrop = fl === true || (!!fl && fl.drop !== false);
  el.loadRow.hidden = !allowLoadButton;
  el.loadRow.querySelector('.tt-hint').textContent = allowDrop ? 'or drop a CSV file onto the table' : '';

  const ctl = {
    src: null, model: null, view: null, heat: true,
    hover: { x: -1, y: -1 },   // x = display column index, y = data row
    sel: { x: -1, y: -1 },
    info: {},
    transform: opts.transform || null,
    rowNumbers: opts.rowNumbers !== false,
    headers: opts.headers !== false,   // false: no column header row in the table (edit from outside instead)
    totals: opts.totals === 'top' || opts.totals === 'bottom' ? opts.totals : null,   // the totals row, if any
    groupKey: opts.groupBy || (opts.transform && opts.transform.groupBy) || null,   // column the rows are grouped by
    // Which header gestures are on: sort (click), filter / align (the column box), columns (move + the menu's
    // column list), resize (edge drag). Turn some off to do that part from an external UI instead.
    headerControls: { sort: true, filter: true, align: true, columns: true, resize: true, ...(opts.headerControls || {}) },
  };

  // ---------- change events (keep an external UI in step) ----------
  const listeners = new Set();
  function emit(type) {
    for (const fn of listeners) { try { fn({ type }); } catch (err) { console.error('[tall-table] onChange listener:', err); } }
  }
  ctl.notify = emit;
  root.classList.toggle('tt-no-rownums', !ctl.rowNumbers);
  let renderer = null, rendererName = null, rendererReady = Promise.resolve();
  const statsCache = new Map();

  const busy = async text => { el.busy.textContent = text; el.busy.hidden = false; await nextFrame(); };
  const idle = () => { el.busy.hidden = true; };

  async function rowsChanged(keepRow) {
    el.empty.hidden = ctl.view.count() > 0;
    if (ctl.rowSelCount) renderRowSelection();   // "N currently shown" follows filters
    await renderer.rowsChanged(keepRow);
  }

  // ---------- renderer ----------
  async function setRenderer(name) {
    const factory = RENDERERS[name];
    if (!factory) throw new Error(`Unknown renderer "${name}". Available: ${Object.keys(RENDERERS).join(', ')}`);
    const keep = renderer && ctl.model ? renderer.topRow() : 0;
    if (renderer) renderer.destroy();
    renderer = null;
    renderer = await factory(el.grid, ctl, opts);
    rendererName = name;
    el.footer.innerHTML = renderer.description || '';
    if (ctl.model) {
      renderer.modelChanged();
      await rowsChanged(keep);
    }
  }

  // ---------- loading ----------
  // options.transform: a config for this data (replacing the current one); omit it to keep the current config
  async function load(source, options = {}) {
    const before = { src: ctl.src, info: ctl.info, transform: ctl.transform, groupKey: ctl.groupKey };
    if ('transform' in options) {   // a new config brings its own grouping (transform.groupBy), if any
      ctl.transform = options.transform || null;
      ctl.groupKey = (ctl.transform && ctl.transform.groupBy) || null;
    }
    const { get, label, phase } = describeSource(source);
    await busy(phase);
    try {
      const t0 = performance.now();
      const got = await get();
      const tText = performance.now() - t0;
      if (got && typeof got === 'object' && Array.isArray(got.columns)) {   // parsed already
        ctl.src = got;
        ctl.info = { sourceLabel: label, bytes: null, tText, tParse: 0 };
      } else {
        const text = String(got);
        await busy(`Parsing ${(text.length / 1e6).toFixed(1)} MB…`);
        ctl.src = parseCsv(text);
        ctl.info = { sourceLabel: label, bytes: text.length, tText, tParse: ctl.src.ms };
      }
      await busy('Building table…');
      await applyModel();
    } catch (err) {
      // Shown in the panel rather than alert(), which would block the page; the previous data and config stay
      Object.assign(ctl, before);
      showError(`Could not load ${label}: ${err.message}${source && source.url ? ' (for a URL, the server must allow cross-origin requests, including on any redirect)' : ''}`);
    } finally {
      idle();
    }
  }

  function showError(message) {
    el.sizeInfo.querySelector('.tt-load-error')?.remove();
    const div = document.createElement('div');
    div.className = 'tt-err tt-load-error';
    div.textContent = message;
    el.sizeInfo.prepend(div);
    if (opts.panel) setPanel(true);   // make sure it can be seen (unless the page turned the panel off)
    console.error('[tall-table]', message);
  }

  async function setTransform(transform) {
    ctl.transform = transform || null;
    if (ctl.transform && ctl.transform.groupBy) ctl.groupKey = ctl.transform.groupBy;
    if (!ctl.src) return;
    await busy('Applying transform…');
    try { await applyModel(); } finally { idle(); }
  }

  async function applyModel() {
    await rendererReady;   // a registered renderer may set itself up asynchronously
    let model, transformError = '';
    try { model = buildModel(ctl.src, ctl.transform); }
    catch (err) { transformError = err.message; model = buildModel(ctl.src, null); }
    ctl.model = model;
    ctl.view = createView(model);
    // Keep grouping by the same column (by key) when the data or config is reloaded
    const gcol = ctl.groupKey ? model.allColumns.find(c => c.key === ctl.groupKey) || model.allColumns.find(c => c.label === ctl.groupKey) : null;
    if (gcol) { ctl.view.group = { col: gcol, open: new Set() }; ctl.view.apply(); }
    ctl.hover = { x: -1, y: -1 };
    ctl.sel = { x: -1, y: -1 };
    ctl.rowSel = null; ctl.rowSelCount = 0; rowAnchor = -1; dragBase = null;
    Object.assign(ctl.info, {
      tModel: model.ms, transformError,
      transformLabel: transformError ? 'not applied' : ctl.transform ? 'from page config' : 'none: all columns and rows',
    });
    statsCache.clear();
    closePopovers();
    renderInfo();
    renderFilterPanel();
    el.details.className = 'tt-hint';
    el.details.textContent = 'Click a cell, or a row number to select rows.';
    el.clickResultSec.hidden = true;
    renderer.modelChanged();
    await rowsChanged(0);
    emit('load');
  }

  function renderInfo() {
    const { model, info } = ctl;
    el.sizeInfo.innerHTML = `
      <div class="tt-stats">
        <span>Source</span><span>${esc(info.sourceLabel)}</span>
        <span>Size</span><span>${fmt(model.numRows)} rows × ${fmt(model.src.columns.length)} cols${info.bytes == null ? '' : ` · ${(info.bytes / 1e6).toFixed(1)} MB CSV`}</span>
        <span>Load / parse</span><span>${ms(info.tText)} / ${ms(info.tParse)}</span>
        <span>Transform</span><span>${esc(info.transformLabel)} · ${ms(info.tModel)}</span>
        <span>Showing</span><span>${model.columns.length} of ${model.allColumns.length} columns</span>
        <span>Renderer</span><span>${esc(rendererName)}</span>
      </div>
      ${info.transformError ? `<div class="tt-note">The page's transform doesn't fit this data, so every column and row is shown. <span class="tt-hint">(${esc(info.transformError)})</span></div>` : ''}`;
  }

  el.loadCsv.addEventListener('click', () => el.csvFile.click());
  el.csvFile.addEventListener('change', e => {
    const file = e.target.files[0];
    if (file) load({ file }, { transform: null });   // any CSV: show all its columns
    e.target.value = '';
  });
  // Drag a CSV file anywhere onto the widget (table or panel) to load it
  const draggingFiles = e => allowDrop && e.dataTransfer && [...e.dataTransfer.types].includes('Files');
  root.addEventListener('dragover', e => {
    if (!draggingFiles(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    root.classList.add('tt-dropping');
  });
  root.addEventListener('dragleave', e => { if (!root.contains(e.relatedTarget)) root.classList.remove('tt-dropping'); });
  root.addEventListener('drop', e => {
    if (!draggingFiles(e)) return;
    e.preventDefault();
    root.classList.remove('tt-dropping');
    const file = e.dataTransfer.files[0];
    if (file) load({ file }, { transform: null });
  });

  // ---------- hover, selection, details, callbacks ----------
  // totals: the pointer is on the totals row (y is then -1)
  // where: { totals } on the totals row, { group } on a group's header line (y is -1 for both)
  ctl.setHover = (x, y, { totals = false, group = null } = {}) => {
    if (x === ctl.hover.x && y === ctl.hover.y && totals === !!ctl.hover.totals && group === (ctl.hover.group || null)) return;
    const rowChanged = y !== ctl.hover.y;
    ctl.hover = { x, y, totals, group };
    renderer.redraw();
    if (rowChanged) emit('hover');   // table.hoveredRow changed (not on every cell)
    const cols = ctl.model.columns;
    if (totals && x >= 0) {
      const t = totalOf(cols[x]);
      el.hoverInfo.textContent = `Totals · ${cols[x].label} · ${t.describe}${t.text ? `: ${t.text}` : ''}`;
      return;
    }
    if (group) {
      const n = group.end - group.start, col = x >= 0 ? cols[x] : null;
      const t = col && col !== ctl.view.group.col ? groupTotal(col, group) : null;
      el.hoverInfo.textContent = `${ctl.view.group.col.label} = ${group.name || '(blank)'} · ${fmt(n)} row${n === 1 ? '' : 's'}`
        + (t && t.text ? ` · ${col.label} ${t.describe.replace(/ of .*/, '')}: ${t.text}` : '') + ` · click to ${group.open ? 'close' : 'open'}`;
      return;
    }
    el.hoverInfo.textContent = x >= 0 && y >= 0
      ? `row ${fmt(y)} · ${cols[x].label} · ${cols[x].display(y)}`
      : x >= 0 ? cols[x].label : y >= 0 ? `Row ${fmt(y)}` : 'Move over a cell.';
  };

  // ---------- totals row ----------
  // Totals are worked out per column when first drawn, then cached until the shown rows change
  let totalsCache = { view: null, rows: undefined, byCol: new Map() };
  function totalOf(col) {
    const v = ctl.view;
    if (totalsCache.view !== v || totalsCache.rows !== v.rows) totalsCache = { view: v, rows: v.rows, byCol: new Map() };
    let t = totalsCache.byCol.get(col);
    if (!t) { t = columnTotal(col, v); totalsCache.byCol.set(col, t); }
    return t;
  }
  ctl.totalText = col => totalOf(col).text;

  // ---------- grouping ----------
  // A group's subtotal for a column (same kind of total as the totals row), cached on the group
  function groupTotal(col, g) {
    let t = g.totals.get(col);
    if (!t) {
      const rows = ctl.view.rows;
      t = columnTotal(col, { count: () => g.end - g.start, at: p => rows[g.start + p] });
      g.totals.set(col, t);
    }
    return t;
  }
  ctl.groupTotalText = (col, g) => groupTotal(col, g).text;

  ctl.toggleGroup = g => setGroupOpen(g, !g.open);
  function setGroupOpen(g, open) {
    ctl.view.setGroupOpen(g, open);
    linesChanged();
  }
  function linesChanged() {
    if (renderer.linesChanged) renderer.linesChanged(); else renderer.rowsChanged(renderer.topRow());
    emit('group');
  }

  // Group by a column (or null to stop); groups start collapsed
  async function setGroupBy(col) {
    const v = ctl.view;
    if ((v.group ? v.group.col : null) === (col || null)) return;
    v.group = col ? { col, open: new Set() } : null;
    ctl.groupKey = col ? col.key : null;
    v.apply();
    renderFilterPanel();
    await rowsChanged(v.count() ? v.at(0) : 0);
    renderer.scrollToIndex(0);
    if (!el.filterPop.hidden) updateGroupButtons();
    emit('group');
  }

  async function setTotals(position) {
    ctl.totals = position === 'top' || position === 'bottom' ? position : null;
    el.optTotals.value = ctl.totals || '';
    if (renderer && renderer.totalsChanged) await renderer.totalsChanged();
    emit('totals');
  }
  el.optTotals.addEventListener('change', e => setTotals(e.target.value));

  // mode: one of TOTALS[col.type], a function, null (none), or 'default' (back to the config's)
  function setColumnTotal(col, mode) {
    col.total = mode === 'default' ? col.defaultTotal : mode || null;
    totalsCache.byCol.delete(col);
    for (const g of ctl.view.groups) g.totals.delete(col);
    updateTotalButtons();
    // Groups ordered by this column's subtotal need re-ordering
    const v = ctl.view;
    if (v.group && v.sort && v.sort.col === col) viewChanged();
    else if (v.group && v.group.col === col) renderer.columnsChanged();   // its width depends on the subtotal shown
    else renderer.redraw();
    emit('totals');
  }

  // extra: { button } when the click landed on a button drawn by the column's render callback
  ctl.select = (x, y, extra = {}) => {
    clearRowSelection(false);
    ctl.sel = { x, y };
    renderer.redraw();
    renderDetails();
    runCallback(x, y, extra);
  };

  // ---------- custom cells (render / draw callbacks) ----------
  // What render and draw get: the cell's own value plus the whole source row (built only if used)
  ctl.cellInfo = (col, row) => {
    const model = ctl.model;
    return { column: col.label, value: col.raw(row), display: col.display(row), rowIndex: row, get row() { return model.rowObject(row); } };
  };
  // A column's render callback, normalised to { text, color, background, font, button: { label, color, background } | null }
  ctl.cellLook = (col, row) => {
    const cell = ctl.cellInfo(col, row);
    return lookFrom(col, 'render', () => col.render(cell), cell.display);
  };
  // Its renderGroup callback for a group's header line (same result shape, without buttons)
  ctl.groupLook = (col, g) => {
    const t = groupTotal(col, g), rows = ctl.view.rows;
    const info = {
      column: col.label, name: g.name, value: g.value, count: g.end - g.start, open: g.open,
      subtotal: t.value, subtotalText: t.text,
      get rows() { return rows.subarray(g.start, g.end); },   // the group's data rows
    };
    const fallback = col === ctl.view.group.col ? g.name || '(blank)' : t.text;
    const look = lookFrom(col, 'renderGroup', () => col.renderGroup(info), fallback);
    look.button = null;
    return look;
  };
  function lookFrom(col, what, call, fallback) {
    let out;
    try { out = call(); }
    catch (err) {
      const flag = '_' + what + 'Err';
      if (!col[flag]) { col[flag] = true; console.error(`[tall-table] ${what} for "${col.label}":`, err); }
      return { text: '⚠', font: '', button: null };
    }
    if (out == null) return { text: fallback, font: '', button: null };
    if (typeof out !== 'object') return { text: String(out), font: '', button: null };
    const b = out.button;
    return {
      text: out.text != null ? String(out.text) : b ? '' : fallback,
      color: out.color, background: out.background,
      font: (out.italic ? 'italic ' : '') + (out.bold ? '600 ' : ''),
      strike: !!out.strike,
      button: b == null || b === false || b === '' ? null
        : typeof b === 'object' ? { label: String(b.label ?? ''), color: b.color, background: b.background } : { label: String(b) },
    };
  }

  // ---------- whole-row selection (click / drag the row numbers) ----------
  // Stored as a mask over data rows, so it survives sorting and filtering. Ranges follow the current
  // display order: shift-selecting in a sorted table selects what you see between the two rows.
  ctl.rowSel = null;        // Uint8Array(numRows) or null
  ctl.rowSelCount = 0;
  let rowAnchor = -1;       // data row a shift-click or drag range starts from
  let dragBase = null;      // selection when a Ctrl+drag started, so the range adds to it
  ctl.isRowSelected = row => !!(ctl.rowSel && ctl.rowSel[row]);

  function setRowsInRange(a, b, on) {   // lines a..b inclusive (rows inside closed groups are not included)
    const v = ctl.view;
    for (let p = Math.min(a, b), end = Math.max(a, b); p <= end; p++) {
      const r = v.lineAt(p);
      if (r < 0) continue;   // a group header
      if (!!ctl.rowSel[r] !== on) { ctl.rowSel[r] = on ? 1 : 0; ctl.rowSelCount += on ? 1 : -1; }
    }
  }
  function rowSelectionChanged() {
    renderer.redraw();
    renderRowSelection();
    emit('selection');
  }

  // Click on a row number. shift: range from the anchor; toggle (Ctrl/⌘): add/remove instead of replace
  ctl.rowClick = (row, { shift = false, toggle = false } = {}) => {
    const m = ctl.model, v = ctl.view;
    ctl.sel = { x: -1, y: -1 };
    if (!ctl.rowSel) ctl.rowSel = new Uint8Array(m.numRows);
    const pa = v.lineOf(rowAnchor), pb = v.lineOf(row);
    if (shift && pa >= 0 && pb >= 0) {
      if (!toggle) { ctl.rowSel.fill(0); ctl.rowSelCount = 0; }
      setRowsInRange(pa, pb, true);
    } else if (toggle) {
      setRowsInRange(pb, pb, !ctl.rowSel[row]);
      rowAnchor = row;
    } else {
      ctl.rowSel.fill(0); ctl.rowSelCount = 0;
      setRowsInRange(pb, pb, true);
      rowAnchor = row;
    }
    dragBase = toggle ? ctl.rowSel.slice() : null;
    rowSelectionChanged();
  };

  // Dragging over the row numbers: the selection becomes anchor..row (added to what was there with Ctrl)
  ctl.rowDragTo = row => {
    const v = ctl.view, pa = v.lineOf(rowAnchor), pb = v.lineOf(row);
    if (pa < 0 || pb < 0 || !ctl.rowSel) return;
    if (dragBase) { ctl.rowSel.set(dragBase); ctl.rowSelCount = dragBase.reduce((s, b) => s + b, 0); }
    else { ctl.rowSel.fill(0); ctl.rowSelCount = 0; }
    setRowsInRange(pa, pb, true);
    rowSelectionChanged();
  };

  function clearRowSelection(render = true) {
    if (!ctl.rowSelCount && !ctl.rowSel) return;
    ctl.rowSel = null;
    ctl.rowSelCount = 0;
    dragBase = null;
    if (render) rowSelectionChanged(); else emit('selection');
  }

  // Selected rows in display order (only those currently shown)
  function selectedRowsInView() {
    const v = ctl.view, out = [];
    if (!ctl.rowSel) return out;
    for (let p = 0, n = v.count(); p < n; p++) { const r = v.at(p); if (ctl.rowSel[r]) out.push(r); }
    return out;
  }

  function renderRowSelection() {
    if (!ctl.rowSelCount) {
      if (ctl.sel.x < 0) { el.details.className = 'tt-hint'; el.details.textContent = 'Click a cell, or a row number to select rows.'; }
      return;
    }
    const shown = selectedRowsInView();
    const one = ctl.rowSelCount === 1 && shown.length === 1 ? shown[0] : -1;
    el.details.className = '';
    el.details.innerHTML = `
      <div><b>${fmt(ctl.rowSelCount)}</b> row${ctl.rowSelCount === 1 ? '' : 's'} selected${shown.length !== ctl.rowSelCount ? ` <span class="tt-hint">· ${fmt(shown.length)} currently shown</span>` : ''}</div>
      <div class="tt-row" style="margin-top:6px"><button data-tt-act="copySel" title="Ctrl+C: CSV with headers, shown columns only">⧉ Copy</button><button data-tt-act="dlSel">⤓ Download selected rows</button><button data-tt-act="clearSel">Clear</button></div>
      ${one >= 0 ? `<div class="tt-rowdata"><div class="tt-hint">Row ${fmt(one)}</div><table class="tt-kv">
        ${Object.entries(ctl.model.rowObject(one)).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${v == null ? '<span class="tt-hint">–</span>' : esc(v)}</td></tr>`).join('')}
      </table></div>` : `<div class="tt-hint" style="margin-top:6px">Shift+click a row number for a range, Ctrl+click to add or remove rows, Ctrl+C to copy, Esc to clear.</div>`}`;
  }
  el.details.addEventListener('click', e => {
    const act = e.target.closest('[data-tt-act]')?.dataset.ttAct;
    if (act === 'dlSel') downloadCsv({ rows: 'selected', columns: el.dlAllCols.checked ? 'all' : 'shown' });
    else if (act === 'clearSel') clearRowSelection();
    else if (act === 'copySel') copySelection();
  });
  root.addEventListener('keydown', e => {
    if (e.target.closest('input, select, textarea')) return;   // normal behaviour in text boxes
    if (e.key === 'Escape' && ctl.rowSelCount) clearRowSelection();
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && e.key.toLowerCase() === 'c' && (ctl.rowSelCount || ctl.sel.x >= 0)) {
      e.preventDefault();
      copySelection();
    }
  });

  // ---------- copy (Ctrl/⌘+C) ----------
  // Selected rows: CSV with a header line, shown columns only, in display order, values as displayed.
  // Otherwise the selected cell's value as displayed. Returns the text that was copied (or null).
  async function copySelection() {
    let text = null, what = '';
    if (ctl.rowSelCount) {
      const { parts, rowCount } = csvParts({ rows: 'selected', columns: 'shown' });
      if (!rowCount) { toast('None of the selected rows are shown'); return null; }
      text = parts.join('');
      what = `${fmt(rowCount)} row${rowCount === 1 ? '' : 's'} as CSV (${ctl.model.columns.length} columns + header)`;
    } else if (ctl.sel.x >= 0 && ctl.sel.y >= 0) {
      const col = ctl.model.columns[ctl.sel.x];
      text = col.display(ctl.sel.y);
      what = `"${text.length > 40 ? text.slice(0, 40) + '…' : text}"`;
    }
    if (text == null) return null;
    const ok = await writeClipboard(text);
    toast(ok ? `Copied ${what}` : 'Could not copy to the clipboard');
    return ok ? text : null;
  }

  async function writeClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fallback (older browsers, or no clipboard permission): copy from a temporary text area
      const focused = document.activeElement, ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta);
      ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch { ok = false; }
      ta.remove();
      if (focused && focused.focus) focused.focus({ preventScroll: true });
      return ok;
    }
  }

  let toastTimer = 0;
  function toast(message) {
    el.toast.textContent = message;
    el.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.toast.hidden = true; }, 1800);
  }

  function columnStats(col) {
    if (statsCache.has(col)) return statsCache.get(col);
    let html;
    if (col.type === 'number') {
      const d = col.data, f = v => (v === v && isFinite(v)
        ? (col.formatValue ? col.formatValue(v) : col.decimals ? v.toFixed(col.decimals) : String(Math.round(v * 100) / 100)) : '–');
      html = `min ${f(d.min)} · max ${f(d.max)} · mean ${f(d.mean)}${d.count < ctl.model.numRows ? ` · ${fmt(ctl.model.numRows - d.count)} empty` : ''}`;
    } else {
      const counts = new Uint32Array(col.data.dict.length);
      for (const c of col.data.codes) counts[c]++;
      const top = [...counts].map((n, i) => [i, n]).filter(([, n]) => n).sort((a, b) => b[1] - a[1]);
      const n = ctl.model.numRows;
      html = top.slice(0, 5).map(([i, k]) => `${esc(col.data.dict[i] || '(empty)')} ${(100 * k / n).toFixed(1)}%`).join(' · ')
        + (top.length > 5 ? ` · +${fmt(top.length - 5)} more` : '');
    }
    statsCache.set(col, html);
    return html;
  }

  function renderDetails() {
    const { x, y } = ctl.sel;
    if (x < 0 || y < 0) return;
    const col = ctl.model.columns[x];
    const colors = ctl.heat && col.heat ? col.colors(y) : null;
    const row = ctl.model.rowObject(y);
    const hiddenNote = ctl.view.isHiddenRow(y) ? ' <span class="tt-hint">(hidden by transform)</span>' : '';
    el.details.className = '';
    el.details.innerHTML = `<table class="tt-kv">
        <tr><td>Row</td><td>${fmt(y)}${hiddenNote}</td></tr>
        <tr><td>Column</td><td>${esc(col.label)} <span class="tt-hint">(${col.type}${col.computed ? ', computed' : ''})</span></td></tr>
        <tr><td>Value</td><td>${colors ? `<span class="tt-swatch" style="background:${colors[0]}"></span> ` : ''}${esc(col.display(y))}</td></tr>
        <tr><td>Column stats</td><td>${columnStats(col)}</td></tr>
        ${col.heat ? `<tr><td>Colour scale</td><td>${esc(col.heatDescription)}</td></tr>` : ''}
      </table>
      <div class="tt-rowdata"><div class="tt-hint">Source row</div><table class="tt-kv">
        ${Object.entries(row).map(([k, v]) => `<tr${k === col.sourceName ? ' class="tt-cur"' : ''}><td>${esc(k)}</td><td>${v == null ? '<span class="tt-hint">–</span>' : esc(v)}</td></tr>`).join('')}
      </table></div>`;
  }

  // Column onClick takes priority over the transform-wide onCellClick
  function runCallback(x, y, extra = {}) {
    const { model } = ctl;
    const col = model.columns[x];
    const fn = col.onClick || model.onCellClick;
    if (!fn) { el.clickResultSec.hidden = true; return; }
    const payload = {
      column: col.label, columnIndex: x, source: col.sourceName,
      value: col.raw(y), display: col.display(y), rowIndex: y,
      button: extra.button ?? null,   // label of the clicked button (render: { button }), else null
      row: model.rowObject(y),
      shown: Object.fromEntries(model.columns.map(c => [c.label, c.raw(y)])),
    };
    let out;
    try { out = fn(payload); }
    catch (err) { out = `<span class="tt-err">Callback error: ${esc(err.message)}</span>`; }
    if (out == null || out === '') { el.clickResultSec.hidden = true; return; }
    el.clickResultSec.hidden = false;
    el.clickResult.innerHTML = typeof out === 'string' ? out : `<pre>${esc(JSON.stringify(out, null, 2))}</pre>`;
  }

  function setHeat(on) {
    ctl.heat = !!on;
    el.heat.checked = el.optHeat.checked = ctl.heat;
    renderer.redraw();
    renderDetails();
  }
  el.heat.addEventListener('change', e => setHeat(e.target.checked));

  function setPanel(show) {
    el.panel.hidden = !show;
    el.optPanel.checked = !!show;
    if (renderer && renderer.resized) renderer.resized();
  }

  // Row numbers off: the row-header column shrinks to a slim strip whose corner (☰) still opens the menu
  async function setRowNumbers(show) {
    ctl.rowNumbers = !!show;
    el.optRowNums.checked = ctl.rowNumbers;
    root.classList.toggle('tt-no-rownums', !ctl.rowNumbers);
    if (renderer && ctl.model) await renderer.columnsChanged();
  }

  // ---------- jump to row ----------
  el.jumpForm.addEventListener('submit', async e => {
    e.preventDefault();
    const y = parseInt(el.jumpInput.value.replace(/[^0-9]/g, ''), 10);
    const v = ctl.view;
    if (!v || !Number.isFinite(y) || !v.count()) return;
    // That row, or the next one that is visible (opening its group if it is in a closed one)
    const row = v.at(Math.min(v.count() - 1, v.lowerBound(y)));
    await scrollToRow(row);
    ctl.select(ctl.sel.x >= 0 ? ctl.sel.x : 0, row);
  });

  // Scroll a data row into view, opening its group if it is in a closed one. False if filters hide it
  async function scrollToRow(row) {
    const v = ctl.view;
    if (!v || !renderer || v.indexOf(row) < 0) return false;
    if (v.group && v.lineOf(row) < 0) {
      const p = v.indexOf(row), g = v.groups.find(gr => p >= gr.start && p < gr.end);
      if (g) setGroupOpen(g, true);
    }
    await renderer.scrollToIndex(Math.max(0, v.lineOf(row) - 2));   // a couple of rows of context above it
    return true;
  }

  // ---------- popovers ----------
  function place(pop, left, top) {
    pop.style.left = Math.max(8, Math.min(left, innerWidth - pop.offsetWidth - 8)) + 'px';
    pop.style.top = Math.max(8, Math.min(top + 4, innerHeight - pop.offsetHeight - 8)) + 'px';
  }
  function closePopovers() { closeFilter(); closeColumns(); }
  ctl.closePopovers = closePopovers;
  const onDocMouseDown = e => {
    if (!el.filterPop.hidden && !el.filterPop.contains(e.target) && !el.grid.contains(e.target)) closeFilter();
    if (!el.colPop.hidden && !el.colPop.contains(e.target) && !el.grid.contains(e.target)) closeColumns();
  };
  document.addEventListener('mousedown', onDocMouseDown);

  // ---------- filter & sort popover ----------
  let popCol = null, popTimer = 0;

  // From the header: only the sections the page allows there (headerControls)
  ctl.openFilter = (x, left, top) => {
    const hc = ctl.headerControls, sections = { sort: hc.sort, filter: hc.filter, align: hc.align, total: !!ctl.totals, group: hc.sort };
    if (sections.sort || sections.filter || sections.align) openFilterFor(ctl.model.columns[x], left, top, sections);
  };
  // From the totals row: just the choice of total
  ctl.openTotal = (x, left, top) => openFilterFor(ctl.model.columns[x], left, top, { total: true });
  // sections: which parts of the box to show (the header can have some switched off via headerControls);
  // the Total buttons show while the totals row is on
  function openFilterFor(col, left, top, sections = { sort: true, filter: true, align: true, total: !!ctl.totals, group: true }) {
    closeColumns();
    popCol = col;
    el.fpSort.hidden = !sections.sort;
    el.fpAlign.hidden = !sections.align;
    el.fpTotal.hidden = !sections.total;
    el.fpGroup.hidden = !sections.group;
    updateGroupButtons();
    for (const part of [el.filterInput, el.fpHelp, el.fpErr, el.fpClear]) part.hidden = !sections.filter;
    el.fpTitle.innerHTML = `${esc(col.label)} <span>(${col.type})</span>`;
    el.fpHelp.innerHTML = FILTER_HELP[col.type];
    el.fpErr.textContent = '';
    el.filterInput.classList.remove('tt-bad');
    el.filterInput.placeholder = col.type === 'number' ? 'Filter, e.g. >10<20' : 'Filter, e.g. pass';
    el.filterInput.value = ctl.view.filters.get(col)?.text || '';
    updateSortButtons();
    updateAlignButtons();
    updateTotalButtons();
    suggIndex = -1;
    renderSuggestions();
    el.filterPop.hidden = false;
    place(el.filterPop, left, top);
    if (sections.filter) { el.filterInput.focus(); el.filterInput.select(); }
  }
  function closeFilter() { el.filterPop.hidden = true; popCol = null; }

  // Set a column's filter text; returns an error message, or null when it was valid (and applied)
  function applyFilterText(col, text) {
    try {
      const f = parseFilter(col, text);
      if (f) ctl.view.filters.set(col, f); else ctl.view.filters.delete(col);
      return null;
    } catch (err) {
      return err.message;
    }
  }

  function setFilter(col, text) {
    if (!col) return;
    const error = applyFilterText(col, text);
    el.filterInput.classList.toggle('tt-bad', !!error);
    el.fpErr.textContent = error || '';
    if (error) return;
    return viewChanged();
  }

  async function viewChanged() {
    let keep = renderer.topRow();
    const v = ctl.view;
    v.apply();
    // When sorted, "the next data row" is not a meaningful place to land: go to the top instead
    if (v.sort && v.indexOf(keep) < 0) keep = v.count() ? v.at(0) : 0;
    renderFilterPanel();
    await rowsChanged(keep);
    emit('filter');
  }

  function updateSortButtons() {
    const s = ctl.view.sort;
    for (const b of el.fpSort.querySelectorAll('[data-sort]')) {
      const dir = +b.dataset.sort;
      b.classList.toggle('tt-on', s ? s.col === popCol && s.dir === dir : dir === 0);
    }
  }
  // Text alignment for the column (applies immediately; the config sets the starting value)
  function updateAlignButtons() {
    for (const b of el.fpAlign.querySelectorAll('[data-align]')) b.classList.toggle('tt-on', !!popCol && popCol.align === b.dataset.align);
  }
  el.fpAlign.addEventListener('click', e => {
    const b = e.target.closest('[data-align]');
    if (!b || !popCol) return;
    popCol.align = b.dataset.align;
    updateAlignButtons();
    renderer.redraw();
    emit('align');
  });

  // What the column's cell in the totals row shows: the aggregates for its type, plus the config's own function
  function updateTotalButtons() {
    if (!popCol) return;
    const modes = [...TOTALS[popCol.type], ...(typeof popCol.defaultTotal === 'function' ? ['default'] : []), ''];
    const on = typeof popCol.total === 'function' ? 'default' : popCol.total || '';
    el.fpTotal.innerHTML = '<span class="tt-hint">Total</span>' + modes.map(m =>
      `<button data-total="${m}" class="${m === on ? 'tt-on' : ''}">${m === 'default' ? 'Custom' : m ? TOTAL_LABELS[m] : 'None'}</button>`).join('');
  }
  // Group the rows by this column's values (collapsible groups with subtotals), or stop grouping
  function updateGroupButtons() {
    if (!popCol) return;
    const g = ctl.view.group, mine = !!g && g.col === popCol;
    el.fpGroup.innerHTML = '<span class="tt-hint">Group</span>'
      + `<button data-group="on" class="${mine ? 'tt-on' : ''}">${mine ? 'Grouped by this' : 'Group by this'}</button>`
      + (g ? '<button data-group="off">Ungroup</button>' : '');
  }
  el.fpGroup.addEventListener('click', e => {
    const b = e.target.closest('[data-group]');
    if (b && popCol) setGroupBy(b.dataset.group === 'on' ? popCol : null);
  });

  el.fpTotal.addEventListener('click', e => {
    const b = e.target.closest('[data-total]');
    if (b && popCol) setColumnTotal(popCol, b.dataset.total);
  });

  el.fpSort.addEventListener('click', e => {
    const b = e.target.closest('[data-sort]');
    if (b && popCol) setSort(popCol, +b.dataset.sort);
  });

  // Header clicks: single click cycles the sort (▲ → ▼ → off), double click opens the filter & sort box.
  // The single-click action waits for the double-click interval so a double click doesn't sort first.
  const DBLCLICK_MS = 250;
  let pendingHeader = null;   // { x, timer }
  ctl.headerClick = (x, left, top, openNow = false) => {
    if (!ctl.headerControls.sort) { ctl.openFilter(x, left, top); return; }   // no sorting from the header: a click opens the box
    if (openNow) {   // Ctrl/⌘+click: open the box straight away
      if (pendingHeader) { clearTimeout(pendingHeader.timer); pendingHeader = null; }
      ctl.openFilter(x, left, top);
      return;
    }
    if (pendingHeader && pendingHeader.x === x) {
      clearTimeout(pendingHeader.timer);
      pendingHeader = null;
      ctl.openFilter(x, left, top);
      return;
    }
    if (pendingHeader) { clearTimeout(pendingHeader.timer); cycleSort(pendingHeader.x); }   // a different column: do that one now
    closePopovers();
    pendingHeader = { x, timer: setTimeout(() => { pendingHeader = null; cycleSort(x); }, DBLCLICK_MS) };
  };
  function cycleSort(x) {
    const col = ctl.model.columns[x], s = ctl.view.sort;
    const dir = !s || s.col !== col ? 1 : s.dir === 1 ? -1 : 0;
    return setSort(col, dir);
  }

  async function setSort(col, dir) {
    const v = ctl.view;
    v.sort = dir ? { col, dir } : null;
    const slow = dir && ctl.model.numRows > 200_000;
    if (slow) await busy('Sorting…');
    v.apply();
    if (slow) idle();
    updateSortButtons();
    renderFilterPanel();
    await rowsChanged(v.count() ? v.at(0) : 0);   // a new order starts at the top
    renderer.redraw();
    emit('sort');
  }

  function renderFilterPanel() {
    const { model, view } = ctl;
    const filtered = view.filters.size || (model.hidden && !view.showHidden);
    const s = view.sort;
    el.filterInfo.innerHTML = (filtered
      ? `Showing <b>${fmt(view.count())}</b> of ${fmt(model.numRows)} rows <span class="tt-hint">· ${Math.round(view.ms)} ms</span>`
      : `All ${fmt(model.numRows)} rows. Click a column header to sort; right-click or double-click it to filter.`)
      + (s ? `<br>Sorted by <b>${esc(s.col.label)}</b> ${s.dir > 0 ? '▲ ascending' : '▼ descending'} <span class="tt-hint">· ${Math.round(view.sortMs)} ms</span>` : '');
    el.hiddenToggle.hidden = !model.hiddenCount;
    el.showHidden.checked = view.showHidden;
    el.hiddenLabel.textContent = `Show ${fmt(model.hiddenCount)} row${model.hiddenCount === 1 ? '' : 's'} hidden by the transform`;
    const sortChip = s
      ? `<div class="tt-chip tt-chip-sort"><a data-col="${model.allColumns.indexOf(s.col)}">${s.dir > 0 ? '▲' : '▼'} ${esc(s.col.label)} <b>${s.dir > 0 ? 'ascending' : 'descending'}</b>${s.col.visible ? '' : ' <span class="tt-hint">(hidden)</span>'}</a><button data-unsort title="Remove sort">×</button></div>`
      : '';
    const g = view.group;
    const groupChip = g
      ? `<div class="tt-chip tt-chip-sort"><a data-col="${model.allColumns.indexOf(g.col)}">Grouped by <b>${esc(g.col.label)}</b> (${fmt(view.groups.length)})</a><button data-ungroup title="Stop grouping">×</button></div>`
        + `<span class="tt-group-all"><button data-groups="open">Open all</button><button data-groups="close">Close all</button></span>`
      : '';
    el.filterChips.innerHTML = groupChip + sortChip + [...view.filters.entries()].map(([col, f]) => {
      const k = model.allColumns.indexOf(col);
      return `<div class="tt-chip"><a data-col="${k}">${esc(col.label)} <b>${esc(f.text)}</b>${col.visible ? '' : ' <span class="tt-hint">(hidden)</span>'}</a><button data-clear="${k}" title="Remove">×</button></div>`;
    }).join('') + (view.filters.size > 1 ? '<button data-clear-all>Clear all filters</button>' : '');
  }

  function setShowHidden(on) {
    ctl.view.showHidden = !!on;
    el.showHidden.checked = el.optHidden.checked = !!on;
    return viewChanged();
  }
  el.showHidden.addEventListener('change', e => setShowHidden(e.target.checked));

  // ---------- value suggestions for text columns ----------
  // Most common values when empty, closest matches while typing; clicking one applies an exact filter
  // (=value, or !=value when the text starts with "!").
  // With "|" (either / or), suggestions are for the last term being typed; values already chosen drop out.
  let sugg = [], suggIndex = -1, suggNegate = false, suggEarlier = [];
  function renderSuggestions() {
    const col = popCol;
    if (!col || col.type !== 'text' || el.filterInput.hidden) { el.fpSugg.hidden = true; sugg = []; return; }
    const terms = el.filterInput.value.split('|');
    const m = /^\s*(!=|!|==|=)?(.*)$/.exec(terms.pop());
    suggEarlier = terms.map(t => t.trim()).filter(Boolean);
    const chosen = new Set(suggEarlier.map(t => t.replace(/^(!=|!|==|=)/, '').trim().toLowerCase()));
    suggNegate = !!m[1] && m[1].startsWith('!');
    sugg = suggestValues(col, m[2], 8 + chosen.size).filter(s => !chosen.has(s.value.toLowerCase())).slice(0, 8);
    suggIndex = Math.min(suggIndex, sugg.length - 1);
    if (!sugg.length) { el.fpSugg.hidden = true; return; }
    el.fpSugg.hidden = false;
    el.fpSugg.innerHTML = sugg.map((s, i) =>
      `<div class="tt-sugg-row${i === suggIndex ? ' tt-on' : ''}">
        <button type="button" data-sugg="${i}" title="${suggNegate ? 'Exclude' : 'Show only'} “${esc(s.value)}”${suggEarlier.length ? ' (with the values before it)' : ''}">
          <span>${suggNegate ? '≠ ' : ''}${esc(s.value)}</span><span class="tt-n">${fmt(s.count)}</span></button>
        <button type="button" class="tt-add" data-sugg-add="${i}" title="Add “${esc(s.value)}” and keep choosing (either / or) · Ctrl+click">+</button>
      </div>`).join('');
  }
  // add = false: use this value as the last term and apply; add = true: add it and keep the box open for more
  function pickSuggestion(i, add = false) {
    const s = sugg[i];
    if (!s) return;
    const text = [...suggEarlier, (suggNegate ? '!=' : '=') + s.value].join(' | ') + (add ? ' | ' : '');
    el.filterInput.value = text;
    clearTimeout(popTimer);
    setFilter(popCol, text);
    if (add) {
      suggIndex = -1;
      renderSuggestions();
      el.filterInput.focus();
      el.filterInput.setSelectionRange(text.length, text.length);
    } else closeFilter();
  }
  el.fpSugg.addEventListener('mousedown', e => e.preventDefault());   // keep focus in the text box
  el.fpSugg.addEventListener('click', e => {
    const add = e.target.closest('[data-sugg-add]');
    if (add) { pickSuggestion(+add.dataset.suggAdd, true); return; }
    const b = e.target.closest('[data-sugg]');
    if (b) pickSuggestion(+b.dataset.sugg, e.ctrlKey || e.metaKey);
  });

  el.filterInput.addEventListener('input', () => {
    clearTimeout(popTimer);
    const col = popCol;
    suggIndex = -1;
    renderSuggestions();
    popTimer = setTimeout(() => setFilter(col, el.filterInput.value), 150);
  });
  el.filterInput.addEventListener('keydown', e => {
    if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && sugg.length) {
      e.preventDefault();
      suggIndex = e.key === 'ArrowDown' ? Math.min(sugg.length - 1, suggIndex + 1) : Math.max(-1, suggIndex - 1);
      renderSuggestions();
      return;
    }
    if (e.key === 'Enter') {
      if (suggIndex >= 0) { pickSuggestion(suggIndex, e.ctrlKey || e.metaKey); return; }   // Ctrl+Enter: add, keep choosing
      clearTimeout(popTimer);
      setFilter(popCol, el.filterInput.value);
      if (!el.filterInput.classList.contains('tt-bad')) closeFilter();
    }
    if (e.key === 'Escape') closeFilter();
  });
  el.fpClear.addEventListener('click', () => { el.filterInput.value = ''; setFilter(popCol, ''); closeFilter(); });
  el.fpDone.addEventListener('click', () => { clearTimeout(popTimer); setFilter(popCol, el.filterInput.value); closeFilter(); });
  el.filterChips.addEventListener('click', e => {
    const d = e.target.closest('[data-col],[data-clear],[data-clear-all],[data-unsort],[data-ungroup],[data-groups]')?.dataset;
    if (!d) return;
    const all = ctl.model.allColumns;
    if ('unsort' in d) { setSort(null, 0); return; }
    if ('ungroup' in d) { setGroupBy(null); return; }
    if (d.groups) { ctl.view.setAllGroupsOpen(d.groups === 'open'); linesChanged(); return; }
    if ('clearAll' in d) ctl.view.filters.clear();
    else if (d.clear !== undefined) ctl.view.filters.delete(all[+d.clear]);
    else if (d.col !== undefined) {
      const r = e.target.closest('.tt-chip').getBoundingClientRect();
      openFilterFor(all[+d.col], r.left, r.bottom);
      return;
    }
    viewChanged();
  });

  // ---------- column chooser (top-left corner cell) ----------
  ctl.openColumns = (left, top) => {
    closeFilter();
    el.colSearch.value = '';
    renderViewOptions();
    renderColumnList();
    // The column list is a header control too: hidden when the page turns that off
    const showCols = ctl.headerControls.columns;
    for (const part of [el.colSearch, el.colList, el.colCount.parentElement, el.colAll, el.colReset]) part.hidden = !showCols;
    el.colPop.hidden = false;
    place(el.colPop, left, top);
    if (ctl.headerControls.columns) el.colSearch.focus();
  };
  function closeColumns() { el.colPop.hidden = true; }

  // "View" options at the top of the corner menu
  function renderViewOptions() {
    const { model, view } = ctl;
    el.optPanel.checked = !el.panel.hidden;
    el.optRowNums.checked = ctl.rowNumbers;
    el.optHeat.checked = ctl.heat;
    el.optTotals.value = ctl.totals || '';
    el.optHiddenRow.hidden = !model.hiddenCount;
    el.optHidden.checked = view.showHidden;
    el.optHiddenLabel.textContent = `Show ${fmt(model.hiddenCount)} rows hidden by the transform`;
    el.optRendererRow.hidden = Object.keys(RENDERERS).length < 2;   // only worth showing with a choice
    el.optRenderer.innerHTML = Object.keys(RENDERERS)
      .map(name => `<option value="${esc(name)}"${name === rendererName ? ' selected' : ''}>${esc(name)}</option>`).join('');
    el.dlAll.textContent = `⤓ Whole table (${fmt(model.numRows)})`;
    el.dlView.textContent = `⤓ Filtered view (${fmt(view.count())})`;
    el.dlSel.hidden = !ctl.rowSelCount;
    el.dlSel.textContent = `⤓ Selected rows (${fmt(selectedRowsInView().length)})`;
    el.dlAll.title = 'Every row, ignoring filters and transform-hidden rows, in data order';
    el.dlView.title = 'The rows currently shown, in the current sort order';
  }
  el.optPanel.addEventListener('change', e => setPanel(e.target.checked));
  el.optRowNums.addEventListener('change', e => setRowNumbers(e.target.checked));
  el.optHeat.addEventListener('change', e => setHeat(e.target.checked));
  el.optHidden.addEventListener('change', e => setShowHidden(e.target.checked));
  el.optRenderer.addEventListener('change', async e => {
    el.optRenderer.disabled = true;
    try { await switchRenderer(e.target.value); }
    catch (err) { showError(err.message); }
    finally { el.optRenderer.disabled = false; renderViewOptions(); }
  });

  // ---------- CSV export ----------
  // rows: 'view' = the rows shown (filters, hidden rows, sort order) | 'all' = every row in data order
  //       | 'selected' = the selected rows that are shown, in display order
  // columns: 'all' (default) = the current column layout plus the hidden columns | 'shown' = only shown columns
  // Values are written as displayed (same decimals as on screen); headers use the column labels.
  function csvParts({ rows = 'view', columns = 'all' } = {}) {
    const m = ctl.model;
    const cols = columns === 'all' ? m.allColumns : m.columns;
    const sel = rows === 'selected' ? selectedRowsInView() : null;
    const n = sel ? sel.length : rows === 'all' ? m.numRows : ctl.view.count();
    const at = sel ? i => sel[i] : rows === 'all' ? i => i : ctl.view.at;
    const parts = [cols.map(c => csvEscape(c.label)).join(',') + '\n'];
    const CHUNK = 20_000;   // build in chunks so no single huge string is needed
    for (let s = 0; s < n; s += CHUNK) {
      const lines = [];
      for (let k = s, end = Math.min(n, s + CHUNK); k < end; k++) {
        const row = at(k);
        let line = '';
        for (let c = 0; c < cols.length; c++) line += (c ? ',' : '') + csvEscape(cols[c].plain(row));   // values, not `format`ted text
        lines.push(line);
      }
      parts.push(lines.join('\n') + '\n');
    }
    return { parts, rowCount: n, colCount: cols.length };
  }

  async function downloadCsv(options = {}) {
    const rows = options.rows || 'view';
    const big = (rows === 'all' ? ctl.model.numRows : rows === 'selected' ? ctl.rowSelCount : ctl.view.count()) > 100_000;
    if (big) await busy('Preparing CSV…');
    try {
      const { parts } = csvParts(options);
      const base = (ctl.info.sourceLabel || 'table').replace(/\.csv$/i, '').replace(/[^\w.-]+/g, '_').replace(/^_+|_+$/g, '') || 'table';
      const name = options.filename || `${base}-${rows === 'all' ? 'all' : rows === 'selected' ? 'selected' : 'filtered'}.csv`;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob(parts, { type: 'text/csv' }));
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 10_000);
      return name;
    } finally {
      if (big) idle();
    }
  }

  el.dlAll.addEventListener('click', () => downloadCsv({ rows: 'all', columns: el.dlAllCols.checked ? 'all' : 'shown' }));
  el.dlView.addEventListener('click', () => downloadCsv({ rows: 'view', columns: el.dlAllCols.checked ? 'all' : 'shown' }));
  el.dlSel.addEventListener('click', () => downloadCsv({ rows: 'selected', columns: el.dlAllCols.checked ? 'all' : 'shown' }));

  async function switchRenderer(name) {
    rendererReady = setRenderer(name);
    await rendererReady;
    if (ctl.model) renderInfo();
  }

  function renderColumnList() {
    const { model, view } = ctl, all = model.allColumns;
    const q = el.colSearch.value.trim().toLowerCase();
    el.colCount.textContent = `${model.columns.length} of ${all.length} shown`;
    el.colList.innerHTML = all.map((c, i) => {
      if (q && !c.label.toLowerCase().includes(q) && !(c.sourceName || '').toLowerCase().includes(q)) return '';
      const note = c.computed ? 'computed' : c.sourceName !== c.label ? `from ${esc(c.sourceName)}` : '';
      return `<div class="tt-colrow${c.visible ? '' : ' tt-off'}">
          <label><input type="checkbox" data-toggle="${i}" ${c.visible ? 'checked' : ''}>
            <span class="tt-name">${view.filters.has(c) ? '<span class="tt-funnel"></span>' : ''}${esc(c.label)}</span>
            <span class="tt-meta">${c.type === 'number' ? '#' : 'abc'}${note ? ' · ' + note : ''}</span></label>
          <button data-move="${i}" data-dir="-1" title="Move up" ${i === 0 ? 'disabled' : ''}>▲</button>
          <button data-move="${i}" data-dir="1" title="Move down" ${i === all.length - 1 ? 'disabled' : ''}>▼</button>
        </div>`;
    }).join('') || '<div class="tt-hint">No matching columns.</div>';
  }

  // Recompute the displayed columns; keep the selection on the same column if it is still shown
  async function columnsChanged() {
    const m = ctl.model;
    const selCol = m.columns[ctl.sel.x];
    m.columns = m.allColumns.filter(c => c.visible);
    const x = selCol ? m.columns.indexOf(selCol) : -1;
    ctl.sel = { x, y: x >= 0 ? ctl.sel.y : -1 };
    ctl.hover = { x: -1, y: -1 };
    renderInfo();
    renderFilterPanel();
    renderColumnList();
    await renderer.columnsChanged();
    emit('columns');
  }

  // Move a displayed column from position `from` to `to` (both indexes into model.columns), e.g. after a header drag.
  // The order lives in allColumns, so the column list in the ☰ menu and Reset stay in step.
  ctl.moveColumn = (from, to) => {
    const m = ctl.model, cols = m.columns;
    if (from === to || from < 0 || to < 0 || from >= cols.length || to >= cols.length) return;
    const col = cols[from], target = cols[to], all = m.allColumns;
    all.splice(all.indexOf(col), 1);
    const at = all.indexOf(target);
    all.splice(to > from ? at + 1 : at, 0, col);
    return columnsChanged();
  };

  el.colSearch.addEventListener('input', renderColumnList);
  el.colSearch.addEventListener('keydown', e => { if (e.key === 'Escape') closeColumns(); });
  el.colList.addEventListener('change', e => {
    const i = e.target.dataset.toggle;
    if (i === undefined) return;
    const col = ctl.model.allColumns[+i];
    if (!e.target.checked && ctl.model.columns.length === 1 && col.visible) { e.target.checked = true; return; }   // keep at least one
    col.visible = e.target.checked;
    columnsChanged();
  });
  el.colList.addEventListener('click', e => {
    const b = e.target.closest('[data-move]');
    if (!b) return;
    const all = ctl.model.allColumns, i = +b.dataset.move, j = i + +b.dataset.dir;
    if (j < 0 || j >= all.length) return;
    [all[i], all[j]] = [all[j], all[i]];
    columnsChanged();
  });
  el.colAll.addEventListener('click', () => { ctl.model.allColumns.forEach(c => { c.visible = true; }); columnsChanged(); });
  el.colReset.addEventListener('click', () => {
    const m = ctl.model;
    m.allColumns.splice(0, m.allColumns.length, ...m.defaultOrder);
    m.allColumns.forEach(c => { c.visible = c.defaultVisible; c.width = c.defaultWidth; c.align = c.defaultAlign; c.total = c.defaultTotal; });
    totalsCache.byCol.clear();
    columnsChanged();
  });
  el.colDone.addEventListener('click', closeColumns);

  // ---------- view state: sort, filters, grouping ----------
  // { sort: { key, dir } | null, filters: { key: text }, groupBy: key | null }
  function getState() {
    const v = ctl.view;
    if (!v) return { sort: null, filters: {}, groupBy: null };
    const filters = {};
    for (const [col, f] of v.filters) filters[col.key] = f.text;
    return { sort: v.sort ? { key: v.sort.col.key, dir: v.sort.dir } : null, filters, groupBy: v.group ? v.group.col.key : null };
  }
  // Applies the parts given (a missing part is left as it is). Parts that no longer fit the data (an unknown
  // column, a filter that can't be read) are skipped; returns a list of what was skipped. A hidden column
  // that is sorted by is shown.
  async function setState(state) {
    const v = ctl.view, skipped = [];
    if (!v || !state) return skipped;
    let showSorted = false;
    if ('filters' in state) {
      v.filters.clear();
      for (const [key, text] of Object.entries(state.filters || {})) {
        const col = colByKey(key);
        const error = col ? applyFilterText(col, String(text)) : `no column "${key}"`;
        if (error) skipped.push(`filter ${key}: ${error}`);
      }
    }
    if ('sort' in state) {
      const s = state.sort, col = s && s.dir ? colByKey(s.key) : null;
      if (s && s.dir && !col) skipped.push(`sort: no column "${s.key}"`);
      v.sort = col ? { col, dir: s.dir > 0 ? 1 : -1 } : null;
      if (col && !col.visible) { col.visible = true; showSorted = true; }   // a sort you can't see is confusing
    }
    if ('groupBy' in state) {
      const col = state.groupBy ? colByKey(state.groupBy) : null;
      if (state.groupBy && !col) skipped.push(`groupBy: no column "${state.groupBy}"`);
      if ((v.group ? v.group.col : null) !== col) v.group = col ? { col, open: new Set() } : null;
      ctl.groupKey = col ? col.key : null;
    }
    const slow = v.sort && ctl.model.numRows > 200_000;
    if (slow) await busy('Sorting…');
    v.apply();
    if (slow) idle();
    if (showSorted) await columnsChanged();
    renderFilterPanel();
    await rowsChanged(v.count() ? v.at(0) : 0);
    renderer.scrollToIndex(0);
    renderer.redraw();
    emit('state');
    return skipped;
  }

  // urlState: 'name' keeps the state in the page's query string, as name.sort=-price, name.filter.status==shipped,
  // name.group=status (other query parameters are left alone), and restores it when the page opens
  const urlPrefix = typeof opts.urlState === 'string' && opts.urlState ? opts.urlState + '.' : null;
  const configGroup = ctl.groupKey;   // grouping from the config; turning it off needs saying in the URL
  // Readable in the address bar: | = , < > and spaces as + stay as they are
  const encodeParam = s => encodeURIComponent(s).replace(/%7C/g, '|').replace(/%3D/g, '=').replace(/%2C/g, ',')
    .replace(/%3C/g, '<').replace(/%3E/g, '>').replace(/%20/g, '+');
  function readUrlState() {
    const params = new URLSearchParams(location.search), state = {};
    for (const [name, value] of params) {
      if (!name.startsWith(urlPrefix)) continue;
      const part = name.slice(urlPrefix.length);
      if (part === 'sort') state.sort = value ? { key: value.replace(/^-/, ''), dir: value.startsWith('-') ? -1 : 1 } : null;
      else if (part === 'group') state.groupBy = value || null;
      else if (part.startsWith('filter.')) (state.filters ||= {})[part.slice(7)] = value;
    }
    return Object.keys(state).length ? state : null;
  }
  function writeUrlState() {
    const s = getState(), ours = [];
    if (s.sort) ours.push(['sort', (s.sort.dir < 0 ? '-' : '') + s.sort.key]);
    for (const [key, text] of Object.entries(s.filters)) ours.push([`filter.${key}`, text]);
    if (s.groupBy || configGroup) ours.push(['group', s.groupBy || '']);
    // Keep every other parameter exactly as written
    const others = location.search.replace(/^\?/, '').split('&').filter(p => {
      if (!p) return false;
      let name = p.split('=')[0];
      try { name = decodeURIComponent(name.replace(/\+/g, ' ')); } catch { /* leave it */ }
      return !name.startsWith(urlPrefix);
    });
    const query = [...others, ...ours.map(([k, v]) => `${encodeParam(urlPrefix + k)}=${encodeParam(v)}`)].join('&');
    if (query === location.search.replace(/^\?/, '')) return;
    try { history.replaceState(history.state, '', `${location.pathname}${query ? '?' + query : ''}${location.hash}`); }
    catch (err) { /* e.g. not allowed for this page's URL: the table still works */ }
  }

  // ---------- start ----------
  // Set up the renderer while the data loads (a custom renderer may load something asynchronously)
  rendererReady = setRenderer(opts.renderer);
  const initialSource = opts.source;
  opts.source = null;   // don't keep the CSV text alive for the table's lifetime (it can be ~100 MB)
  const startState = urlPrefix ? readUrlState() : null;   // read before the first load rewrites the URL
  await load(initialSource);
  await rendererReady;
  if (startState) {
    const skipped = await setState(startState);
    if (skipped.length) console.warn('[tall-table] parts of the saved state were skipped:', skipped.join('; '));
  }
  if (urlPrefix) {
    listeners.add(({ type }) => { if (['load', 'sort', 'filter', 'group', 'state'].includes(type)) writeUrlState(); });
    writeUrlState();
  }

  return {
    load,
    setTransform,
    setRenderer: switchRenderer,
    setPanel,                 // show / hide the side panel
    setRowNumbers,            // show / hide the row-number column (the ☰ menu stays in a slim strip)
    setHeatmap: setHeat,      // heatmap colouring on / off
    setShowHidden,            // show rows hidden by the transform
    downloadCsv,              // ({ rows: 'view' | 'all', columns: 'all' (default) | 'shown', filename }) -> starts a download
    toCsv: options => csvParts(options).parts.join(''),   // same options, returns the CSV text
    redraw() { if (renderer) renderer.redraw(); },        // repaint, e.g. after something render callbacks read changed
    get panelVisible() { return !el.panel.hidden; },
    get renderer() { return rendererName; },
    get model() { return ctl.model; },
    get view() { return ctl.view; },
    get selectedRows() { return selectedRowsInView(); },   // data row numbers, in display order
    selectRows(rows) {                                      // replace the row selection with these data rows
      const m = ctl.model;
      ctl.rowSel = new Uint8Array(m.numRows);
      ctl.rowSelCount = 0;
      for (const r of rows) if (r >= 0 && r < m.numRows && !ctl.rowSel[r]) { ctl.rowSel[r] = 1; ctl.rowSelCount++; }
      rowAnchor = rows.length ? rows[rows.length - 1] : -1;
      ctl.sel = { x: -1, y: -1 };
      rowSelectionChanged();
    },
    clearRowSelection: () => clearRowSelection(),
    scrollToRow,                                            // (dataRow) -> Promise<bool>: false if filters hide it
    get hoveredRow() { return ctl.hover.y; },               // the data row under the pointer, or -1
    copySelection,                                         // what Ctrl/⌘+C does; resolves to the copied text
    select: (x, row) => ctl.select(x, row),

    // ---------- column state, for building the header UI outside the table ----------
    // `key` is a column's stable id (its source name, or label for computed columns); labels work too.
    // Every change below, and the same changes made in the table itself, fire onChange listeners.
    get columns() { return ctl.model ? ctl.model.allColumns.map(columnInfo) : []; },   // all columns, current order
    onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); },          // returns an unsubscribe function
    async setFilter(key, text) {          // returns an error message for unreadable text, otherwise null
      const col = colByKey(key);
      if (!col) return `No column "${key}"`;
      const error = applyFilterText(col, text || '');
      if (!error) await viewChanged();
      return error;
    },
    async clearFilters() { ctl.view.filters.clear(); await viewChanged(); },
    setSort: (key, dir) => { const col = colByKey(key); return col ? setSort(col, dir > 0 ? 1 : dir < 0 ? -1 : 0) : null; },
    async setColumnVisible(key, visible) {
      const col = colByKey(key);
      if (!col || (!visible && col.visible && ctl.model.columns.length === 1)) return;   // keep at least one
      col.visible = !!visible;
      await columnsChanged();
    },
    async moveColumnTo(key, index) {      // index in the full column order (table.columns)
      const col = colByKey(key), all = ctl.model.allColumns;
      if (!col) return;
      all.splice(all.indexOf(col), 1);
      all.splice(Math.max(0, Math.min(all.length, index)), 0, col);
      await columnsChanged();
    },
    setAlign(key, align) {
      const col = colByKey(key);
      if (!col || !ALIGNS.includes(align)) return;
      col.align = align;
      renderer.redraw();
      emit('align');
    },
    async setWidth(key, px) {             // px, or null for the fitted width
      const col = colByKey(key);
      if (!col) return;
      col.width = px > 0 ? Math.round(Math.min(2000, Math.max(30, px))) : null;
      await renderer.columnsChanged();
      emit('width');
    },
    suggestValues(key, query = '', limit = 8) {   // text columns: [{ value, count }], closest first
      const col = colByKey(key);
      return col && col.type === 'text' ? suggestValues(col, query, limit) : [];
    },
    async resetColumns() { el.colReset.click(); },   // order, visibility, widths and alignment back to the config
    async setHeaders(show) {              // show / hide the column header row in the table
      ctl.headers = !!show;
      closePopovers();
      if (renderer.headersChanged) await renderer.headersChanged();
      emit('headers');
    },
    get headersVisible() { return ctl.headers; },
    setGroupBy(key) {                     // group the rows by a column (collapsible, with subtotals); null to stop
      return setGroupBy(key == null ? null : colByKey(key));
    },
    get groupBy() { return ctl.view && ctl.view.group ? ctl.view.group.col.key : null; },
    get groups() {                        // [{ name, count, open }] in display order
      return ctl.view ? ctl.view.groups.map(g => ({ name: g.name, count: g.end - g.start, open: g.open })) : [];
    },
    setGroupOpen(name, open) {            // open / close one group by name
      const g = ctl.view.groups.find(gr => gr.name === String(name));
      if (g) setGroupOpen(g, !!open);
    },
    setAllGroupsOpen(open) { if (ctl.view.group) { ctl.view.setAllGroupsOpen(!!open); linesChanged(); } },
    getState,                             // { sort: { key, dir } | null, filters: { key: text }, groupBy: key | null }
    setState,                             // applies the parts given; resolves to a list of parts that were skipped
    setTotals,                            // the totals row: 'top', 'bottom', or false / null for none
    get totals() { return ctl.totals; },
    setTotal(key, mode) {                 // a column's total: 'sum' | 'avg' | 'min' | 'max' | 'count' | 'distinct' |
      const col = colByKey(key);          //   a function | null (none) | 'default' (back to the config's)
      if (!col || !(mode == null || mode === 'default' || typeof mode === 'function' || TOTALS[col.type].includes(mode))) return;
      setColumnTotal(col, mode);
    },
    setHeaderControls(controls) {         // e.g. { sort: false, filter: false } to leave those to an external UI
      Object.assign(ctl.headerControls, controls);
      closePopovers();
      renderer.redraw();
    },
    get headerControls() { return { ...ctl.headerControls }; },
    openOptionsMenu(x, y) { ctl.openColumns(x, y); },   // the ☰ menu, e.g. from a page button when headers are off
    openColumnMenu(key, x, y) {           // a column's filter / sort / align popup, at viewport position x, y
      const col = colByKey(key);
      if (col) openFilterFor(col, x, y);
    },
    get columnMenuKey() { return !el.filterPop.hidden && popCol ? popCol.key : null; },   // whose popup is open

    destroy() {
      document.removeEventListener('mousedown', onDocMouseDown);
      if (renderer) renderer.destroy();
      listeners.clear();
      root.remove();
    },
  };

  function colByKey(key) {
    if (!ctl.model) return null;
    const all = ctl.model.allColumns;
    return all.find(c => c.key === key) || all.find(c => c.label === key) || null;
  }
  function columnInfo(c) {
    const s = ctl.view.sort;
    return {
      key: c.key, label: c.label, type: c.type, source: c.sourceName, computed: c.computed,
      visible: c.visible, sort: s && s.col === c ? s.dir : 0, filter: ctl.view.filters.get(c)?.text || '',
      align: c.align, width: c.width || null,
      total: typeof c.total === 'function' ? 'custom' : c.total,
      totalValue: ctl.totals && c.visible ? totalOf(c).value : null,   // while the totals row is on
      grouped: !!ctl.view.group && ctl.view.group.col === c,
    };
  }
}

// ===========================================================================
// Column editor: the header controls as a plain HTML list, placed anywhere on the page
// ===========================================================================
//   const editor = TallTable.columnEditor(table, element, {
//     parts: ['visible', 'order', 'sort', 'filter', 'align', 'width'],   // which controls to show (default: all)
//     title: 'Columns', optionsButton: true,                             // heading, and a "☰ Options" button
//   });
//   editor.destroy()
// It only uses the table's public API (table.columns, setFilter, setSort, … and onChange), so it stays in step
// with changes made in the table itself, and it doubles as an example of building your own controls.
const EDITOR_PARTS = ['visible', 'order', 'sort', 'filter', 'align', 'width'];

function columnEditor(table, container, options = {}) {
  const parts = Object.fromEntries(EDITOR_PARTS.map(p => [p, !options.parts || options.parts.includes(p)]));
  const root = document.createElement('div');
  root.className = 'tt-ce';
  root.style.setProperty('--tt-ce-cols', [parts.visible && '24px', parts.order && '64px', 'minmax(110px, 1.2fr)',
    parts.sort && '34px', parts.filter && 'minmax(150px, 2fr)', parts.align && '86px', parts.width && '72px'].filter(Boolean).join(' '));
  root.innerHTML = `
    <div class="tt-ce-bar">
      <b>${esc(options.title || 'Columns')}</b><span class="tt-ce-count"></span>
      <span class="tt-ce-actions">
        ${parts.visible ? '<button data-act="all">Show all</button>' : ''}
        ${parts.filter ? '<button data-act="clear">Clear filters</button>' : ''}
        <button data-act="reset" title="Order, visibility, widths and alignment back to the page's config">Reset</button>
        ${options.optionsButton === false ? '' : '<button data-act="options" title="Side panel, row numbers, colours, download…">☰ Options</button>'}
      </span>
    </div>
    <div class="tt-ce-row tt-ce-head">
      ${parts.visible ? '<span title="Shown">✓</span>' : ''}${parts.order ? '<span>Order</span>' : ''}<span>Column</span>
      ${parts.sort ? '<span>Sort</span>' : ''}${parts.filter ? '<span>Filter</span>' : ''}
      ${parts.align ? '<span>Align</span>' : ''}${parts.width ? '<span>Width</span>' : ''}
    </div>
    <div class="tt-ce-list"></div>
    <div class="tt-ce-sugg tt-sugg" hidden></div>`;
  container.appendChild(root);
  const list = root.querySelector('.tt-ce-list'), suggBox = root.querySelector('.tt-ce-sugg');
  const keyOf = node => node.closest('.tt-ce-row')?.dataset.key;
  const rowFor = key => [...list.children].find(r => r.dataset.key === key);
  const sortIcon = dir => (dir > 0 ? '▲' : dir < 0 ? '▼' : '⇅');

  function rowHtml(c, i, n) {
    return `<div class="tt-ce-row${c.visible ? '' : ' tt-off'}" data-key="${esc(c.key)}">
      ${parts.visible ? `<input type="checkbox" data-a="vis" ${c.visible ? 'checked' : ''} title="Show this column">` : ''}
      ${parts.order ? `<span class="tt-ce-order"><span class="tt-ce-grip" draggable="true" title="Drag to reorder">⋮⋮</span><button data-a="up" ${i === 0 ? 'disabled' : ''} title="Move up">▲</button><button data-a="down" ${i === n - 1 ? 'disabled' : ''} title="Move down">▼</button></span>` : ''}
      <span class="tt-ce-label" title="${esc(c.label)}${c.source && c.source !== c.label ? ` (from ${esc(c.source)})` : ''}">${esc(c.label)} <small>${c.type === 'number' ? '#' : 'abc'}${c.computed ? ' · computed' : ''}</small></span>
      ${parts.sort ? `<button data-a="sort" class="tt-ce-sort${c.sort ? ' tt-on' : ''}" title="Sort: click for ▲ ascending, ▼ descending, off">${sortIcon(c.sort)}</button>` : ''}
      ${parts.filter ? `<input type="text" data-a="filter" value="${esc(c.filter)}" placeholder="${c.type === 'number' ? 'e.g. >10<20 or <5 | >40' : 'e.g. =North | =South'}" spellcheck="false" autocomplete="off">` : ''}
      ${parts.align ? `<span class="tt-ce-seg">${ALIGNS.map(a => `<button data-a="align" data-v="${a}" class="${c.align === a ? 'tt-on' : ''}" title="Align ${a}">${a === 'left' ? '⇤' : a === 'center' ? '↔' : '⇥'}</button>`).join('')}</span>` : ''}
      ${parts.width ? `<input type="number" data-a="width" min="30" max="2000" step="10" value="${c.width || ''}" placeholder="auto" title="Width in px (empty = fitted to the content)">` : ''}
    </div>`;
  }

  // Full redraw (column order / visibility / new data); keeps the caret if a filter box is being typed in
  function render() {
    const cols = table.columns;
    const a = document.activeElement;
    const focused = a && list.contains(a) && a.dataset.a === 'filter' ? { key: keyOf(a), pos: a.selectionStart } : null;
    list.innerHTML = cols.map((c, i) => rowHtml(c, i, cols.length)).join('') || '<div class="tt-ce-empty">No data loaded yet.</div>';
    root.querySelector('.tt-ce-count').textContent = cols.length ? `${cols.filter(c => c.visible).length} of ${cols.length} shown` : '';
    if (focused) {
      const inp = rowFor(focused.key)?.querySelector('[data-a="filter"]');
      if (inp) { inp.focus(); inp.setSelectionRange(focused.pos, focused.pos); }
    }
  }
  // In-place update (sort, filter, align, width changed); never overwrites the box being typed in
  function update() {
    for (const c of table.columns) {
      const row = rowFor(c.key);
      if (!row) { render(); return; }
      row.classList.toggle('tt-off', !c.visible);
      const q = s => row.querySelector(s);
      if (parts.visible) q('[data-a="vis"]').checked = c.visible;
      if (parts.sort) { const b = q('[data-a="sort"]'); b.textContent = sortIcon(c.sort); b.classList.toggle('tt-on', !!c.sort); }
      if (parts.filter) { const f = q('[data-a="filter"]'); if (f !== document.activeElement) { f.value = c.filter; f.classList.remove('tt-bad'); f.title = ''; } }
      if (parts.align) for (const b of row.querySelectorAll('[data-a="align"]')) b.classList.toggle('tt-on', b.dataset.v === c.align);
      if (parts.width) { const w = q('[data-a="width"]'); if (w !== document.activeElement) w.value = c.width || ''; }
    }
  }
  const off = table.onChange(({ type }) => (type === 'columns' || type === 'load' ? render() : update()));
  render();

  // ----- controls -----
  list.addEventListener('change', async e => {
    const a = e.target.dataset.a, key = keyOf(e.target);
    if (a === 'vis') { await table.setColumnVisible(key, e.target.checked); update(); }   // update: the last column can't be hidden
    else if (a === 'width') table.setWidth(key, e.target.value === '' ? null : +e.target.value);
  });
  list.addEventListener('click', e => {
    const b = e.target.closest('button[data-a]');
    if (!b) return;
    const key = keyOf(b), cols = table.columns, i = cols.findIndex(c => c.key === key);
    if (b.dataset.a === 'up' || b.dataset.a === 'down') table.moveColumnTo(key, i + (b.dataset.a === 'up' ? -1 : 1));
    else if (b.dataset.a === 'sort') { const s = cols[i].sort; table.setSort(key, s === 0 ? 1 : s > 0 ? -1 : 0); }
    else if (b.dataset.a === 'align') table.setAlign(key, b.dataset.v);
  });
  root.querySelector('.tt-ce-bar').addEventListener('click', async e => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    if (b.dataset.act === 'all') { for (const c of table.columns) if (!c.visible) await table.setColumnVisible(c.key, true); }
    else if (b.dataset.act === 'clear') table.clearFilters();
    else if (b.dataset.act === 'reset') table.resetColumns();
    else if (b.dataset.act === 'options') { const r = b.getBoundingClientRect(); table.openOptionsMenu(r.left, r.bottom); }
  });

  // ----- filter boxes: applied as you type, with value suggestions for text columns -----
  let timer = 0, input = null, sugg = [], suggIdx = -1, suggNeg = false, suggEarlier = [];
  const markError = (inp, err) => { inp.classList.toggle('tt-bad', !!err); inp.title = err || ''; };
  const applyNow = inp => { clearTimeout(timer); const key = keyOf(inp); table.setFilter(key, inp.value).then(err => markError(inp, err)); };

  function showSugg(inp) {
    input = inp;
    const key = keyOf(inp), col = table.columns.find(c => c.key === key);
    if (!col || col.type !== 'text') { hideSugg(); return; }
    const terms = inp.value.split('|');
    const m = /^\s*(!=|!|==|=)?(.*)$/.exec(terms.pop());
    suggEarlier = terms.map(t => t.trim()).filter(Boolean);
    const chosen = new Set(suggEarlier.map(t => t.replace(/^(!=|!|==|=)/, '').trim().toLowerCase()));
    suggNeg = !!m[1] && m[1].startsWith('!');
    sugg = table.suggestValues(key, m[2], 8 + chosen.size).filter(s => !chosen.has(s.value.toLowerCase())).slice(0, 8);
    if (!sugg.length) { hideSugg(); return; }
    suggBox.innerHTML = sugg.map((s, i) => `<div class="tt-sugg-row${i === suggIdx ? ' tt-on' : ''}">
        <button type="button" data-sugg="${i}"><span>${suggNeg ? '≠ ' : ''}${esc(s.value)}</span><span class="tt-n">${s.count.toLocaleString()}</span></button>
        <button type="button" class="tt-add" data-sugg-add="${i}" title="Add and keep choosing (either / or) · Ctrl+click">+</button></div>`).join('');
    const r = inp.getBoundingClientRect(), rr = root.getBoundingClientRect();
    suggBox.style.left = (r.left - rr.left) + 'px';
    suggBox.style.top = (r.bottom - rr.top + 2) + 'px';
    suggBox.style.width = Math.max(220, r.width) + 'px';
    suggBox.hidden = false;
  }
  function hideSugg() { suggBox.hidden = true; sugg = []; suggIdx = -1; }
  function pick(i, add) {
    const s = sugg[i];
    if (!s || !input) return;
    input.value = [...suggEarlier, (suggNeg ? '!=' : '=') + s.value].join(' | ') + (add ? ' | ' : '');
    applyNow(input);
    if (add) { suggIdx = -1; input.focus(); input.setSelectionRange(input.value.length, input.value.length); showSugg(input); }
    else hideSugg();
  }
  suggBox.addEventListener('mousedown', e => e.preventDefault());   // keep focus in the filter box
  suggBox.addEventListener('click', e => {
    const add = e.target.closest('[data-sugg-add]');
    if (add) { pick(+add.dataset.suggAdd, true); return; }
    const b = e.target.closest('[data-sugg]');
    if (b) pick(+b.dataset.sugg, e.ctrlKey || e.metaKey);
  });
  list.addEventListener('input', e => {
    if (e.target.dataset.a !== 'filter') return;
    const inp = e.target;
    clearTimeout(timer);
    timer = setTimeout(() => applyNow(inp), 200);
    suggIdx = -1;
    showSugg(inp);
  });
  list.addEventListener('focusin', e => { if (e.target.dataset.a === 'filter') { suggIdx = -1; showSugg(e.target); } });
  list.addEventListener('focusout', e => {
    if (e.target.dataset.a === 'filter') setTimeout(() => { if (!list.contains(document.activeElement) || document.activeElement.dataset.a !== 'filter') hideSugg(); }, 120);
  });
  list.addEventListener('keydown', e => {
    const inp = e.target;
    if (inp.dataset.a === 'width' && e.key === 'Enter') { inp.blur(); return; }
    if (inp.dataset.a !== 'filter') return;
    if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && sugg.length) {
      e.preventDefault();
      suggIdx = e.key === 'ArrowDown' ? Math.min(sugg.length - 1, suggIdx + 1) : Math.max(-1, suggIdx - 1);
      showSugg(inp);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (suggIdx >= 0) pick(suggIdx, e.ctrlKey || e.metaKey);
      else { applyNow(inp); hideSugg(); }
    } else if (e.key === 'Escape') hideSugg();
  });

  // ----- drag the ⋮⋮ handle to reorder -----
  let dragKey = null;
  const clearMarks = () => list.querySelectorAll('.tt-drop-before, .tt-drop-after, .tt-dragging')
    .forEach(r => r.classList.remove('tt-drop-before', 'tt-drop-after', 'tt-dragging'));
  list.addEventListener('dragstart', e => {
    if (!e.target.classList || !e.target.classList.contains('tt-ce-grip')) return;
    const row = e.target.closest('.tt-ce-row');
    dragKey = row.dataset.key;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', dragKey);
    e.dataTransfer.setDragImage(row, 20, 12);
    row.classList.add('tt-dragging');
  });
  list.addEventListener('dragover', e => {
    const row = dragKey && e.target.closest && e.target.closest('.tt-ce-row');
    if (!row) return;
    e.preventDefault();
    const after = e.clientY > row.getBoundingClientRect().top + row.offsetHeight / 2;
    list.querySelectorAll('.tt-drop-before, .tt-drop-after').forEach(r => r.classList.remove('tt-drop-before', 'tt-drop-after'));
    row.classList.add(after ? 'tt-drop-after' : 'tt-drop-before');
  });
  list.addEventListener('drop', e => {
    const row = dragKey && e.target.closest && e.target.closest('.tt-ce-row');
    if (!row) return;
    e.preventDefault();
    const cols = table.columns, from = cols.findIndex(c => c.key === dragKey);
    let to = cols.findIndex(c => c.key === row.dataset.key) + (row.classList.contains('tt-drop-after') ? 1 : 0);
    if (to > from) to--;
    const key = dragKey;
    dragKey = null;
    clearMarks();
    if (to !== from) table.moveColumnTo(key, to);
  });
  list.addEventListener('dragend', () => { dragKey = null; clearMarks(); });

  return {
    refresh: render,
    destroy() { off(); clearTimeout(timer); root.remove(); },
  };
}

// ===========================================================================
// Header bar: the minimal outside header, one button per column that opens its popup
// ===========================================================================
//   const bar = TallTable.headerBar(table, element, {
//     optionsButton: true,   // a ☰ button first, for the options menu
//     hidden: false,         // true: also list hidden columns (greyed), so they can be filtered too
//   });
//   bar.destroy()
// Buttons follow the table's column order and show ▲ / ▼ when sorted and a funnel when filtered.
function headerBar(table, container, options = {}) {
  const root = document.createElement('div');
  root.className = 'tt-hb';
  root.setAttribute('role', 'toolbar');
  root.setAttribute('aria-label', 'Table columns');
  container.appendChild(root);

  function render() {
    const cols = table.columns.filter(c => c.visible || options.hidden);
    root.innerHTML = (options.optionsButton === false ? '' : '<button class="tt-hb-opt" data-opt title="Options: columns, side panel, colours, download">☰</button>')
      + cols.map(c => {
        const marks = (c.filter ? '<span class="tt-funnel"></span>' : '') + (c.sort ? `<span class="tt-hb-sort">${c.sort > 0 ? '▲' : '▼'}</span>` : '');
        const state = [c.sort ? (c.sort > 0 ? 'sorted ascending' : 'sorted descending') : '', c.filter ? `filter ${c.filter}` : ''].filter(Boolean).join(', ');
        return `<button data-key="${esc(c.key)}" class="${c.sort || c.filter ? 'tt-on' : ''}${c.visible ? '' : ' tt-off'}"
          title="${esc(c.label)}${state ? ` (${esc(state)})` : ''}: click to filter, sort or align">${marks}<span class="tt-hb-label">${esc(c.label)}</span><span class="tt-hb-caret">▾</span></button>`;
      }).join('');
  }
  const off = table.onChange(render);   // any change in the table, an editor or code
  render();

  root.addEventListener('mousedown', e => {
    // Clicking the button whose popup is already open closes it (the table closes popups on outside clicks)
    const b = e.target.closest('[data-key]');
    root.dataset.wasOpen = b && table.columnMenuKey === b.dataset.key ? '1' : '';
  });
  root.addEventListener('click', e => {
    const opt = e.target.closest('[data-opt]');
    if (opt) { const r = opt.getBoundingClientRect(); table.openOptionsMenu(r.left, r.bottom); return; }
    const b = e.target.closest('[data-key]');
    if (!b || root.dataset.wasOpen) return;
    const r = b.getBoundingClientRect();
    table.openColumnMenu(b.dataset.key, r.left, r.bottom);
  });

  return { refresh: render, destroy() { off(); root.remove(); } };
}

// numberData(name, Float64Array, decimals, trim) / textData(name, Uint32Array codes, dict with '' first):
// build the column shapes parseCsv produces, for a { data } source
window.TallTable = { create, registerRenderer, generateCsv, parseCsv, numberData, textData, buildModel, createView, parseFilter, columnEditor, headerBar };
})();
