// SPDX-License-Identifier: MIT
// Checks for openlayers-mvp/two-maps.html, run inside the page (it loads this with ?test): two maps on one
// page, each with its own data, categories, regions and selection. Needs the network (OpenLayers from a CDN).
TT.run('Two maps on one page', async T => {
  const { check, ok, wait } = T;
  await T.until(() => window.depots && window.sites && depots.data.points.length && sites.data.points.length, 20000, 'both maps');
  await wait(500);
  const [a, b] = document.querySelectorAll('.rm');
  check('two maps', document.querySelectorAll('.rm').length, 2);
  check('their own categories', [depots.categoryCounts.filter(c => c.count).map(c => c.name), sites.categoryCounts.filter(c => c.count).map(c => c.name)],
    [['Open', 'Closed'], ['North', 'South', 'East', 'West']]);
  check('their own data', [depots.data.points.length, sites.data.points.length, sites.data.boxes.length], [3000, 50000, 2000]);
  check('Performance section only on the first', [a.querySelector('.rm-stats-section').hidden, b.querySelector('.rm-stats-section').hidden], [false, true]);
  check('their own regions', [a.querySelector('.rm-crumb').textContent, b.querySelector('.rm-crumb').textContent], ['County', 'World']);
  // selecting in one leaves the other alone
  depots.selectFeature('point', 5, { pan: false });
  await wait(200);
  ok('a selection shows in its own map', a.querySelector('.rm-details').textContent.includes('Point'));
  ok('...not in the other', b.querySelector('.rm-details').textContent.startsWith('Click a feature'));
  sites.highlight([1, 2, 3], [], { pan: false });
  await wait(200);
  ok('both can have selections at once', a.querySelector('.rm-details').textContent.includes('Point') && b.querySelector('.rm-details').textContent.includes('Points'));
  depots.clearSelection(); sites.clearSelection();
  // hiding a category in one map
  a.querySelector('.rm-legend input[data-cat="0"]').click();
  await wait(200);
  check('a legend tick only changes its own map', [a.querySelector('.rm-legend input[data-cat="0"]').checked, b.querySelector('.rm-legend input[data-cat="0"]').checked], [false, true]);
});
